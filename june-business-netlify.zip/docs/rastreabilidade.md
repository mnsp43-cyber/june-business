# Matriz de rastreabilidade — June Business (Etapa 2)

Classificação: **Implementado** (funciona no protótipo, com regra e teste) · **Demonstrativo** (funciona com simulação identificada) · **Dependente de backend** · **Dependente de integração** · **Planejado**.

| Requisito do comando mestre | Tela / funcionalidade | Regra de negócio | Teste | Situação |
| --- | --- | --- | --- | --- |
| Login com marca, e-mail, senha, mostrar/ocultar, credenciais preenchidas | Login | Login local demonstrativo | Interface | Demonstrativo |
| Autenticação real, recuperação de senha, sessões | — | Supabase Auth | — | Dependente de backend |
| Perfil, edição, equipe, saída da conta | Configurações → Meu perfil / Equipe | — | Interface | Implementado |
| Perfis Proprietária, Recepcionista, Profissional, Gestora, Admin June | Equipe e permissões, troca de perfil | Matriz de permissões em menus e operações | Profissional/Recepcionista | Implementado (cliente) / Dependente de backend (servidor e RLS) |
| Navegação desktop lateral e barra inferior móvel (Meu Dia, Agenda, Dados, Clientes, Finanças, Mais) | Shell | Rótulos em uma linha | 390 px | Implementado |
| Ação rápida global | Botão + / menu | — | Interface | Implementado |
| Meu Dia completo | Meu Dia | — | Interface | Implementado |
| Cards de atendimento alinhados com ações por estado | Card | Ações conforme estado | Interface | Implementado |
| Pendências sem status final, sem conclusão automática | Meu Dia | `isPendingOp` | Estados | Implementado |
| Agenda diária, semanal, por profissional, filtros | Agenda | — | Interface | Implementado |
| Filtro por unidade | Agenda / Dashboard | Unidade única | — | Planejado (multiunidade) |
| Novo agendamento com campos essenciais e opcionais | Novo agendamento | — | Cria cliente automaticamente | Implementado |
| Normalização de telefone, sugestão de cadastro, confirmação | Novo agendamento | E.164; busca na mesma empresa | Normaliza / Reutiliza / Compartilhado | Implementado |
| Não mesclar telefone compartilhado; mesclagem autorizada | Clientes → Duplicidades | `mergeClients` com histórico | Duplicidade / Mesclagem | Implementado |
| Preço, duração e profissionais do serviço | Novo agendamento | Snapshot de preço | Preço novo não altera histórico | Implementado |
| Disponibilidade: jornada, intervalo, bloqueio, férias, sala, conflito | Agenda / Novo agendamento | `checkConflict`, `freeSlots` | Conflito / Recurso / Jornada | Implementado |
| Proteção contra reserva simultânea | — | Restrição de exclusão no PostgreSQL | — | Dependente de backend |
| Estados e transições válidas | Detalhes, cards | `TRANSITIONS` | Transição inválida | Implementado |
| Reagendamento com histórico e vínculo | Reagendar | `reschedule` | Reagendamento | Implementado |
| Cancelamento e falta sem venda; taxa só por política | Cards, Configurações | Política configurável, cobrança manual | Cancelamento e falta | Implementado |
| Agendamento online público | Integrações | — | — | Planejado |
| Finalização Expressa: extras, 5 situações, resumo | Finalização Expressa | `checkout` | 8 testes | Implementado |
| Sem finalização, recebimento ou consumo duplicados | Finalização | Idempotência + unicidade | Duplicada / consumo duplicado | Implementado (navegador) / Dependente de backend (transação real) |
| Ajustes e estornos autorizados com histórico | Financeiro | Reversão, permissão | Estorno | Implementado |
| Clientes: base, filtros, cadastro, métricas calculadas | Clientes | `clientStats` | Atualização integrada | Implementado |
| Perfil com Visão geral, Histórico, Pacotes, Financeiro, CRM | Perfil | Linha do tempo | Interface | Implementado |
| Sem dados sensíveis de saúde | Formulários | Avisos nos campos | — | Implementado |
| Catálogo de serviços | Serviços | Histórico de preços | Preço não retroativo | Implementado |
| Pacotes: criação, venda, saldo, validade, consumo | Serviços e Pacotes | Bloqueios de vencido/saldo | Pacote vencido / saldo | Implementado |
| Financeiro: vendas × recebimentos, saldo, despesas, filtros | Financeiro | Venda ≠ caixa | Venda não é caixa / Despesas | Implementado |
| Fechamento de caixa, comissões | Financeiro | Comissão simples | Interface | Implementado (comissões avançadas: Planejado) |
| Integração bancária | — | — | — | Planejado |
| Dashboard com dicionário, filtros, comparativos | Dashboard | `computeKPIs`, `variation`, `previousRange` | Variação zero / Equivalente / Filtros | Implementado |
| Gráficos exigidos (9) | Dashboard | — | Visual | Implementado |
| Insights determinísticos | Dashboard | Regras sem causa | — | Implementado |
| Base histórica de 12 meses | Seed | Determinística | — | Implementado |
| Segmentos dinâmicos e limites configuráveis | CRM → Segmentos, Configurações | `segmentMembers` | Atualização de segmentos | Implementado |
| Classificação ≠ elegibilidade | Segmentos, Campanhas | `eligibility` | Consentimento | Implementado |
| Central de campanhas com aprovação | CRM → Campanhas | Estados de campanha e de mensagem | Campanha simulada | Demonstrativo |
| Templates com variáveis | CRM → Templates | `renderTemplate` | Interface | Implementado |
| Jornadas Gatilho → Condição → Espera → Ação, simulação de tempo | CRM → Jornadas | Fila, revalidação, sem duplicidade | Jornadas / Avanço de tempo | Demonstrativo |
| Consentimento por canal e finalidade, descadastro | Perfil → CRM | Histórico de consentimento | Consentimento | Implementado |
| WhatsApp Business Platform e e-mail reais | Integrações | Adaptadores | — | Dependente de integração |
| Abrir conversa individual sem registrar envio | Menu do atendimento | Link wa.me | — | Implementado |
| Relatórios com CSV | Relatórios | Mesmas fórmulas | Interface | Implementado |
| Métricas de CRM (cliques, custos) | Relatórios → CRM | Indisponível sem rastreamento | — | Dependente de integração |
| Configurações do estabelecimento | Configurações | — | Interface | Implementado |
| Multiempresa, RLS, auditoria no servidor, LGPD | Modelo especificado | — | — | Dependente de backend |
| Persistência local e restauração | Dados demonstrativos | localStorage | Persistência | Implementado |
| Relógio demonstrativo | Dados demonstrativos / Jornadas | Só avança | — | Implementado |
| Indicadores de sucesso do produto | Dados demonstrativos | Tempos medidos | — | Implementado (hipóteses a validar) |
| Assinaturas SaaS, planos, multiunidade, estoque, IA | — | — | — | Planejado |
