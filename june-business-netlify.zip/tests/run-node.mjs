import { runTests } from './rules.test.js';
const r = runTests(); let f = 0;
for (const x of r) { if (!x.ok) f++; console.log((x.ok ? '✔ ' : '✘ ') + x.name + (x.ok ? '' : ' — ' + x.error)); }
console.log(`\n${r.length - f}/${r.length} testes passaram`); process.exit(f ? 1 : 0);
