// Gráficos em SVG próprio (sem bibliotecas externas). Cores de série em ordem fixa,
// validadas para daltonismo; tooltips por elemento; texto sempre em tinta neutra.
import { esc } from '../util.js';

export const SERIES = ['var(--series-1)', 'var(--series-2)', 'var(--series-3)', 'var(--series-4)'];

function niceMax(v) { if (v <= 0) return 1; const p = Math.pow(10, Math.floor(Math.log10(v))); const n = v / p; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * p; }
function niceMin(v) { return v >= 0 ? 0 : -niceMax(-v); }

export function legend(items) { return `<div class="legend">${items.map((it, i) => `<span><i class="${it.line ? 'line' : ''}" style="background:${it.color || SERIES[i]}"></i>${esc(it.label)}</span>`).join('')}</div>`; }

// Linhas: series = [{label, values:[...], color}], labels = [...]
export function lineChart({ labels, series, fmt = (v) => v, height = 220, yLabel = '', area = false }) {
  const W = 680, H = height, L = 56, R = 12, T = 12, B = 28; const n = labels.length;
  const all = series.flatMap((s) => s.values); const max = niceMax(Math.max(0, ...all)); const min = niceMin(Math.min(0, ...all));
  const x = (i) => L + (n <= 1 ? (W - L - R) / 2 : (i * (W - L - R)) / (n - 1)); const y = (v) => T + (H - T - B) * (1 - (v - min) / (max - min || 1));
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((f) => min + (max - min) * f);
  const step = Math.max(1, Math.ceil(n / 8));
  let svg = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(series.map((s) => s.label).join(' e '))}${yLabel ? ' — ' + esc(yLabel) : ''}">`;
  for (const t of ticks) svg += `<line class="gridline" x1="${L}" x2="${W - R}" y1="${y(t)}" y2="${y(t)}"/><text class="axis-label" x="${L - 8}" y="${y(t) + 4}" text-anchor="end">${esc(fmt(t, true))}</text>`;
  labels.forEach((lb, i) => { if (i % step === 0 || i === n - 1) svg += `<text class="axis-label" x="${x(i)}" y="${H - 8}" text-anchor="middle">${esc(lb)}</text>`; });
  series.forEach((s, si) => {
    const c = s.color || SERIES[si]; const pts = s.values.map((v, i) => `${x(i)},${y(v)}`).join(' ');
    if (area && si === 0) svg += `<polygon points="${x(0)},${y(Math.max(min, 0))} ${pts} ${x(n - 1)},${y(Math.max(min, 0))}" fill="${c}" opacity=".08"/>`;
    svg += `<polyline points="${pts}" fill="none" stroke="${c}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" ${s.dashed ? 'stroke-dasharray="5 4"' : ''}/>`;
    if (n <= 31) s.values.forEach((v, i) => { svg += `<circle cx="${x(i)}" cy="${y(v)}" r="3.5" fill="${c}" stroke="var(--surface)" stroke-width="2"/>`; });
  });
  // Camada de hover (alvos maiores que as marcas)
  const bw = n <= 1 ? W - L - R : (W - L - R) / (n - 1);
  labels.forEach((lb, i) => { const tip = `<b>${esc(lb)}</b><br>` + series.map((s, si) => `<span style="color:${'#cfe'}">●</span> ${esc(s.label)}: <b>${esc(fmt(s.values[i]))}</b>`).join('<br>'); svg += `<rect x="${x(i) - bw / 2}" y="${T}" width="${bw}" height="${H - T - B}" fill="transparent" data-tip="${esc(tip)}" tabindex="-1"/>`; });
  svg += '</svg>';
  return `<div class="chart">${series.length > 1 ? legend(series.map((s, i) => ({ label: s.label, color: s.color || SERIES[i], line: true }))) : ''}${svg}</div>`;
}

// Barras verticais agrupadas
export function barChart({ labels, series, fmt = (v) => v, height = 220 }) {
  const W = 680, H = height, L = 56, R = 8, T = 12, B = 28; const n = labels.length; const k = series.length;
  const all = series.flatMap((s) => s.values); const max = niceMax(Math.max(0, ...all)); const min = niceMin(Math.min(0, ...all));
  const y = (v) => T + (H - T - B) * (1 - (v - min) / (max - min || 1));
  const band = (W - L - R) / n; const gap = 2; const bw = Math.max(3, Math.min(28, (band * 0.72 - gap * (k - 1)) / k));
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((f) => min + (max - min) * f);
  const step = Math.max(1, Math.ceil(n / 10));
  let svg = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(series.map((s) => s.label).join(', '))}">`;
  for (const t of ticks) svg += `<line class="gridline" x1="${L}" x2="${W - R}" y1="${y(t)}" y2="${y(t)}"/><text class="axis-label" x="${L - 8}" y="${y(t) + 4}" text-anchor="end">${esc(fmt(t, true))}</text>`;
  labels.forEach((lb, i) => {
    const cx = L + band * i + band / 2; const gx = cx - (k * bw + (k - 1) * gap) / 2;
    if (i % step === 0 || i === n - 1) svg += `<text class="axis-label" x="${cx}" y="${H - 8}" text-anchor="middle">${esc(lb)}</text>`;
    series.forEach((s, si) => {
      const v = s.values[i]; const y0 = y(0), y1 = y(v); const top = Math.min(y0, y1), h = Math.max(1, Math.abs(y0 - y1)); const r = Math.min(4, bw / 2, h);
      const xx = gx + si * (bw + gap); const c = s.color || SERIES[si];
      // canto arredondado só na ponta de dados
      const d = v >= 0 ? `M${xx},${y0} V${top + r} Q${xx},${top} ${xx + r},${top} H${xx + bw - r} Q${xx + bw},${top} ${xx + bw},${top + r} V${y0} Z` : `M${xx},${y0} V${top + h - r} Q${xx},${top + h} ${xx + r},${top + h} H${xx + bw - r} Q${xx + bw},${top + h} ${xx + bw},${top + h - r} V${y0} Z`;
      svg += `<path d="${d}" fill="${c}"/>`;
    });
    const tip = `<b>${esc(lb)}</b><br>` + series.map((s) => `${esc(s.label)}: <b>${esc(fmt(s.values[i]))}</b>`).join('<br>');
    svg += `<rect x="${L + band * i}" y="${T}" width="${band}" height="${H - T - B}" fill="transparent" data-tip="${esc(tip)}"/>`;
  });
  if (min < 0) svg += `<line x1="${L}" x2="${W - R}" y1="${y(0)}" y2="${y(0)}" stroke="var(--axis)"/>`;
  svg += '</svg>';
  return `<div class="chart">${k > 1 ? legend(series.map((s, i) => ({ label: s.label, color: s.color || SERIES[i] }))) : ''}${svg}</div>`;
}

// Barras horizontais com rótulo e valor (ranking)
export function hbars(rows, { fmt = (v) => v, color = SERIES[0], max } = {}) {
  if (!rows.length) return '<p class="muted small">Sem dados no período.</p>';
  const m = max || Math.max(...rows.map((r) => r.value), 1);
  return `<div class="hbar">${rows.map((r) => `<div class="hb-label" title="${esc(r.label)}">${esc(r.label)}</div><div class="hb-track" data-tip="${esc(`<b>${esc(r.label)}</b><br>${r.tip || fmt(r.value)}`)}"><div class="hb-fill" style="width:${(r.value / m) * 100}%;background:${r.color || color}"></div></div><div class="hb-val">${esc(r.display ?? fmt(r.value))}</div>`).join('')}</div>`;
}

// Barra empilhada única (distribuição) com legenda e valores
export function stackBar(parts, { fmt = (v) => v } = {}) {
  const total = parts.reduce((t, p) => t + p.value, 0) || 1;
  return `<div style="display:flex;height:16px;border-radius:6px;overflow:hidden;gap:2px;background:var(--surface)">${parts.filter((p) => p.value > 0).map((p) => `<div style="flex:${p.value};background:${p.color}" data-tip="${esc(`<b>${esc(p.label)}</b>: ${fmt(p.value)} (${Math.round((p.value / total) * 100)}%)`)}"></div>`).join('')}</div>
  <div class="legend" style="margin-top:10px">${parts.map((p) => `<span><i style="background:${p.color}"></i>${esc(p.label)} <b class="num" style="color:var(--text)">${fmt(p.value)}</b></span>`).join('')}</div>`;
}

// Mapa de calor (sequencial, um só matiz)
export function heatmap({ rows, cols, get, rowLabel, colLabel, tipFmt }) {
  const vals = []; for (const r of rows) for (const c of cols) vals.push(get(r, c)); const max = Math.max(1, ...vals);
  const scale = ['var(--seq-1)', 'var(--seq-2)', 'var(--seq-3)', 'var(--seq-4)', 'var(--seq-5)', 'var(--seq-6)'];
  let h = `<div class="heat" style="grid-template-columns:36px repeat(${cols.length},minmax(0,1fr))"><div></div>${cols.map((c) => `<div class="hh">${esc(colLabel(c))}</div>`).join('')}`;
  for (const r of rows) {
    h += `<div class="hd">${esc(rowLabel(r))}</div>`;
    for (const c of cols) { const v = get(r, c); const i = v ? Math.min(5, Math.floor((v / max) * 5.999)) : -1; const bg = i < 0 ? 'var(--surface-2)' : scale[i]; const fg = i >= 3 ? '#fff' : 'var(--text-2)'; h += `<div class="hc" style="background:${bg};color:${fg}" data-tip="${esc(tipFmt(r, c, v))}">${v || ''}</div>`; }
  }
  h += '</div>';
  h += `<div class="row small subtle" style="margin-top:8px;gap:6px">Menos ${scale.map((c) => `<i style="width:14px;height:10px;border-radius:2px;background:${c};display:inline-block"></i>`).join('')} Mais</div>`;
  return h;
}
