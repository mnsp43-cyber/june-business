// Infraestrutura de interface: ícones, ações delegadas, folhas laterais, diálogos, toasts, menus e tooltips.
import { esc } from '../util.js';
import { STATUS } from '../domain/rules.js';

const P = {
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  calendar: '<rect x="3" y="4.5" width="18" height="16" rx="2"/><path d="M3 9.5h18M8 2.5v4M16 2.5v4"/>',
  chart: '<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.5 3.4-5.5 6.5-5.5s5.7 2 6.5 5.5"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18.5 14.8c1.6.8 2.7 2.6 3 5.2"/>',
  tag: '<path d="M3 12V4a1 1 0 0 1 1-1h8l9 9-9 9-9-9z"/><circle cx="7.5" cy="7.5" r="1.5"/>',
  wallet: '<rect x="3" y="6" width="18" height="14" rx="2"/><path d="M3 10h18M16 15h2"/><path d="M6 6V5a2 2 0 0 1 2-2h9"/>',
  megaphone: '<path d="M3 10v4a1 1 0 0 0 1 1h3l6 4V5L7 9H4a1 1 0 0 0-1 1z"/><path d="M17 8.5a5 5 0 0 1 0 7"/>',
  file: '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h5"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  more: '<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  check: '<path d="m5 12 5 5L20 7"/>',
  checkCircle: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  left: '<path d="m15 18-6-6 6-6"/>', right: '<path d="m9 18 6-6-6-6"/>', down: '<path d="m6 9 6 6 6-6"/>',
  phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2"/>',
  message: '<path d="M21 12a8 8 0 0 1-11.5 7.2L4 20l1-4.6A8 8 0 1 1 21 12z"/>',
  alert: '<path d="M12 3 2 20h20L12 3z"/><path d="M12 10v4M12 17.5v.01"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.5v.01"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeOff: '<path d="M3 3l18 18M10.6 5.1A10 10 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4.1M6.6 6.6C3.8 8.4 2 12 2 12s3.5 7 10 7a9.6 9.6 0 0 0 5.4-1.6M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>',
  filter: '<path d="M3 5h18l-7 8v6l-4 2v-8z"/>',
  download: '<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>',
  up: '<path d="m6 15 6-6 6 6"/>', box: '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>',
  cash: '<rect x="2.5" y="6" width="19" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 9.5v.01M18 14.5v.01"/>',
  play: '<path d="M7 4v16l13-8z"/>', pause: '<path d="M7 4h3v16H7zM14 4h3v16h-3z"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>',
  arrowRight: '<path d="M5 12h14M13 6l6 6-6 6"/>', merge: '<path d="M6 3v6a6 6 0 0 0 6 6h6M15 12l3 3-3 3M6 21v-6"/>',
  undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-4"/>', ban: '<circle cx="12" cy="12" r="9"/><path d="m5.7 5.7 12.6 12.6"/>',
  door: '<path d="M14 3H6v18h8"/><path d="M14 3l6 2v16l-6-2z"/><path d="M11 12h.01"/>', zap: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  link: '<path d="M10 14a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 10a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/>', lock: '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
  send: '<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>', copy: '<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
  cake: '<path d="M4 21v-8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8M2 21h20M4 16c2 0 2-1.5 4-1.5s2 1.5 4 1.5 2-1.5 4-1.5 2 1.5 4 1.5M12 11V7M12 4v.01"/>',
};
export function icon(name, cls = '') { return `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[name] || ''}</svg>`; }

// ---------- Ações delegadas ----------
const actions = {};
export function registerActions(map) { Object.assign(actions, map); }
export function initDelegation() {
  document.addEventListener('click', (ev) => {
    const el = ev.target.closest('[data-action]'); if (!el || el.disabled) return;
    const fn = actions[el.dataset.action]; if (!fn) return;
    if (!(el.type === 'checkbox' || el.type === 'radio')) ev.preventDefault(); closeMenu();
    try { fn(el, ev); } catch (e) { showError(e); }
  });
  document.addEventListener('submit', (ev) => {
    const form = ev.target.closest('form[data-submit]'); if (!form) return;
    ev.preventDefault(); const fn = actions[form.dataset.submit]; if (!fn) return;
    clearErrors(form);
    try { fn(form, readForm(form), ev); } catch (e) { showError(e, form); }
  });
  document.addEventListener('keydown', (ev) => {
    if (ev.key === 'Escape') { if (document.querySelector('.menu')) return closeMenu(); const top = sheets.at(-1); if (top) closeSheet(); }
  });
  // Tooltips para gráficos e elementos com data-tip
  const tip = document.createElement('div'); tip.className = 'tooltip'; tip.setAttribute('role', 'tooltip'); document.body.appendChild(tip);
  const showTip = (el, x, y) => { tip.innerHTML = el.getAttribute('data-tip'); tip.classList.add('show'); const r = tip.getBoundingClientRect(); let left = x + 12, top = y - r.height - 10; if (left + r.width > innerWidth - 8) left = x - r.width - 12; if (top < 8) top = y + 16; tip.style.left = left + 'px'; tip.style.top = top + 'px'; };
  document.addEventListener('pointermove', (ev) => { const el = ev.target.closest?.('[data-tip]'); if (el) showTip(el, ev.clientX, ev.clientY); else tip.classList.remove('show'); });
  document.addEventListener('focusin', (ev) => { const el = ev.target.closest?.('[data-tip]'); if (el) { const r = el.getBoundingClientRect(); showTip(el, r.left + r.width / 2, r.top); } });
  document.addEventListener('focusout', () => tip.classList.remove('show'));
  document.addEventListener('scroll', () => tip.classList.remove('show'), true);
}
export function readForm(form) {
  const data = {};
  for (const el of form.elements) {
    if (!el.name || el.disabled) continue;
    if (el.type === 'checkbox') { if (el.name.endsWith('[]')) { const k = el.name.slice(0, -2); data[k] = data[k] || []; if (el.checked) data[k].push(el.value); } else data[el.name] = el.checked; }
    else if (el.type === 'radio') { if (el.checked) data[el.name] = el.value; }
    else data[el.name] = el.value;
  }
  return data;
}
export function clearErrors(root) { root.querySelectorAll('.err').forEach((e) => e.remove()); root.querySelectorAll('.invalid').forEach((e) => e.classList.remove('invalid')); }
export function showError(e, form) {
  console.error(e);
  const msg = e?.message || String(e);
  if (form && e.field) {
    const input = form.querySelector(`[name="${e.field}"]`) || form.querySelector(`[data-field="${e.field}"]`);
    if (input) { input.classList.add('invalid'); const err = document.createElement('div'); err.className = 'err'; err.setAttribute('role', 'alert'); err.textContent = msg; (input.closest('.field') || input.parentElement).appendChild(err); input.focus?.(); return; }
  }
  toast(msg, 'err');
}

// ---------- Toast ----------
export function toast(msg, kind = 'ok') {
  let box = document.querySelector('.toasts'); if (!box) { box = document.createElement('div'); box.className = 'toasts'; box.setAttribute('aria-live', 'polite'); document.body.appendChild(box); }
  const t = document.createElement('div'); t.className = 'toast' + (kind === 'err' ? ' err' : ''); t.innerHTML = icon(kind === 'err' ? 'alert' : 'checkCircle') + `<span>${esc(msg)}</span>`;
  while (box.children.length >= 2) box.firstChild.remove();
  box.appendChild(t); setTimeout(() => t.remove(), kind === 'err' ? 6000 : 3500);
}

// ---------- Folhas laterais (sheets) ----------
const sheets = [];
export function openSheet({ title, render, wide = false, onMount, id }) {
  const ov = document.createElement('div'); ov.className = 'overlay';
  ov.innerHTML = `<section class="sheet ${wide ? 'wide' : ''}" role="dialog" aria-modal="true" aria-label="${esc(title)}"><header class="sheet-head"><h2></h2><button class="btn ghost icon" data-action="sheet-close" aria-label="Fechar">${icon('x')}</button></header><div class="sheet-content" style="display:flex;flex-direction:column;flex:1;min-height:0"></div></section>`;
  ov.addEventListener('mousedown', (e) => { if (e.target === ov) closeSheet(); });
  document.body.appendChild(ov); document.body.style.overflow = 'hidden';
  const entry = { el: ov, render, onMount, title, id, prevFocus: document.activeElement };
  sheets.push(entry); refreshSheet(entry, true);
  return entry;
}
export function refreshSheet(entry = sheets.at(-1), first = false) {
  if (!entry) return;
  const out = entry.render();
  if (out === null) return closeSheet(entry);
  const title = typeof out === 'object' && out.title ? out.title : entry.title;
  entry.el.querySelector('.sheet-head h2').textContent = title;
  const html = typeof out === 'object' ? out.html : out;
  const box = entry.el.querySelector('.sheet-content');
  const scroll = box.querySelector('.sheet-body')?.scrollTop || 0;
  box.innerHTML = html;
  const body = box.querySelector('.sheet-body'); if (body) body.scrollTop = scroll;
  entry.onMount?.(entry.el);
  if (first) { const f = entry.el.querySelector('[autofocus], .sheet-body input:not([type=hidden]), .sheet-body select, .sheet-body button'); (f || entry.el.querySelector('[data-action=sheet-close]')).focus({ preventScroll: true }); }
}
export function refreshAllSheets() { for (const s of [...sheets]) if (!s.static) refreshSheet(s); }
export function closeSheet(entry = sheets.at(-1)) {
  if (!entry) return; const i = sheets.indexOf(entry); if (i >= 0) sheets.splice(i, 1);
  entry.el.remove(); if (!sheets.length) document.body.style.overflow = '';
  entry.prevFocus?.focus?.({ preventScroll: true });
}
export function closeAllSheets() { while (sheets.length) closeSheet(); }
export function currentSheet() { return sheets.at(-1); }
registerActions({ 'sheet-close': () => closeSheet() });

// ---------- Diálogo de confirmação ----------
export function confirmDialog({ title, message, confirmLabel = 'Confirmar', danger = false, input = null }) {
  return new Promise((resolve) => {
    const ov = document.createElement('div'); ov.className = 'overlay center';
    ov.innerHTML = `<div class="dialog" role="alertdialog" aria-modal="true" aria-labelledby="dlg-t"><div class="d-body"><h2 id="dlg-t" style="margin-bottom:8px">${esc(title)}</h2><p class="muted">${message}</p>${input ? `<div class="field" style="margin-top:12px"><label for="dlg-in">${esc(input.label)}</label><input id="dlg-in" class="input" placeholder="${esc(input.placeholder || '')}"></div>` : ''}</div><div class="d-foot"><button class="btn" data-r="0">Voltar</button><button class="btn ${danger ? 'danger solid' : 'primary'}" data-r="1">${esc(confirmLabel)}</button></div></div>`;
    document.body.appendChild(ov);
    const done = (v) => { ov.remove(); document.removeEventListener('keydown', key, true); resolve(v); };
    const key = (e) => { if (e.key === 'Escape') { e.stopPropagation(); done(false); } };
    document.addEventListener('keydown', key, true);
    ov.addEventListener('click', (e) => { const b = e.target.closest('[data-r]'); if (!b) return; if (b.dataset.r === '1') { if (input) { const v = ov.querySelector('#dlg-in').value.trim(); if (input.required && !v) { ov.querySelector('#dlg-in').classList.add('invalid'); ov.querySelector('#dlg-in').focus(); return; } done(v || true); } else done(true); } else done(false); });
    (ov.querySelector('#dlg-in') || ov.querySelector('[data-r="1"]')).focus();
  });
}

// ---------- Menu contextual ----------
let openMenuEl = null;
export function openMenu(anchor, items) {
  closeMenu();
  const m = document.createElement('div'); m.className = 'menu'; m.setAttribute('role', 'menu');
  m.innerHTML = items.map((it) => it === '-' ? '<hr>' : `<button role="menuitem" class="${it.danger ? 'danger' : ''}" data-action="${it.action}" ${Object.entries(it.data || {}).map(([k, v]) => `data-${k}="${esc(v)}"`).join(' ')}>${icon(it.icon || 'right')}${esc(it.label)}</button>`).join('');
  document.body.appendChild(m);
  const r = anchor.getBoundingClientRect(); const mr = m.getBoundingClientRect();
  let left = Math.min(r.right - mr.width, innerWidth - mr.width - 8); left = Math.max(8, left);
  let top = r.bottom + 4; if (top + mr.height > innerHeight - 8) top = r.top - mr.height - 4;
  m.style.left = left + 'px'; m.style.top = Math.max(8, top) + 'px';
  openMenuEl = m; m.querySelector('button')?.focus();
  setTimeout(() => document.addEventListener('mousedown', outside, true));
  m.addEventListener('keydown', (e) => { const btns = [...m.querySelectorAll('button')]; const i = btns.indexOf(document.activeElement); if (e.key === 'ArrowDown') { e.preventDefault(); btns[(i + 1) % btns.length].focus(); } if (e.key === 'ArrowUp') { e.preventDefault(); btns[(i - 1 + btns.length) % btns.length].focus(); } });
}
function outside(e) { if (openMenuEl && !openMenuEl.contains(e.target)) closeMenu(); }
export function closeMenu() { if (openMenuEl) { openMenuEl.remove(); openMenuEl = null; document.removeEventListener('mousedown', outside, true); } }

// ---------- Fragmentos ----------
export function statusBadge(st) { const s = STATUS[st]; return `<span class="badge ${s.tone}">${esc(s.label)}</span>`; }
export function badge(text, tone = '') { return `<span class="badge ${tone}">${esc(text)}</span>`; }
export function simBadge(text = 'Simulado') { return `<span class="badge sim" title="Resultado demonstrativo — nenhuma mensagem real foi enviada">${esc(text)}</span>`; }
export function empty(title, text, actionHtml = '', ic = 'info') { return `<div class="empty">${icon(ic)}<h3>${esc(title)}</h3><p class="small">${text}</p>${actionHtml ? `<div style="margin-top:12px">${actionHtml}</div>` : ''}</div>`; }
export function field(label, inner, { hint = '', full = false, id = '' } = {}) { return `<div class="field ${full ? 'full' : ''}">${label ? `<label ${id ? `for="${id}"` : ''}>${label}</label>` : ''}${inner}${hint ? `<div class="hint">${hint}</div>` : ''}</div>`; }
export function options(list, selected, { placeholder } = {}) { return (placeholder != null ? `<option value="">${esc(placeholder)}</option>` : '') + list.map((o) => { const [v, l] = Array.isArray(o) ? o : [o.id, o.name || o.label]; return `<option value="${esc(v)}" ${String(v) === String(selected ?? '') ? 'selected' : ''}>${esc(l)}</option>`; }).join(''); }
export function seg(name, list, current, action) { return `<div class="segmented" role="group">${list.map(([v, l]) => `<button type="button" aria-pressed="${v === current}" data-action="${action}" data-value="${esc(v)}" data-name="${esc(name)}">${esc(l)}</button>`).join('')}</div>`; }
export function tabs(list, current, action) { return `<div class="tabs" role="tablist">${list.map(([v, l]) => `<button role="tab" aria-selected="${v === current}" data-action="${action}" data-value="${esc(v)}">${esc(l)}</button>`).join('')}</div>`; }
export function deltaBadge(v, { suffix = '', pp = false } = {}) {
  if (!v) return '';
  if (!v.calculable && !pp) return `<span class="delta flat" title="O período anterior é zero">variação não calculável</span>`;
  const cls = v.dir === 'flat' ? 'flat' : v.good ? 'good' : 'bad';
  const arrow = v.dir === 'up' ? '▲' : v.dir === 'down' ? '▼' : '■';
  const val = pp ? `${v.pp > 0 ? '+' : ''}${v.pp.toLocaleString('pt-BR', { maximumFractionDigits: 1 })} p.p.` : `${v.pct > 0 ? '+' : ''}${v.pct.toLocaleString('pt-BR', { maximumFractionDigits: 1 })}%`;
  return `<span class="delta ${cls}" aria-label="Variação ${val}">${arrow} ${val}${suffix}</span>`;
}
