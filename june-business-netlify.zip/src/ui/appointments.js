// Componentes de atendimento compartilhados: card, detalhes, novo agendamento,
// reagendamento, Finalização Expressa e resolução de pendências.
import { S, ui, go, now, today } from './ctx.js';
import { esc, money, moneyInput, parseMoney, fmtDate, fmtDateTime, fmtPhone, maskPhoneInput, normalizePhone, timeToMin, minToTime, addDays, uid, fmtLongDate, initials } from '../util.js';
import { STATUS, SETTLEMENT, PAYMENT_METHODS, ORIGINS, ACTIVE_STATUSES } from '../domain/rules.js';
import { client, service, professional, user, byId, hasPerm, currentUser, findByPhone, freeSlots, usablePackages, packageRemaining, saleTotal, salePaid, checkConflict } from '../services/core.js';
import * as op from '../services/operations.js';
import { icon, registerActions, openSheet, closeSheet, refreshSheet, toast, confirmDialog, openMenu, statusBadge, badge, field, options, showError, simBadge } from './dom.js';
import { clientStats } from '../metrics/metrics.js';
import { waLink } from '../adapters/messaging.js';
import { renderTemplate } from '../services/core.js';
import { templateVars } from '../services/crm.js';

const endTime = (a) => minToTime(timeToMin(a.start) + a.duration);
export const isPast = (a) => `${a.date}T${endTime(a)}` <= now();
export const isPendingOp = (a) => ['agendado', 'confirmado', 'chegou', 'em_atendimento'].includes(a.status) && isPast(a);
const isNow = (a) => a.date === today() && ['chegou', 'em_atendimento'].includes(a.status);
const methodLabel = (m) => PAYMENT_METHODS.find((x) => x.id === m)?.label || m || '—';
export { methodLabel };

// ---------- Card de atendimento ----------
export function apptCard(a, { showDate = false } = {}) {
  const s = S(); const c = client(s, a.clientId); const sv = service(s, a.serviceId); const p = professional(s, a.professionalId);
  const final = STATUS[a.status].final; const pending = isPendingOp(a);
  let primary = [];
  const canFinish = hasPerm(s, 'atendimento.finalizar');
  if (pending) primary = [['Finalizar', 'appt-checkout', 'accent'], ['Faltou', 'appt-noshow', '']];
  else if (a.status === 'agendado') primary = [['Confirmar', 'appt-confirm', ''], ['Chegou', 'appt-arrived', '']];
  else if (a.status === 'confirmado') primary = [['Chegou', 'appt-arrived', ''], ['Finalizar', 'appt-checkout', 'accent']];
  else if (a.status === 'chegou') primary = [['Iniciar', 'appt-start', ''], ['Finalizar', 'appt-checkout', 'accent']];
  else if (a.status === 'em_atendimento') primary = [['Finalizar', 'appt-checkout', 'accent']];
  else if (a.status === 'realizado' && a.checkout?.saleId) { const sl = byId(s.sales, a.checkout.saleId); if (sl && saleTotal(sl) > salePaid(s, sl.id) && hasPerm(s, 'pagamentos.registrar')) primary = [['Receber saldo', 'appt-receive', '']]; }
  if (!canFinish) primary = primary.filter((x) => x[1] !== 'appt-checkout');
  const pkgTag = a.clientPackageId && !final ? `<span class="badge accent" title="Pacote vinculado">${icon('box')}Pacote</span>` : '';
  const settle = a.checkout ? { pago: ['Pago', 'good'], parcial: ['Parcial', 'warn'], pendente: ['A receber', 'bad'], pacote: ['Pacote', 'accent'], cortesia: ['Cortesia', 'muted'] }[a.checkout.settlement] : null;
  const priceTxt = a.checkout ? (a.checkout.settlement === 'pacote' ? 'Sessão de pacote' : money(a.checkout.realizedValue + (a.checkout.extras?.length ? extrasTotal(a) : 0))) : money(a.price);
  return `<article class="appt ${final ? 'is-final' : ''} ${pending ? 'is-pending' : ''} ${isNow(a) ? 'is-now' : ''}" aria-label="${esc(a.start + ' ' + (c?.name || ''))}">
    <div class="a-time"><strong>${a.start}</strong><span>${a.duration} min</span>${showDate ? `<span>${fmtDate(a.date).slice(0, 5)}</span>` : ''}</div>
    <div class="a-body">
      <div class="a-name">${esc(c?.name || 'Cliente removida')}</div>
      <div class="a-service">${esc(sv?.name || '')}</div>
      <div class="a-pro"><span class="dot" style="background:${p?.color}"></span><span class="ellipsis">${esc(p?.name || '')}</span>${pkgTag}</div>
      <div class="a-meta"><span class="a-price">${priceTxt}</span><span class="row" style="gap:4px">${pending ? badge('Sem status final', 'warn') : ''}${settle ? badge(settle[0], settle[1]) : ''}${statusBadge(a.status)}</span></div>
      <div class="a-actions">
        ${primary.map(([l, act, cls]) => `<button class="btn sm ${cls}" data-action="${act}" data-id="${a.id}">${l}</button>`).join('')}
        <span class="spacer"></span>
        <button class="btn sm ghost" data-action="appt-open" data-id="${a.id}">Detalhes</button>
        ${!final || a.status === 'falta' ? `<button class="btn sm ghost icon" data-action="appt-menu" data-id="${a.id}" aria-label="Mais ações">${icon('more')}</button>` : ''}
      </div>
    </div></article>`;
}
function extrasTotal(a) { const s = S(); const sl = byId(s.sales, a.checkout.saleId); if (!sl) return 0; return sl.items.slice(1).reduce((t, i) => t + i.unitPrice * i.qty - (i.discount || 0), 0); }

function menuFor(a) {
  const items = []; const past = `${a.date}T${a.start}` <= now();
  if (a.status === 'agendado') items.push({ label: 'Confirmar presença', action: 'appt-confirm', icon: 'check', data: { id: a.id } });
  if (['agendado', 'confirmado'].includes(a.status)) items.push({ label: 'Registrar chegada', action: 'appt-arrived', icon: 'door', data: { id: a.id } });
  if (['confirmado', 'chegou'].includes(a.status)) items.push({ label: 'Iniciar atendimento', action: 'appt-start', icon: 'play', data: { id: a.id } });
  if (ACTIVE_STATUSES.includes(a.status) && hasPerm(S(), 'atendimento.finalizar')) items.push({ label: 'Finalização Expressa', action: 'appt-checkout', icon: 'checkCircle', data: { id: a.id } });
  const c = client(S(), a.clientId);
  if (c?.phone) items.push({ label: 'Abrir conversa no WhatsApp', action: 'appt-wa', icon: 'message', data: { id: a.id } });
  items.push('-');
  if ((ACTIVE_STATUSES.includes(a.status) && a.status !== 'em_atendimento') || a.status === 'falta') items.push({ label: 'Reagendar', action: 'appt-reschedule', icon: 'calendar', data: { id: a.id } });
  if (['agendado', 'confirmado'].includes(a.status) && past) items.push({ label: 'Cliente faltou', action: 'appt-noshow', icon: 'ban', data: { id: a.id } });
  if (['agendado', 'confirmado', 'chegou'].includes(a.status)) items.push({ label: 'Cancelar agendamento', action: 'appt-cancel', icon: 'x', danger: true, data: { id: a.id } });
  return items;
}

const doStatus = (id, to, okMsg, extra) => { op.changeStatus(id, to, extra); toast(okMsg); };
registerActions({
  'appt-menu': (el) => openMenu(el, menuFor(byId(S().appointments, el.dataset.id))),
  'appt-open': (el) => openApptDetails(el.dataset.id),
  'appt-confirm': (el) => doStatus(el.dataset.id, 'confirmado', 'Presença confirmada.'),
  'appt-arrived': (el) => doStatus(el.dataset.id, 'chegou', 'Chegada registrada.'),
  'appt-start': (el) => doStatus(el.dataset.id, 'em_atendimento', 'Atendimento iniciado.'),
  'appt-noshow': async (el) => { const a = byId(S().appointments, el.dataset.id); const c = client(S(), a.clientId); if (await confirmDialog({ title: 'Registrar falta?', message: `${esc(c.name)} não compareceu às ${a.start}. Nenhuma venda será gerada.`, confirmLabel: 'Registrar falta', danger: true })) try { doStatus(a.id, 'falta', 'Falta registrada.'); } catch (e) { showError(e); } },
  'appt-cancel': async (el) => { const a = byId(S().appointments, el.dataset.id); const pol = S().org.cancellationPolicy; const r = await confirmDialog({ title: 'Cancelar agendamento?', message: `O horário será liberado e lembretes pendentes serão cancelados. Nenhuma venda é gerada${pol.enabled ? '. Política de cancelamento ativa: a taxa, se houver, deve ser lançada como venda avulsa.' : '.'}`, confirmLabel: 'Cancelar agendamento', danger: true, input: { label: 'Motivo (opcional)', placeholder: 'Ex.: imprevisto pessoal' } }); if (r) try { doStatus(a.id, 'cancelado', 'Agendamento cancelado.', { reason: typeof r === 'string' ? r : '' }); } catch (e) { showError(e); } },
  'appt-reschedule': (el) => openReschedule(el.dataset.id),
  'appt-checkout': (el) => openCheckout(el.dataset.id),
  'appt-receive': (el) => { const a = byId(S().appointments, el.dataset.id); import('./screens/financeiro.js').then((m) => m.openReceive(a.checkout.saleId)); },
  'appt-wa': (el) => { const s = S(); const a = byId(s.appointments, el.dataset.id); const c = client(s, a.clientId); const t = renderTemplate(byId(s.templates, 'tpl_lembrete')?.text || '', templateVars(s, c, a)); const lk = document.createElement('a'); lk.href = waLink(c.phone, t); lk.target = '_blank'; lk.rel = 'noopener'; document.body.appendChild(lk); lk.click(); lk.remove(); toast('Conversa aberta no WhatsApp. Ela não é registrada como mensagem enviada.'); },
});

// ---------- Detalhes do atendimento ----------
export function openApptDetails(id) {
  openSheet({ title: 'Detalhes do atendimento', render: () => {
    const s = S(); const a = byId(s.appointments, id); if (!a) return null;
    const c = client(s, a.clientId); const sv = service(s, a.serviceId); const p = professional(s, a.professionalId);
    const st = clientStats(s, c.id); const sl = a.checkout?.saleId ? byId(s.sales, a.checkout.saleId) : null;
    const pays = sl ? s.payments.filter((x) => x.saleId === sl.id) : [];
    const cp = a.clientPackageId ? byId(s.clientPackages, a.clientPackageId) : null;
    const msgs = s.communications.filter((m) => m.appointmentId === a.id);
    const execs = s.journeyExecutions.filter((e) => e.appointmentId === a.id);
    const res = a.resourceId ? byId(s.resources, a.resourceId) : null;
    const actions = menuFor(a).filter((x) => x !== '-');
    return `<div class="sheet-body stack">
      <div class="row-between"><div class="row" style="gap:12px"><div class="avatar lg">${initials(c.name)}</div><div class="grow"><div class="strong" style="font-size:16px">${esc(c.name)}</div><div class="small muted">${fmtPhone(c.phone)} · ${st.visitCount} visita(s)</div></div></div>${statusBadge(a.status)}</div>
      ${isPendingOp(a) ? `<div class="callout warn">${icon('alert')}<div>O horário já passou e o atendimento está sem status final. Registre o que aconteceu — nada é concluído automaticamente.</div></div>` : ''}
      <dl class="kv card card-pad" style="margin:0">
        <dt>Serviço</dt><dd>${esc(sv.name)}</dd>
        <dt>Profissional</dt><dd>${esc(p.name)}</dd>
        <dt>Data e horário</dt><dd>${fmtDate(a.date)} · ${a.start}–${endTime(a)}</dd>
        <dt>Valor previsto</dt><dd>${money(a.price)}${a.price !== sv.price ? ` <span class="subtle small">(tabela atual ${money(sv.price)})</span>` : ''}</dd>
        ${res ? `<dt>Recurso</dt><dd>${esc(res.name)}</dd>` : ''}
        ${cp ? `<dt>Pacote</dt><dd>${esc(byId(s.packages, cp.packageId)?.name)} · ${packageRemaining(s, cp)} restante(s)</dd>` : ''}
        <dt>Origem</dt><dd>${esc(a.origin || '—')}</dd>
        ${a.rescheduledFrom ? `<dt>Reagendado de</dt><dd><button class="btn sm ghost" data-action="appt-open" data-id="${a.rescheduledFrom}">Ver original</button></dd>` : ''}
        ${a.rescheduledTo ? `<dt>Novo horário</dt><dd><button class="btn sm ghost" data-action="appt-open" data-id="${a.rescheduledTo}">Ver novo agendamento</button></dd>` : ''}
      </dl>
      ${a.checkout ? `<div class="card card-pad stack-sm"><div class="row-between"><h3>Finalização</h3>${badge(SETTLEMENT[a.checkout.settlement], 'accent')}</div>
        <dl class="kv"><dt>Valor realizado</dt><dd>${a.checkout.settlement === 'pacote' ? 'Sessão de pacote (sem nova venda)' : money(a.checkout.realizedValue)}</dd>
        ${sl ? `<dt>Venda</dt><dd>${money(saleTotal(sl))}</dd><dt>Recebido</dt><dd>${money(salePaid(s, sl.id))}</dd><dt>Pendente</dt><dd>${money(Math.max(0, saleTotal(sl) - salePaid(s, sl.id)))}</dd>` : ''}
        <dt>Registrado por</dt><dd>${esc(user(s, a.checkout.by)?.name || '—')} · ${fmtDateTime(a.checkout.at)}</dd></dl>
        ${pays.length ? `<div class="small muted">${pays.map((x) => `${fmtDate(x.date)} · ${x.kind === 'estorno' ? 'Estorno' : methodLabel(x.method)} · ${money(x.amount)}`).join('<br>')}</div>` : ''}
        ${sl && saleTotal(sl) > salePaid(s, sl.id) && hasPerm(s, 'pagamentos.registrar') ? `<button class="btn sm" data-action="appt-receive" data-id="${a.id}">${icon('cash')}Receber saldo</button>` : ''}
      </div>` : ''}
      <div class="field"><label for="appt-notes">Observação administrativa</label><textarea id="appt-notes" class="textarea" placeholder="Informações operacionais (sem dados de saúde)">${esc(a.notes)}</textarea><div class="hint">Não registre dados clínicos ou de saúde.</div><div><button class="btn sm" data-action="appt-save-notes" data-id="${a.id}">Salvar observação</button></div></div>
      <div><h3 style="margin-bottom:8px">Histórico</h3><ol class="timeline">${a.history.map((h) => `<li><span class="t-dot ${STATUS[h.to]?.tone === 'good' ? 'good' : STATUS[h.to]?.tone === 'bad' ? 'bad' : 'info'}">${icon('clock')}</span><div><div class="t-text">${esc(STATUS[h.to]?.label || h.to)}${h.reason ? ` — ${esc(h.reason)}` : ''}${h.note ? ` <span class="muted">(${esc(h.note)})</span>` : ''}</div><div class="t-when">${fmtDateTime(h.at)} · ${esc(user(s, h.by)?.name || 'Sistema')}</div></div></li>`).join('')}</ol></div>
      <div><h3 style="margin-bottom:8px">Comunicações deste atendimento</h3>${msgs.length || execs.length ? `<div class="stack-sm small">${msgs.map((m) => `<div class="row-between"><span>${esc(byId(s.journeys, m.journeyId)?.name || 'Mensagem')} · ${fmtDateTime(m.at)}</span>${simBadge(m.status === 'bloqueada' ? 'Bloqueada' : m.status === 'falhou' ? 'Falhou (sim.)' : 'Entregue (sim.)')}</div>`).join('')}${execs.filter((e) => e.status === 'pendente').map((e) => `<div class="row-between"><span>${esc(byId(s.journeys, e.journeyId)?.name)} · previsto ${fmtDateTime(e.dueAt)}</span>${badge('Na fila', 'neutral')}</div>`).join('')}</div>` : '<p class="small muted">Nenhuma comunicação registrada.</p>'}</div>
      <button class="btn ghost" data-action="go-client" data-id="${c.id}">${icon('user')}Abrir perfil da cliente</button>
    </div>
    ${actions.length ? `<div class="sheet-foot" style="flex-wrap:wrap;justify-content:flex-start">${actions.map((it) => `<button class="btn sm ${it.danger ? 'danger' : it.action === 'appt-checkout' ? 'accent' : ''}" data-action="${it.action}" data-id="${a.id}">${icon(it.icon)}${esc(it.label)}</button>`).join('')}</div>` : ''}`;
  } });
}
registerActions({
  'appt-save-notes': (el) => { const v = el.closest('.field').querySelector('textarea').value; op.updateAppointmentNotes(el.dataset.id, v); toast('Observação salva.'); },
  'go-client': (el) => { closeAllAndGo('/clientes/' + el.dataset.id); },
});
function closeAllAndGo(path) { import('./dom.js').then((m) => { m.closeAllSheets(); go(path); }); }

// ---------- Novo agendamento ----------
export function openNewAppointment(pre = {}) {
  const s = S(); const u = currentUser(s);
  const draft = {
    startedAt: Date.now(), phone: '', name: '', clientId: pre.clientId || null, matchMode: null, serviceId: pre.serviceId || '', professionalId: pre.professionalId || (u.role === 'profissional' ? u.professionalId : ''),
    date: pre.date || today(), start: pre.start || '', price: '', origin: '', notes: '', clientPackageId: '', resourceId: undefined, showMore: false,
  };
  if (draft.clientId) { const c = client(s, draft.clientId); draft.phone = fmtPhone(c.phone); draft.name = c.name; draft.matchMode = 'existing'; }
  openSheet({ title: 'Novo agendamento', render: () => newApptHtml(draft), onMount: (root) => bindNewAppt(root, draft) });
}
function svcOptions(s, selected) {
  const cats = s.org.categories; return '<option value="">Escolha o serviço</option>' + cats.map((cat) => { const list = s.services.filter((x) => x.active && x.category === cat); return list.length ? `<optgroup label="${esc(cat)}">${list.map((x) => `<option value="${x.id}" ${x.id === selected ? 'selected' : ''}>${esc(x.name)} — ${money(x.price)} · ${x.duration} min</option>`).join('')}</optgroup>` : ''; }).join('');
}
function newApptHtml(d) {
  const s = S(); const sv = d.serviceId ? service(s, d.serviceId) : null; const u = currentUser(s);
  const pros = s.professionals.filter((p) => p.active && (!sv || sv.professionalIds.includes(p.id)) && (hasPerm(s, 'agenda.ver_todas') || p.id === u.professionalId));
  return `<form class="sheet-body stack" data-submit="appt-create" novalidate id="new-appt">
    <div class="form-grid">
      ${field('Telefone / WhatsApp *', `<input class="input" name="phone" id="na-phone" inputmode="tel" autocomplete="off" placeholder="(11) 90000-0000" value="${esc(d.phone)}" ${d.clientId && d.matchMode === 'existing' && d.lockClient ? 'readonly' : ''}>`, { id: 'na-phone' })}
      ${field('Nome da cliente *', `<input class="input" name="clientName" id="na-name" autocomplete="off" placeholder="Nome e sobrenome" value="${esc(d.name)}" ${d.matchMode === 'existing' ? 'readonly' : ''}>`, { id: 'na-name' })}
      <div class="full" id="na-matches">${matchesHtml(d)}</div>
      ${field('Serviço *', `<select class="select" name="serviceId" id="na-service">${svcOptions(s, d.serviceId)}</select>`, { full: true, id: 'na-service' })}
      ${field('Profissional *', `<select class="select" name="professionalId" id="na-pro">${options(pros, d.professionalId, { placeholder: sv ? 'Escolha a profissional' : 'Escolha o serviço primeiro' })}</select>`, { id: 'na-pro' })}
      ${field('Data *', `<input class="input" type="date" name="date" id="na-date" value="${d.date}" min="${today()}">`, { id: 'na-date' })}
      <div class="full field" data-field="start"><span class="label">Horário *</span><div id="na-slots">${slotsHtml(d)}</div></div>
    </div>
    <details ${d.showMore ? 'open' : ''} id="na-more"><summary class="small strong" style="cursor:pointer;padding:6px 0">Opções adicionais <span class="subtle">(preço personalizado, origem, pacote, sala, observação)</span></summary>
      <div class="form-grid" style="margin-top:8px">
        ${field('Preço personalizado', `<input class="input" name="price" inputmode="decimal" placeholder="${sv ? moneyInput(sv.price) : '0,00'}" value="${esc(d.price)}">`, { hint: 'Deixe vazio para usar o preço padrão.' })}
        ${field('Origem comercial', `<select class="select" name="origin">${options(ORIGINS.map((o) => [o, o]), d.origin, { placeholder: 'Automática' })}</select>`)}
        <div class="full" id="na-pkg">${pkgHtml(d)}</div>
        ${field('Sala ou recurso', `<select class="select" name="resourceId" id="na-res">${options(s.resources, d.resourceId === undefined ? sv?.resourceId || '' : d.resourceId, { placeholder: 'Nenhum' })}</select>`, { hint: sv?.resourceId ? 'Sugerido pelo serviço.' : '' })}
        ${field('Observação administrativa', `<input class="input" name="notes" value="${esc(d.notes)}" placeholder="Sem dados de saúde">`)}
      </div></details>
    <div class="summary small" id="na-summary">${summaryHtml(d)}</div>
  </form>
  <div class="sheet-foot"><button class="btn" data-action="sheet-close">Cancelar</button><button class="btn primary" type="submit" form="new-appt">${icon('check')}Salvar agendamento</button></div>`;
}
function matchesHtml(d) {
  const s = S(); if (d.lockClient) return '';
  const norm = normalizePhone(d.phone); if (!norm) return d.phone.replace(/\D/g, '').length >= 3 ? '<p class="small subtle">Digite DDD + número para buscar o cadastro.</p>' : '';
  const m = findByPhone(s, d.phone);
  if (!m.length) return `<div class="callout info">${icon('user')}<div>Nenhum cadastro com este telefone. <b>Uma nova cliente será criada automaticamente</b> ao salvar.</div></div>`;
  return `<div class="stack-sm"><span class="label">Encontramos ${m.length === 1 ? 'um cadastro' : m.length + ' cadastros'} com este telefone. Confirme quem é:</span>
    <div class="choice-grid">${m.map((c) => { const st = clientStats(s, c.id); return `<button type="button" class="choice" aria-pressed="${d.clientId === c.id}" data-action="na-pick" data-id="${c.id}"><span class="strong">${esc(c.name)}</span><small>${st.lastVisit ? 'Última visita ' + fmtDate(st.lastVisit) : 'Sem visitas'} · ${st.visitCount} atend.</small></button>`; }).join('')}
    <button type="button" class="choice" aria-pressed="${d.matchMode === 'new'}" data-action="na-pick" data-id=""><span class="strong">Outra pessoa</span><small>Criar novo cadastro com este telefone</small></button></div>
    ${m.length > 1 ? '<p class="xs subtle">Telefone compartilhado: os cadastros não são mesclados automaticamente.</p>' : ''}</div>`;
}
function slotsHtml(d) {
  const s = S(); if (!d.serviceId || !d.professionalId || !d.date) return '<p class="small subtle">Escolha serviço, profissional e data para ver os horários livres.</p>';
  const sv = service(s, d.serviceId); const res = d.resourceId === undefined ? sv.resourceId : d.resourceId;
  let slots = freeSlots(s, { professionalId: d.professionalId, date: d.date, duration: sv.duration, resourceId: res, step: s.org.slotStep || 15 });
  if (d.date === today()) slots = slots.filter((t) => t >= S().settings.demoTime);
  const p = professional(s, d.professionalId);
  if (!slots.length) return `<div class="callout warn">${icon('alert')}<div>Sem horários livres para ${esc(p.name)} neste dia (jornada, intervalos, bloqueios, sala e agendamentos já considerados). Tente outra data ou profissional.</div></div>`;
  if (d.start && !slots.includes(d.start)) { const why = checkConflict(s, { professionalId: d.professionalId, date: d.date, start: d.start, duration: sv.duration, resourceId: res }); if (why) d.start = ''; }
  return `<div class="chips" role="group" aria-label="Horários livres">${slots.map((t) => `<button type="button" class="chip" aria-pressed="${t === d.start}" data-action="na-slot" data-t="${t}">${t}</button>`).join('')}</div><p class="xs subtle" style="margin-top:6px">${slots.length} horários livres · duração ${sv.duration} min</p>`;
}
function pkgHtml(d) {
  const s = S(); if (!d.clientId || !d.serviceId) return '';
  const list = usablePackages(s, d.clientId, d.serviceId, d.date);
  if (!list.length) return '';
  return field('Pacote vinculado', `<select class="select" name="clientPackageId">${options(list.map((cp) => [cp.id, `${byId(s.packages, cp.packageId).name} — ${packageRemaining(s, cp, d.serviceId)} sessão(ões), vence ${fmtDate(cp.expiresAt)}`]), d.clientPackageId, { placeholder: 'Não usar pacote' })}</select>`, { full: true, hint: 'A sessão só é consumida na Finalização Expressa.' });
}
function summaryHtml(d) {
  const s = S(); const sv = d.serviceId ? service(s, d.serviceId) : null; const p = d.professionalId ? professional(s, d.professionalId) : null;
  const price = d.price ? parseMoney(d.price) : sv?.price;
  const who = d.matchMode === 'existing' ? esc(d.name) : d.name ? `${esc(d.name)} <span class="badge info">novo cadastro</span>` : '<span class="subtle">cliente</span>';
  return `<div class="strong" style="margin-bottom:4px">Resumo</div>${who} · ${sv ? esc(sv.name) : '<span class="subtle">serviço</span>'} · ${p ? esc(p.name) : '<span class="subtle">profissional</span>'}<br>${fmtDate(d.date)} ${d.start ? 'às ' + d.start : ''} · ${price != null && !isNaN(price) ? money(price) : '—'}${sv ? ` · ${sv.duration} min` : ''}`;
}
function bindNewAppt(root, d) {
  const $ = (sel) => root.querySelector(sel);
  const upd = (...regions) => { for (const r of regions) { if (r === 'matches') $('#na-matches').innerHTML = matchesHtml(d); if (r === 'slots') $('#na-slots').innerHTML = slotsHtml(d); if (r === 'pkg') $('#na-pkg').innerHTML = pkgHtml(d); if (r === 'summary') $('#na-summary').innerHTML = summaryHtml(d); } };
  $('#na-phone').addEventListener('input', (e) => {
    e.target.value = maskPhoneInput(e.target.value); d.phone = e.target.value;
    const m = findByPhone(S(), d.phone);
    if (m.length === 1 && d.matchMode !== 'new') { /* sugere, mas exige confirmação */ }
    if (!m.some((c) => c.id === d.clientId)) { if (d.matchMode === 'existing') { d.name = ''; $('#na-name').value = ''; } d.clientId = null; d.matchMode = m.length ? null : 'new'; $('#na-name').readOnly = false; }
    upd('matches', 'pkg', 'summary');
  });
  $('#na-name').addEventListener('input', (e) => { d.name = e.target.value; upd('summary'); });
  $('#na-service').addEventListener('change', (e) => { d.serviceId = e.target.value; d.resourceId = undefined; const sv = service(S(), d.serviceId); if (sv && d.professionalId && !sv.professionalIds.includes(d.professionalId)) d.professionalId = ''; if (sv && sv.professionalIds.length === 1) d.professionalId = sv.professionalIds[0]; d.start = ''; refreshSheet(); });
  $('#na-pro').addEventListener('change', (e) => { d.professionalId = e.target.value; upd('slots', 'summary'); });
  $('#na-date').addEventListener('change', (e) => { d.date = e.target.value || today(); upd('slots', 'pkg', 'summary'); });
  $('#na-res')?.addEventListener('change', (e) => { d.resourceId = e.target.value; upd('slots'); });
  root.querySelector('[name=price]')?.addEventListener('input', (e) => { d.price = e.target.value; upd('summary'); });
  root.querySelector('[name=origin]')?.addEventListener('change', (e) => { d.origin = e.target.value; });
  root.querySelector('[name=notes]')?.addEventListener('input', (e) => { d.notes = e.target.value; });
  $('#na-more').addEventListener('toggle', (e) => { d.showMore = e.target.open; });
  root.addEventListener('change', (e) => { if (e.target.name === 'clientPackageId') d.clientPackageId = e.target.value; });
  root._d = d;
}
registerActions({
  'na-pick': (el) => { const d = findDraft(el.closest('.overlay')); const id = el.dataset.id; if (id) { const c = client(S(), id); d.clientId = id; d.name = c.name; d.matchMode = 'existing'; } else { d.clientId = null; d.matchMode = 'new'; d.name = ''; } refreshSheet(); },
  'na-slot': (el) => { const d = findDraft(el.closest('.overlay')); d.start = el.dataset.t; el.closest('.chips').querySelectorAll('.chip').forEach((b) => b.setAttribute('aria-pressed', b === el)); el.closest('.overlay').querySelector('#na-summary').innerHTML = summaryHtml(d); },
  'appt-create': (form, data) => {
    const d = findDraft(form.closest('.overlay'));
    if (!normalizePhone(d.phone)) throw Object.assign(new Error('Informe um telefone válido com DDD.'), { field: 'phone' });
    if (!d.clientId && findByPhone(S(), d.phone).length && d.matchMode !== 'new') throw Object.assign(new Error('Confirme se é uma das clientes encontradas ou “Outra pessoa”.'), { field: 'phone' });
    if (!d.clientId && !d.name.trim()) throw Object.assign(new Error('Informe o nome da cliente.'), { field: 'clientName' });
    if (!d.start) throw Object.assign(new Error('Escolha um horário livre.'), { field: 'start' });
    const price = d.price ? parseMoney(d.price) : null; if (d.price && isNaN(price)) throw Object.assign(new Error('Preço inválido.'), { field: 'price' });
    const r = op.createAppointment({ clientId: d.clientId, clientName: d.name, phone: d.phone, serviceId: d.serviceId, professionalId: d.professionalId, date: d.date, start: d.start, price, origin: d.origin || undefined, notes: d.notes, clientPackageId: d.clientPackageId || null, resourceId: d.resourceId === undefined ? undefined : d.resourceId, _startedAt: d.startedAt });
    closeSheet();
    toast(r.createdClient ? `Agendamento salvo. Cadastro de ${r.client.name.split(' ')[0]} criado automaticamente.` : 'Agendamento salvo.');
  },
});
function findDraft(overlay) { return overlay._d; }

// ---------- Reagendamento ----------
export function openReschedule(id) {
  const s = S(); const a = byId(s.appointments, id);
  const d = { date: a.date < today() ? today() : a.date, start: '', professionalId: a.professionalId };
  openSheet({ title: 'Reagendar', render: () => {
    const s2 = S(); const sv = service(s2, a.serviceId); const c = client(s2, a.clientId);
    let slots = freeSlots(s2, { professionalId: d.professionalId, date: d.date, duration: a.duration, resourceId: a.resourceId, ignoreId: a.id });
    if (d.date === today()) slots = slots.filter((t) => t >= s2.settings.demoTime);
    return `<form class="sheet-body stack" data-submit="appt-resched" data-id="${a.id}" id="resched">
      <div class="callout info">${icon('info')}<div>${esc(c.name)} · ${esc(sv.name)}<br><span class="small">Horário atual: ${fmtDate(a.date)} às ${a.start}. O registro original é preservado como “Reagendado”, com vínculo ao novo horário.</span></div></div>
      <div class="form-grid">
        ${field('Profissional', `<select class="select" name="professionalId" data-rs="pro">${options(s2.professionals.filter((p) => p.active && sv.professionalIds.includes(p.id)), d.professionalId)}</select>`)}
        ${field('Nova data', `<input class="input" type="date" name="date" value="${d.date}" min="${today()}" data-rs="date">`)}
      </div>
      <div class="field" data-field="start"><span class="label">Novo horário</span>${slots.length ? `<div class="chips">${slots.map((t) => `<button type="button" class="chip" aria-pressed="${t === d.start}" data-action="rs-slot" data-t="${t}">${t}</button>`).join('')}</div>` : `<div class="callout warn">${icon('alert')}<div>Sem horários livres nesta data.</div></div>`}</div>
    </form><div class="sheet-foot"><button class="btn" data-action="sheet-close">Voltar</button><button class="btn primary" type="submit" form="resched">Confirmar novo horário</button></div>`;
  }, onMount: (root) => { root._rs = d; root.querySelectorAll('[data-rs]').forEach((el) => el.addEventListener('change', () => { if (el.dataset.rs === 'date') d.date = el.value; else d.professionalId = el.value; d.start = ''; refreshSheet(); })); } });
}
registerActions({
  'rs-slot': (el) => { const d = el.closest('.overlay')._rs; d.start = el.dataset.t; el.closest('.chips').querySelectorAll('.chip').forEach((b) => b.setAttribute('aria-pressed', b === el)); },
  'appt-resched': (form) => { const d = form.closest('.overlay')._rs; if (!d.start) throw Object.assign(new Error('Escolha o novo horário.'), { field: 'start' }); op.reschedule(form.dataset.id, { date: d.date, start: d.start, professionalId: d.professionalId }); closeSheet(); toast(`Reagendado para ${fmtDate(d.date)} às ${d.start}.`); },
});

// ---------- Finalização Expressa ----------
export function openCheckout(id) {
  const s = S(); const a = byId(s.appointments, id); const u = currentUser(s);
  if (a.checkout) { toast('Este atendimento já foi finalizado.', 'err'); return; }
  const pkgs = usablePackages(s, a.clientId, a.serviceId, a.date);
  const d = { realized: a.price, extras: [], settlement: (a.clientPackageId && pkgs.some((p) => p.id === a.clientPackageId)) ? 'pacote' : 'pago', method: 'pix', amount: '', pkgId: a.clientPackageId || pkgs[0]?.id || '', authorizedBy: hasPerm(s, 'estornos.autorizar') ? u.id : '', key: uid('chk'), startedAt: Date.now(), step: 'form', addingExtra: false };
  openSheet({ title: 'Finalização Expressa', render: () => checkoutHtml(a.id, d), onMount: (root) => bindCheckout(root, a.id, d) });
}
function checkoutCalc(s, a, d) {
  const extrasTot = d.extras.reduce((t, x) => t + x.price, 0);
  if (d.settlement === 'pacote') return { sold: extrasTot, received: extrasTot, pending: 0, total: extrasTot };
  if (d.settlement === 'cortesia') return { sold: 0, received: 0, pending: 0, total: 0 };
  const total = Math.max(0, (isNaN(d.realized) ? 0 : d.realized)) + extrasTot;
  const amt = parseMoney(d.amount);
  const received = d.settlement === 'pago' ? total : d.settlement === 'parcial' ? (isNaN(amt) ? 0 : amt) : 0;
  return { sold: total, received, pending: Math.max(0, total - received), total };
}
function checkoutHtml(id, d) {
  const s = S(); const a = byId(s.appointments, id); if (!a) return null; if (a.checkout && d.step !== 'done' && !d.submitting) return null;
  if (d.submitting && d.step !== 'done') return '<div class="sheet-body"><p class="muted">Registrando…</p></div>';
  const c = client(s, a.clientId); const sv = service(s, a.serviceId); const p = professional(s, a.professionalId);
  if (d.step === 'done') return `<div class="sheet-body stack" style="align-items:center;text-align:center;padding-top:40px"><div style="width:56px;height:56px;border-radius:50%;background:var(--good-bg);color:var(--good);display:grid;place-items:center">${icon('check')}</div><h2>Atendimento finalizado</h2><p class="muted">${esc(c.name)} · ${esc(sv.name)}</p><div class="summary" style="width:100%;text-align:left">${d.doneSummary}</div><p class="small muted">Histórico da cliente, financeiro, pacotes, métricas e segmentos já foram atualizados.</p></div><div class="sheet-foot"><button class="btn" data-action="go-client" data-id="${c.id}">Ver cliente</button><button class="btn primary" data-action="sheet-close">Concluir</button></div>`;
  const pkgs = usablePackages(s, a.clientId, a.serviceId, a.date);
  const expired = s.clientPackages.filter((cp) => cp.clientId === a.clientId && cp.serviceIds.includes(a.serviceId) && (cp.expiresAt < a.date) && packageRemaining(s, cp, a.serviceId) > 0);
  const calc = checkoutCalc(s, a, d);
  const authorizers = s.users.filter((x) => x.active && hasPerm(s, 'estornos.autorizar', x));
  const settlements = [['pago', 'Pago integralmente', 'Recebe o total agora'], ['parcial', 'Pagamento parcial', 'Recebe uma parte'], ['pendente', 'Pendente', 'Fica a receber'], ['pacote', 'Sessão de pacote', pkgs.length ? `${pkgs.length} pacote(s) disponível(is)` : 'Nenhum pacote válido'], ['cortesia', 'Cortesia autorizada', 'Sem receita']];
  const needMethod = d.settlement === 'pago' || d.settlement === 'parcial' || (d.settlement === 'pacote' && d.extras.length);
  return `<div class="sheet-body stack" id="ck-body">
    <div class="card card-pad"><div class="row-between"><div class="grow"><div class="strong">${esc(c.name)}</div><div class="small muted">${esc(sv.name)} · ${esc(p.name)}</div><div class="small subtle">${fmtDate(a.date)} às ${a.start}</div></div><div class="right"><div class="xs subtle">Previsto</div><div class="strong num">${money(a.price)}</div></div></div></div>
    ${d.settlement !== 'pacote' && d.settlement !== 'cortesia' ? field('Valor realizado do serviço', `<input class="input num" name="realized" inputmode="decimal" value="${moneyInput(d.realized)}" id="ck-realized">`, { hint: d.realized !== a.price ? `Diferença de ${money(d.realized - a.price)} em relação ao previsto — o previsto fica preservado.` : 'Edite se o valor cobrado for diferente do previsto.' }) : ''}
    <div class="stack-sm"><div class="row-between"><span class="label">Serviços extras</span><button class="btn sm" data-action="ck-add-extra">${icon('plus')}Adicionar</button></div>
      ${d.addingExtra ? `<div class="row"><select class="select" id="ck-extra-sel">${options(s.services.filter((x) => x.active && x.id !== a.serviceId).map((x) => [x.id, `${x.name} — ${money(x.price)}`]), '', { placeholder: 'Escolha o serviço extra' })}</select><button class="btn sm primary" data-action="ck-extra-ok">Incluir</button></div>` : ''}
      ${d.extras.length ? d.extras.map((x, i) => `<div class="row-between small"><span>${esc(x.name)}</span><span class="row"><span class="num">${money(x.price)}</span><button class="btn sm ghost icon" data-action="ck-del-extra" data-i="${i}" aria-label="Remover ${esc(x.name)}">${icon('x')}</button></span></div>`).join('') : '<p class="xs subtle">Nenhum extra.</p>'}
    </div>
    <div class="stack-sm" data-field="settlement"><span class="label">Situação financeira</span>
      <div class="choice-grid">${settlements.map(([k, l, sub]) => `<button type="button" class="choice" aria-pressed="${d.settlement === k}" data-action="ck-settle" data-v="${k}" ${k === 'pacote' && !pkgs.length ? 'disabled style="opacity:.5;cursor:not-allowed"' : ''} ${k === 'cortesia' && !authorizers.length ? 'disabled' : ''}><span class="strong">${l}</span><small>${sub}</small></button>`).join('')}</div>
      ${expired.length && d.settlement !== 'pacote' ? `<p class="xs" style="color:var(--bad)">${icon('alert', '')} A cliente tem pacote vencido em ${fmtDate(expired[0].expiresAt)} para este serviço — não pode ser usado.</p>` : ''}
    </div>
    ${d.settlement === 'pacote' ? field('Pacote', `<select class="select" name="pkg" id="ck-pkg">${options(pkgs.map((cp) => [cp.id, `${byId(s.packages, cp.packageId).name} — restam ${packageRemaining(s, cp, a.serviceId)} · vence ${fmtDate(cp.expiresAt)}`]), d.pkgId)}</select>`, { hint: 'Consome 1 sessão. Não gera nova venda do serviço.' }) : ''}
    ${d.settlement === 'cortesia' ? field('Autorizado por', `<select class="select" name="authorizedBy" id="ck-auth">${options(authorizers, d.authorizedBy, { placeholder: 'Quem autorizou' })}</select>`, { hint: 'Registra o atendimento sem receita; a autorização fica no histórico.' }) : ''}
    ${needMethod ? `<div class="stack-sm" data-field="method"><span class="label">Forma de pagamento${d.settlement === 'pacote' ? ' (extras)' : ''}</span><div class="chips">${PAYMENT_METHODS.filter((m) => s.org.paymentMethods.includes(m.id)).map((m) => `<button type="button" class="chip" aria-pressed="${d.method === m.id}" data-action="ck-method" data-v="${m.id}">${m.label}</button>`).join('')}</div></div>` : ''}
    ${d.settlement === 'parcial' ? field('Valor recebido agora', `<input class="input num" name="amountReceived" inputmode="decimal" placeholder="0,00" value="${esc(d.amount)}" id="ck-amount">`, { hint: 'O saldo fica pendente na venda.' }) : ''}
    <div class="summary" id="ck-summary">${summaryCk(calc, d)}</div>
  </div>
  <div class="sheet-foot"><button class="btn" data-action="sheet-close">Cancelar</button><button class="btn accent lg" data-action="ck-confirm" data-id="${a.id}" id="ck-confirm">${icon('check')}Confirmar finalização</button></div>`;
}
function summaryCk(calc, d) {
  if (d.settlement === 'pacote') return `<dl class="kv"><dt>Sessão de pacote</dt><dd>1 sessão consumida</dd>${calc.sold ? `<dt>Venda de extras</dt><dd>${money(calc.sold)}</dd><dt>Recebido</dt><dd>${money(calc.received)}</dd>` : '<dt>Nova venda</dt><dd>Nenhuma</dd>'}</dl>`;
  if (d.settlement === 'cortesia') return `<dl class="kv"><dt>Valor vendido</dt><dd>${money(0)}</dd><dt>Receita</dt><dd>Nenhuma (cortesia)</dd></dl>`;
  return `<dl class="kv"><dt>Valor realizado</dt><dd>${money(calc.total)}</dd><dt>Valor vendido</dt><dd>${money(calc.sold)}</dd><dt>Recebido agora</dt><dd style="color:var(--good)">${money(calc.received)}</dd><dt>Pendente</dt><dd style="color:${calc.pending ? 'var(--bad)' : 'inherit'}">${money(calc.pending)}</dd></dl>`;
}
function bindCheckout(root, id, d) {
  root._ck = d;
  const re = () => { const s = S(); const a = byId(s.appointments, id); const el = root.querySelector('#ck-summary'); if (el) el.innerHTML = summaryCk(checkoutCalc(s, a, d), d); };
  root.querySelector('#ck-realized')?.addEventListener('input', (e) => { d.realized = parseMoney(e.target.value); re(); });
  root.querySelector('#ck-realized')?.addEventListener('change', () => refreshSheet());
  root.querySelector('#ck-amount')?.addEventListener('input', (e) => { d.amount = e.target.value; re(); });
  root.querySelector('#ck-pkg')?.addEventListener('change', (e) => { d.pkgId = e.target.value; });
  root.querySelector('#ck-auth')?.addEventListener('change', (e) => { d.authorizedBy = e.target.value; });
}
const ckd = (el) => el.closest('.overlay')._ck;
registerActions({
  'ck-settle': (el) => { const d = ckd(el); d.settlement = el.dataset.v; refreshSheet(); },
  'ck-method': (el) => { const d = ckd(el); d.method = el.dataset.v; el.closest('.chips').querySelectorAll('.chip').forEach((b) => b.setAttribute('aria-pressed', b === el)); },
  'ck-add-extra': (el) => { ckd(el).addingExtra = true; refreshSheet(); },
  'ck-extra-ok': (el) => { const d = ckd(el); const v = el.closest('.overlay').querySelector('#ck-extra-sel').value; if (!v) return; const sv = service(S(), v); d.extras.push({ serviceId: v, name: sv.name, price: sv.price }); d.addingExtra = false; refreshSheet(); },
  'ck-del-extra': (el) => { const d = ckd(el); d.extras.splice(Number(el.dataset.i), 1); refreshSheet(); },
  'ck-confirm': (el) => {
    const d = ckd(el); const btn = el; btn.disabled = true;
    try {
      const s = S(); const a = byId(s.appointments, el.dataset.id);
      if (d.settlement !== 'pacote' && d.settlement !== 'cortesia' && (isNaN(d.realized) || d.realized < 0)) throw Object.assign(new Error('Valor realizado inválido.'), { field: 'realized' });
      const calc = checkoutCalc(s, a, d);
      d.doneSummary = summaryCk(calc, d); d.submitting = true;
      const r = op.checkout(a.id, { realizedValue: d.realized, extras: d.extras.map((x) => ({ serviceId: x.serviceId, price: x.price })), settlement: d.settlement, method: d.method, amountReceived: parseMoney(d.amount), clientPackageId: d.pkgId, authorizedBy: d.authorizedBy, idempotencyKey: d.key, startedAt: d.startedAt });
      d.step = 'done'; d.submitting = false;
      refreshSheet(); toast(r.duplicate ? 'Este atendimento já estava finalizado.' : 'Atendimento finalizado e registrado.');
    } catch (e) { d.submitting = false; btn.disabled = false; refreshSheet(); showError(e, el.closest('.overlay').querySelector('#ck-body')); }
  },
});

// ---------- Resolução de pendências ----------
export function pendingList() { const s = S(); return s.appointments.filter(isPendingOp).sort((x, y) => (x.date + x.start).localeCompare(y.date + y.start)); }
export function pendingRow(a) {
  const s = S(); const c = client(s, a.clientId); const sv = service(s, a.serviceId);
  return `<div class="list-item" style="cursor:default;flex-wrap:wrap"><div class="li-main"><div class="li-title">${esc(c.name)}</div><div class="li-sub">${a.date === today() ? 'Hoje' : fmtDate(a.date)} ${a.start} · ${esc(sv.name)} · ${STATUS[a.status].label}</div></div>
  <div class="btn-group">${hasPerm(s, 'atendimento.finalizar') ? `<button class="btn sm accent" data-action="appt-checkout" data-id="${a.id}">Realizado</button>` : ''}<button class="btn sm" data-action="appt-noshow" data-id="${a.id}">Cliente faltou</button><button class="btn sm" data-action="appt-cancel" data-id="${a.id}">Cancelado</button><button class="btn sm" data-action="appt-reschedule" data-id="${a.id}">Reagendar</button></div></div>`;
}
