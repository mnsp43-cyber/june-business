// Utilidades de interface sem dependências de tela.
import { toast, openSheet } from './dom.js';
import { esc } from '../util.js';

const inFrame = (() => { try { return window.top !== window.self; } catch { return true; } })();

// Exportação: download direto; dentro de visualizadores que bloqueiam downloads (prévia em frame),
// mostra o conteúdo com botão Copiar.
export function download(name, content, type = 'text/csv;charset=utf-8') {
  if (inFrame) {
    openSheet({ title: `Exportar ${name}`, wide: true, render: () => `<div class="sheet-body stack"><div class="callout info"><div>Nesta prévia o navegador bloqueia downloads. Copie o conteúdo abaixo e cole em uma planilha, ou use a versão publicada (Netlify), onde o arquivo é baixado diretamente.</div></div><textarea class="textarea" id="exp-txt" rows="16" readonly style="font-family:ui-monospace,monospace;font-size:12px">${esc(content.replace(/^﻿/, ''))}</textarea></div><div class="sheet-foot"><button class="btn primary" data-action="exp-copy">Copiar</button></div>`,
      onMount: (root) => { root.querySelector('[data-action=exp-copy]').onclick = async (e) => { e.stopPropagation(); const t = root.querySelector('#exp-txt'); try { await navigator.clipboard.writeText(t.value); toast('Conteúdo copiado.'); } catch { t.select(); toast('Selecione e copie com Ctrl/Cmd + C.', 'err'); } }; } });
    return;
  }
  try {
    const blob = new Blob([content], { type }); const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000); toast(`Arquivo ${name} gerado com dados demonstrativos.`);
  } catch (e) { toast('Não foi possível gerar o arquivo neste navegador.', 'err'); }
}
