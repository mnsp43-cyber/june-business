// Seletor de cliente com busca por nome ou telefone.
import { S } from './ctx.js';
import { esc, fmtPhone } from '../util.js';
import { client, searchClients } from '../services/core.js';
import { clientStats } from '../metrics/metrics.js';

export function clientPicker(selectedId, label = 'Cliente *') {
  const c = selectedId ? client(S(), selectedId) : null;
  return `<div class="field" data-field="clientId"><label for="cp-q">${label}</label>
    <div class="cp" style="position:relative">${c ? `<div class="row-between card card-pad" style="padding:8px 12px"><div><div class="strong">${esc(c.name)}</div><div class="xs muted">${fmtPhone(c.phone)}</div></div><button type="button" class="btn sm ghost" data-cp-clear>Trocar</button></div>`
      : `<input class="input" id="cp-q" placeholder="Buscar por nome ou telefone" autocomplete="off"><div class="cp-res card" style="display:none;position:absolute;left:0;right:0;top:44px;z-index:5;max-height:240px;overflow:auto"></div>`}</div></div>`;
}
export function bindClientPicker(root, onPick) {
  const q = root.querySelector('#cp-q'); const res = root.querySelector('.cp-res');
  root.querySelector('[data-cp-clear]')?.addEventListener('click', () => { onPick(''); import('./dom.js').then((m) => m.refreshSheet()); });
  if (!q) return;
  q.addEventListener('input', () => {
    const v = q.value.trim(); if (v.length < 2) { res.style.display = 'none'; return; }
    const list = searchClients(S(), v).slice(0, 8);
    res.innerHTML = list.length ? list.map((c) => `<button type="button" class="list-item" style="min-height:44px" data-cp="${c.id}"><div class="li-main"><div class="li-title">${esc(c.name)}</div><div class="li-sub">${fmtPhone(c.phone)} · ${clientStats(S(), c.id).visitCount} atend.</div></div></button>`).join('') : '<p class="small muted card-pad">Nenhuma cliente encontrada.</p>';
    res.style.display = 'block';
  });
  res.addEventListener('click', (e) => { const b = e.target.closest('[data-cp]'); if (!b) return; onPick(b.dataset.cp); import('./dom.js').then((m) => m.refreshSheet()); });
}
