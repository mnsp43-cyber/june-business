// Meu Dia — central operacional (primeira tela após o login).
import { S, now, today, go } from '../ctx.js';
import { esc, money, fmtLongDate, firstName, timeToMin } from '../../util.js';
import { currentUser, hasPerm, client, service, saleTotal, salePaid, byId } from '../../services/core.js';
import { computeKPIs } from '../../metrics/metrics.js';
import { apptCard, pendingList, pendingRow, isPendingOp } from '../appointments.js';
import { icon, empty, registerActions } from '../dom.js';

const cap = (x) => x.charAt(0).toUpperCase() + x.slice(1);
export function render() {
  const s = S(); const u = currentUser(s); const d = today(); const t = s.settings.demoTime;
  const ownOnly = !hasPerm(s, 'agenda.ver_todas');
  const mine = (a) => !ownOnly || a.professionalId === u.professionalId;
  const list = s.appointments.filter((a) => a.date === d && mine(a)).sort((x, y) => x.start.localeCompare(y.start) || x.professionalId.localeCompare(y.professionalId));
  const visible = list.filter((a) => a.status !== 'reagendado');
  const count = (st) => visible.filter((a) => a.status === st).length;
  const pend = pendingList().filter(mine);
  const k = computeKPIs(s, { from: d, to: d }, ownOnly ? { professionalId: u.professionalId } : {});
  const upcoming = visible.filter((a) => !['realizado', 'falta', 'cancelado'].includes(a.status) && !isPendingOp(a));
  const next = upcoming.filter((a) => a.start >= t).slice(0, 3);
  const done = visible.filter((a) => ['realizado', 'falta', 'cancelado'].includes(a.status));
  const pendingToday = visible.filter(isPendingOp);
  const h = Number(t.slice(0, 2)); const greet = h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite';
  const showFin = hasPerm(s, 'pagamentos.registrar');
  // Pagamentos pendentes de vendas de hoje
  const pendSalesToday = s.sales.filter((x) => x.date === d && x.status === 'valida' && saleTotal(x) > salePaid(s, x.id));
  const kpi = (label, value, sub = '', tone = '', action = '') => `<div class="kpi ${tone ? 'tone-' + tone : ''}"><div class="k-label">${label}</div><div class="k-value">${value}</div>${sub ? `<div class="k-sub">${sub}</div>` : ''}${action}</div>`;
  return `
  <div class="page-head"><div><div class="greet">${greet}, ${esc(firstName(u.name))}</div><div class="muted">${cap(fmtLongDate(d))} · ${t}</div></div>
    <div class="btn-group hide-mobile"><button class="btn" data-action="go" data-to="/agenda">${icon('calendar')}Ver agenda</button></div></div>
  <div class="kpis" style="margin-bottom:16px">
    ${kpi('Agendamentos', visible.length, `${count('confirmado')} confirmados`)}
    ${kpi('Realizados', count('realizado'), `${upcoming.length} a atender`)}
    ${kpi('Pendentes', pend.length, 'sem status final', pend.length ? 'warn' : '')}
    ${kpi('Faltas · Cancel.', `${count('falta')} · ${count('cancelado')}`, 'hoje')}
    ${showFin ? kpi('Vendas do dia', money(k.net), `${k.salesCount} venda(s)`) : ''}
    ${showFin ? kpi('Recebido hoje', money(k.receivedNet), 'entradas confirmadas', 'good') : ''}
    ${showFin ? kpi('A receber (hoje)', money(pendSalesToday.reduce((t2, x) => t2 + saleTotal(x) - salePaid(s, x.id), 0)), `${pendSalesToday.length} venda(s) em aberto`, pendSalesToday.length ? 'bad' : '') : ''}
  </div>
  ${pend.length ? `<section class="card" style="margin-bottom:16px;border-color:#efc98a"><div class="card-head"><h2 class="row">${icon('alert')}Pendências operacionais</h2><span class="badge warn">${pend.length}</span></div>
    <p class="small muted" style="padding:10px 16px 0">Horários que já passaram sem status final. Registre o que aconteceu — o sistema nunca assume que o atendimento ocorreu.</p>
    <div class="list">${pend.map(pendingRow).join('')}</div></section>` : ''}
  <div class="grid g-main-side">
    <section>
      <div class="section-head"><h2>Atendimentos de hoje</h2><span class="small muted">${visible.length} no total</span></div>
      ${visible.length ? `<div class="appt-list">${[...pendingToday, ...upcoming, ...done].filter((a, i, arr) => arr.indexOf(a) === i).sort((x, y) => x.start.localeCompare(y.start)).map((a) => apptCard(a)).join('')}</div>` : `<div class="card">${empty('Nenhum atendimento hoje', 'Quando houver agendamentos para hoje, eles aparecem aqui em ordem de horário.', '<button class="btn primary" data-action="new-appt">Novo agendamento</button>', 'calendar')}</div>`}
    </section>
    <aside class="stack">
      <section class="card"><div class="card-head"><h3>Próximos horários</h3><span class="small muted">a partir de ${t}</span></div>
        ${next.length ? `<div class="list">${next.map((a) => { const c = client(s, a.clientId); return `<button class="list-item" data-action="appt-open" data-id="${a.id}"><strong class="num" style="width:44px">${a.start}</strong><div class="li-main"><div class="li-title">${esc(c.name)}</div><div class="li-sub">${esc(service(s, a.serviceId).name)}</div></div>${icon('right')}</button>`; }).join('')}</div>` : '<p class="small muted card-pad">Sem próximos horários hoje.</p>'}
      </section>
      ${showFin && pendSalesToday.length ? `<section class="card"><div class="card-head"><h3>Pagamentos pendentes de hoje</h3></div><div class="list">${pendSalesToday.map((x) => `<button class="list-item" data-action="fin-receive" data-id="${x.id}"><div class="li-main"><div class="li-title">${esc(client(s, x.clientId)?.name)}</div><div class="li-sub">${esc(x.items.map((i) => i.description).join(', '))}</div></div><span class="num strong" style="color:var(--bad)">${money(saleTotal(x) - salePaid(s, x.id))}</span></button>`).join('')}</div></section>` : ''}
      <section class="card card-pad stack-sm"><h3>Atalhos</h3><div class="btn-group">
        <button class="btn sm" data-action="new-client">${icon('user')}Novo cliente</button>
        ${showFin ? `<button class="btn sm" data-action="new-sale">${icon('cash')}Nova venda</button><button class="btn sm" data-action="new-payment">${icon('wallet')}Registrar pagamento</button>` : ''}
        ${hasPerm(s, 'dashboard.ver') ? `<button class="btn sm" data-action="go" data-to="/dashboard">${icon('chart')}Dashboard</button>` : ''}
      </div></section>
    </aside>
  </div>`;
}
