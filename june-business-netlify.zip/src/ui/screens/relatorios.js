// Relatórios — mesmas definições do dashboard, tabelas detalhadas e exportação CSV.
import { S, ui, today } from '../ctx.js';
import { esc, money, pct, num, fmtDate, toCSV, diffDays } from '../../util.js';
import { STATUS, PAYMENT_METHODS, CAMPAIGN_STATUS, CHANNELS } from '../../domain/rules.js';
import { client, service, professional, activeClients, hasPerm } from '../../services/core.js';
import { computeKPIs, presetRange, rangeLabel, series, autoGranularity, topServices, professionalsPerf, clientStats, commissions } from '../../metrics/metrics.js';
import * as crm from '../../services/crm.js';
import { icon, registerActions, tabs, badge, simBadge } from '../dom.js';
import { barChart, hbars } from '../charts.js';
import { download } from '../util-ui.js';
import { periodControl, bindPeriod } from '../period.js';

let lastTables = {};
function table(key, title, rows, cols, note = '') {
  lastTables[key] = { rows, cols, title };
  return `<section class="card" style="margin-bottom:16px"><div class="card-head"><h3>${esc(title)}</h3><button class="btn sm" data-action="rep-csv" data-key="${key}">${icon('download')}CSV</button></div>
  <div class="table-wrap" style="max-height:440px"><table class="table"><thead><tr>${cols.map((c) => `<th class="${c.num ? 'num' : ''}">${esc(c.label)}</th>`).join('')}</tr></thead><tbody>${rows.length ? rows.map((r) => `<tr>${cols.map((c) => `<td class="${c.num ? 'num' : ''}">${c.html ? c.html(r) : esc(c.value(r))}</td>`).join('')}</tr>`).join('') : `<tr><td colspan="${cols.length}" class="muted">Sem dados no período.</td></tr>`}</tbody></table></div>${note ? `<p class="xs subtle card-pad" style="padding-top:8px">${note}</p>` : ''}</section>`;
}
const M = (c) => money(c); const csvM = (c) => (c / 100).toFixed(2).replace('.', ',');

export function render() {
  const s = S(); const R = ui.rel; lastTables = {};
  const r = presetRange(R.preset, today(), R.custom); const k = computeKPIs(s, r, {});
  const showFin = hasPerm(s, 'financeiro.ver');
  const T = tabs([['operacional', 'Operacionais'], ['financeiro', 'Financeiros'], ['clientes', 'Clientes'], ['servicos', 'Serviços'], ['profissionais', 'Profissionais'], ['crm', 'CRM']], R.tab, 'rep-tab');
  const gran = autoGranularity(r); const ser = series(s, r, {}, gran);
  let body = '';
  if (R.tab === 'operacional') {
    const appts = s.appointments.filter((a) => a.date >= r.from && a.date <= r.to).sort((a, b) => (a.date + a.start).localeCompare(b.date + b.start));
    body = `<div class="kpis" style="margin-bottom:16px">${[['Agendamentos', k.scheduled], ['Realizados', k.realized], ['Faltas', k.noShow], ['Cancelamentos', k.cancel], ['Reagendados', k.resched], ['Comparecimento', pct(k.attendance)], ['Ocupação', pct(k.occupancy)]].map(([l, v]) => `<div class="kpi"><div class="k-label">${l}</div><div class="k-value">${v}</div></div>`).join('')}</div>
    ${table('op-serie', `Atendimentos por ${{ dia: 'dia', semana: 'semana', mes: 'mês' }[gran]}`, ser, [{ label: 'Período', value: (x) => x.label }, { label: 'Realizados', num: true, value: (x) => x.realized }, { label: 'Faltas', num: true, value: (x) => x.noShow }, { label: 'Cancelamentos', num: true, value: (x) => x.cancel }])}
    ${table('op-lista', 'Agendamentos do período', appts, [{ label: 'Data', value: (a) => fmtDate(a.date) }, { label: 'Hora', value: (a) => a.start }, { label: 'Cliente', value: (a) => client(s, a.clientId)?.name }, { label: 'Serviço', value: (a) => service(s, a.serviceId)?.name }, { label: 'Profissional', value: (a) => professional(s, a.professionalId)?.name }, { label: 'Status', value: (a) => STATUS[a.status].label }, { label: 'Previsto', num: true, value: (a) => M(a.price), csv: (a) => csvM(a.price) }])}`;
  }
  if (R.tab === 'financeiro') {
    if (!showFin) body = '<p class="muted">Seu perfil não acessa relatórios financeiros.</p>';
    else {
      const cats = {}; for (const e of s.expenses) if (e.paid && e.paidDate >= r.from && e.paidDate <= r.to) cats[e.category] = (cats[e.category] || 0) + e.amount;
      body = `<div class="kpis" style="margin-bottom:16px">${[['Faturamento bruto', M(k.gross)], ['Descontos', M(k.discount)], ['Estornos', M(k.reversals)], ['Vendas líquidas', M(k.net)], ['Recebido', M(k.receivedNet)], ['A receber', M(k.receivable)], ['Despesas pagas', M(k.expensesPaid)], ['Resultado de caixa', M(k.cashResult)], ['Resultado competência', M(k.accrualResult)]].map(([l, v]) => `<div class="kpi"><div class="k-label">${l}</div><div class="k-value">${v}</div></div>`).join('')}</div>
      ${table('fin-serie', 'Vendas, recebimentos e despesas', ser, [{ label: 'Período', value: (x) => x.label }, { label: 'Vendas líquidas', num: true, value: (x) => M(x.net), csv: (x) => csvM(x.net) }, { label: 'Recebido', num: true, value: (x) => M(x.received), csv: (x) => csvM(x.received) }, { label: 'Despesas pagas', num: true, value: (x) => M(x.expenses), csv: (x) => csvM(x.expenses) }, { label: 'Resultado de caixa', num: true, value: (x) => M(x.received - x.expenses), csv: (x) => csvM(x.received - x.expenses) }, { label: 'A receber (posição)', num: true, value: (x) => M(x.receivable), csv: (x) => csvM(x.receivable) }], 'Resultado de caixa = recebido − despesas pagas. Não é lucro contábil.')}
      <div class="grid g2">${table('fin-forma', 'Recebido por forma de pagamento', PAYMENT_METHODS.map((m) => ({ m, v: k.byMethod[m.id] || 0 })), [{ label: 'Forma', value: (x) => x.m.label }, { label: 'Valor', num: true, value: (x) => M(x.v), csv: (x) => csvM(x.v) }, { label: 'Participação', num: true, value: (x) => pct(k.receivedNet ? (x.v / k.receivedNet) * 100 : null) }])}
      ${table('fin-desp', 'Despesas pagas por categoria', Object.entries(cats).sort((a, b) => b[1] - a[1]), [{ label: 'Categoria', value: (x) => x[0] }, { label: 'Valor', num: true, value: (x) => M(x[1]), csv: (x) => csvM(x[1]) }])}</div>`;
    }
  }
  if (R.tab === 'clientes') {
    const rows = activeClients(s).map((c) => ({ c, st: clientStats(s, c.id) }));
    const inP = rows.filter((x) => x.st.visits.some((a) => a.date >= r.from && a.date <= r.to));
    body = `<div class="kpis" style="margin-bottom:16px">${[['Clientes atendidas', k.attended], ['Novas', k.newClients], ['Recorrentes', k.recurrent], ['Reativadas', k.reactivated], ['Inativas', k.inactive], ['Leads', k.leads]].map(([l, v]) => `<div class="kpi"><div class="k-label">${l}</div><div class="k-value">${v}</div></div>`).join('')}</div>
    ${table('cli-atendidas', 'Clientes atendidas no período', inP.sort((a, b) => b.st.totalSales - a.st.totalSales), [{ label: 'Cliente', value: (x) => x.c.name }, { label: 'Primeira visita', value: (x) => fmtDate(x.st.firstVisit) }, { label: 'Última visita', value: (x) => fmtDate(x.st.lastVisit) }, { label: 'Atendimentos (total)', num: true, value: (x) => x.st.visitCount }, { label: 'Tipo no período', value: (x) => (x.st.firstVisit >= r.from ? 'Nova' : 'Recorrente') }, { label: 'Valor acumulado', num: true, value: (x) => M(x.st.totalSales), csv: (x) => csvM(x.st.totalSales) }, { label: 'Frequência média', num: true, value: (x) => (x.st.avgFrequency ? x.st.avgFrequency + ' d' : '—') }])}
    ${table('cli-inativas', `Clientes inativas (+${s.org.crm.inactivityDays} dias)`, rows.filter((x) => x.st.daysSince > s.org.crm.inactivityDays).sort((a, b) => b.st.totalSales - a.st.totalSales), [{ label: 'Cliente', value: (x) => x.c.name }, { label: 'Última visita', value: (x) => fmtDate(x.st.lastVisit) }, { label: 'Dias', num: true, value: (x) => x.st.daysSince }, { label: 'Valor acumulado', num: true, value: (x) => M(x.st.totalSales), csv: (x) => csvM(x.st.totalSales) }])}`;
  }
  if (R.tab === 'servicos') {
    const top = topServices(s, r, {}).sort((a, b) => b.value - a.value);
    body = `${table('svc', 'Serviços no período', top, [{ label: 'Serviço', value: (x) => x.service.name }, { label: 'Categoria', value: (x) => x.service.category }, { label: 'Vendidos', num: true, value: (x) => x.qty }, { label: 'Sessões de pacote', num: true, value: (x) => x.pkgQty }, { label: 'Valor', num: true, value: (x) => M(x.value), csv: (x) => csvM(x.value) }, { label: 'Ticket', num: true, value: (x) => (x.qty ? M(Math.round(x.value / x.qty)) : '—') }], 'Sessões de pacote não geram nova venda; o valor do pacote é contado na data da venda do pacote.')}`;
  }
  if (R.tab === 'profissionais') {
    const pros = professionalsPerf(s, r, {}); const cm = commissions(s, r);
    body = table('pros', 'Desempenho por profissional', pros, [{ label: 'Profissional', value: (p) => p.professional.name }, { label: 'Realizados', num: true, value: (p) => p.realized }, { label: 'Valor de serviços', num: true, value: (p) => M(p.value), csv: (p) => csvM(p.value) }, { label: 'Ticket médio', num: true, value: (p) => M(p.ticket), csv: (p) => csvM(p.ticket) }, { label: 'Ocupação', num: true, value: (p) => pct(p.occupancy) }, { label: 'Comparecimento', num: true, value: (p) => pct(p.attendance) }, { label: 'Faltas', num: true, value: (p) => p.noShow }, { label: 'Clientes', num: true, value: (p) => p.attended }, ...(showFin ? [{ label: 'Comissão estimada', num: true, value: (p) => M(cm.get(p.professional.id)?.value || 0), csv: (p) => csvM(cm.get(p.professional.id)?.value || 0) }] : [])]);
  }
  if (R.tab === 'crm') {
    const camps = [...s.campaigns].sort((a, b) => b.createdAt.localeCompare(a.createdAt)); // campanhas listadas sem filtro de período
    const rows = camps.map((c) => ({ c, res: crm.campaignResults(s, c) }));
    const msgs = s.communications.filter((m) => m.at.slice(0, 10) >= r.from && m.at.slice(0, 10) <= r.to);
    const by = {}; for (const m of msgs) by[m.status] = (by[m.status] || 0) + 1;
    body = `<div class="callout sim" style="margin-bottom:16px">${icon('info')}<div>Envios, entregas e leituras são <b>simulados</b>. Cliques e custos ficam <b>indisponíveis</b> até existir integração e rastreamento real. Atribuição: agendamento ou compra da destinatária em até ${s.org.crm.attributionDays} dias após a execução (regra demonstrativa, não comprova causalidade).</div></div>
    ${table('crm-camp', 'Campanhas', rows, [{ label: 'Campanha', value: (x) => x.c.name }, { label: 'Status', value: (x) => CAMPAIGN_STATUS[x.c.status] }, { label: 'Canal', value: (x) => CHANNELS[x.c.channel] }, { label: 'Público', num: true, value: (x) => x.res.audience }, { label: 'Elegíveis', num: true, value: (x) => x.res.eligible }, { label: 'Enviadas (sim.)', num: true, value: (x) => x.res.sent }, { label: 'Entregues (sim.)', num: true, value: (x) => x.res.delivered }, { label: 'Falhas (sim.)', num: true, value: (x) => x.res.failed }, { label: 'Cliques', num: true, value: () => 'indisponível' }, { label: 'Descadastros', num: true, value: (x) => x.res.optOuts }, { label: 'Agend. atribuídos', num: true, value: (x) => x.res.bookings }, { label: 'Vendas atribuídas', num: true, value: (x) => x.res.sales }, { label: 'Receita atribuída', num: true, value: (x) => M(x.res.revenue), csv: (x) => csvM(x.res.revenue) }, { label: 'Custo', num: true, value: () => 'indisponível' }])}
    ${table('crm-msg', 'Comunicações no período por status', Object.entries(by), [{ label: 'Status', value: (x) => x[0] }, { label: 'Quantidade (simulada)', num: true, value: (x) => x[1] }])}`;
  }
  return `<div class="page-head"><div><h1>Relatórios</h1><p class="small muted">${rangeLabel(r)} · mesmas fórmulas do dashboard</p></div><div class="filters">${periodControl('rel', R.preset, R.custom)}</div></div>${T}${body}`;
}
export function bindRelatorios(root) { bindPeriod(root, 'rel', ui.rel); }
registerActions({
  'rep-tab': (el) => { ui.rel.tab = el.dataset.value; window.__rerender(); },
  'rep-csv': (el) => { const t = lastTables[el.dataset.key]; if (!t) return; download(`${el.dataset.key}_${today()}.csv`, toCSV(t.rows, t.cols.map((c) => ({ label: c.label, value: c.csv || c.value })))); },
});
