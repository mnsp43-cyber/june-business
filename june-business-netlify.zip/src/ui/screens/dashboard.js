// Dashboard e BI — indicadores, comparativos, gráficos e insights calculados dos registros.
import { S, ui, today } from '../ctx.js';
import { esc, money, pct, num, fmtDate, addDays, diffDays, WEEKDAYS_SHORT } from '../../util.js';
import { STATUS } from '../../domain/rules.js';
import { hasPerm } from '../../services/core.js';
import { dailyTotals, computeKPIs, presetRange, previousRange, rangeLabel, variation, series, autoGranularity, topServices, professionalsPerf, demandHeatmap, cohorts, insights, METRIC_DICTIONARY, bucketsFor } from '../../metrics/metrics.js';
import { icon, registerActions, openSheet, options, seg, badge, deltaBadge } from '../dom.js';
import { lineChart, barChart, hbars, stackBar, heatmap, SERIES } from '../charts.js';
import { periodControl, bindPeriod } from '../period.js';

const axisMoney = (v, axis) => axis ? (Math.abs(v) >= 100000 ? (v / 100000).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' mil' : (v / 100).toLocaleString('pt-BR', { maximumFractionDigits: 0 })) : money(v);

export function render() {
  const s = S(); const D = ui.dash;
  const r = presetRange(D.preset, today(), D.custom);
  const pr = previousRange(r, D.preset, D.compare);
  const f = { professionalId: D.pro || undefined, serviceId: D.service || undefined, category: D.category || undefined, clientType: D.clientType || undefined, status: D.status || undefined };
  const cur = computeKPIs(s, r, f), prev = computeKPIs(s, pr, f);
  const showFin = hasPerm(s, 'financeiro.ver');
  const gran = D.gran === 'auto' ? autoGranularity(r) : D.gran;
  const kcard = (key, label, v, p, fmt, opts = {}) => {
    const vv = variation(v, p, opts);
    const naNote = opts.na ? `<div class="k-sub" style="color:var(--warn)">filtro não se aplica</div>` : '';
    return `<div class="kpi" title="${esc(METRIC_DICTIONARY.find((m) => m.key === key)?.def || '')}"><div class="k-label">${label}</div><div class="k-value">${v == null ? '—' : fmt(v)}</div><div class="row" style="gap:6px;margin-top:4px;flex-wrap:wrap">${v != null && p != null ? deltaBadge(vv, { pp: !!opts.isRate }) : ''}<span class="xs subtle">ant. ${p == null ? '—' : fmt(p)}</span></div>${naNote}</div>`;
  };
  const m = money, n = (x) => num(x), pc = (x) => pct(x);
  const activeN = [D.pro, D.service, D.category, D.clientType, D.status].filter(Boolean).length;
  const filters = `<div class="card card-pad" style="margin-bottom:16px"><div class="filters">
    ${periodControl('dash', D.preset, D.custom)}
    <select class="select" data-dash="compare" aria-label="Comparação">${options([['equivalente', 'vs. período equivalente'], ['completo', 'vs. período anterior completo']], D.compare)}</select>
  </div><details class="more-filters" ${innerWidth >= 768 || activeN ? 'open' : ''} style="margin-top:8px"><summary class="small strong" style="cursor:pointer;padding:4px 0">Filtros${activeN ? ` (${activeN} ativo${activeN > 1 ? 's' : ''})` : ''}</summary><div class="filters" style="margin-top:8px">
    <select class="select" data-dash="pro" aria-label="Profissional">${options(s.professionals, D.pro, { placeholder: 'Todas as profissionais' })}</select>
    <select class="select" data-dash="category" aria-label="Categoria">${options(s.org.categories.map((c) => [c, c]), D.category, { placeholder: 'Todas as categorias' })}</select>
    <select class="select" data-dash="service" aria-label="Serviço">${options(s.services.filter((x) => !D.category || x.category === D.category), D.service, { placeholder: 'Todos os serviços' })}</select>
    <select class="select" data-dash="clientType" aria-label="Tipo de cliente">${options([['novo', 'Clientes novas'], ['recorrente', 'Clientes recorrentes']], D.clientType, { placeholder: 'Todos os tipos de cliente' })}</select>
    <select class="select" data-dash="status" aria-label="Status do atendimento">${options(Object.entries(STATUS).map(([k, v]) => [k, v.label]), D.status, { placeholder: 'Todos os status' })}</select>
    <select class="select" disabled aria-label="Unidade" title="Multiunidade planejada"><option>Unidade única</option></select>
    ${activeN ? '<button class="btn sm ghost" data-action="dash-clear">Limpar filtros</button>' : ''}
  </div></details><p class="xs subtle" style="margin-top:8px">Atual: <b>${rangeLabel(r)}</b> · comparado com <b>${rangeLabel(pr)}</b> (${esc(pr.label)}). ${D.status ? 'O filtro de status afeta apenas contagens de atendimentos. ' : ''}Recebimentos com filtro de profissional/serviço são atribuídos proporcionalmente aos itens da venda.</p></div>`;
  const ins = insights(s, cur, prev, r, pr, f);
  const finKpis = showFin ? `<section style="margin-bottom:16px"><div class="section-head"><h2>Financeiro</h2><button class="btn sm ghost" data-action="dash-dict">${icon('info')}Dicionário de métricas</button></div><div class="kpis">
    ${kcard('gross', 'Faturamento bruto', cur.gross, prev.gross, m)}
    ${kcard('net', 'Vendas líquidas', cur.net, prev.net, m)}
    ${kcard('received', 'Recebido', cur.receivedNet, prev.receivedNet, m)}
    ${kcard('receivable', 'A receber', cur.receivable, prev.receivable, m, { goodWhenUp: false })}
    ${kcard('ticket', 'Ticket médio', cur.ticket, prev.ticket, m)}
    ${kcard('net', 'Descontos e estornos', cur.discount + cur.reversals + cur.cancelled, prev.discount + prev.reversals + prev.cancelled, m, { goodWhenUp: false })}
    ${kcard('expensesPaid', 'Despesas pagas', cur.expensesPaid, prev.expensesPaid, m, { goodWhenUp: false, na: cur.notApplicable.expenses })}
    ${kcard('cashResult', 'Resultado de caixa estimado', cur.cashResult, prev.cashResult, m, { na: cur.notApplicable.expenses })}
  </div></section>` : '';
  const opKpis = `<section style="margin-bottom:16px"><div class="section-head"><h2>Operação</h2>${!showFin ? `<button class="btn sm ghost" data-action="dash-dict">${icon('info')}Dicionário</button>` : ''}</div><div class="kpis">
    ${kcard('', 'Agendamentos', cur.scheduled, prev.scheduled, n)}
    ${kcard('', 'Atendimentos realizados', cur.realized, prev.realized, n)}
    ${kcard('attendance', 'Taxa de comparecimento', cur.attendance, prev.attendance, pc, { isRate: true })}
    ${kcard('occupancy', 'Taxa de ocupação', cur.occupancy, prev.occupancy, pc, { isRate: true, na: cur.notApplicable.occupancy })}
    ${kcard('', 'Faltas', cur.noShow, prev.noShow, n, { goodWhenUp: false })}
    ${kcard('', 'Cancelamentos', cur.cancel, prev.cancel, n, { goodWhenUp: false })}
  </div></section>
  <section style="margin-bottom:16px"><div class="section-head"><h2>Clientes</h2></div><div class="kpis">
    ${kcard('attended', 'Clientes atendidas', cur.attended, prev.attended, n)}
    ${kcard('newClients', 'Clientes novas', cur.newClients, prev.newClients, n)}
    ${kcard('recurrent', 'Recorrentes', cur.recurrent, prev.recurrent, n)}
    ${kcard('reactivated', 'Reativadas', cur.reactivated, prev.reactivated, n)}
    ${kcard('inactive', 'Inativas (+' + s.org.crm.inactivityDays + ' dias)', cur.inactive, prev.inactive, n, { goodWhenUp: false })}
  </div></section>`;
  // Gráficos
  const ser = series(s, r, f, gran);
  const evo = showFin ? lineChart({ labels: ser.map((x) => x.label), series: [{ label: 'Vendas líquidas', values: ser.map((x) => x.net) }, { label: 'Recebido', values: ser.map((x) => x.received) }], fmt: axisMoney }) : lineChart({ labels: ser.map((x) => x.label), series: [{ label: 'Atendimentos realizados', values: ser.map((x) => x.realized) }], fmt: (v) => num(Math.round(v)) });
  // Comparação de períodos: acumulado diário atual × anterior
  const days = Math.min(diffDays(r.to, r.from) + 1, 400);
  const cumulative = (rr) => { const dt = dailyTotals(s, rr, f); const src = showFin ? dt.net : dt.realized; const out = []; let acc = 0; for (let i = 0; i < days; i++) { const d = addDays(rr.from, i); if (d > rr.to) { out.push(null); continue; } acc += src[d] || 0; out.push(acc); } return out; };
  let cmpChart = '';
  if (days <= 92 && days > 1) { const c1 = cumulative(r), c2 = cumulative(pr); const last2 = c2.filter((v) => v != null).at(-1) || 0; cmpChart = lineChart({ labels: Array.from({ length: days }, (_, i) => `dia ${i + 1}`), series: [{ label: 'Período atual (acumulado)', values: c1.map((v) => v ?? 0) }, { label: 'Período de comparação', values: c2.map((v) => v ?? last2), dashed: true }], fmt: showFin ? axisMoney : (v) => num(Math.round(v)) }); }
  else { const pser = series(s, pr, f, gran); cmpChart = barChart({ labels: ser.map((x) => x.label), series: [{ label: 'Atual', values: ser.map((x) => (showFin ? x.net : x.realized)) }, { label: 'Comparação', values: ser.map((_, i) => (pser[i] ? (showFin ? pser[i].net : pser[i].realized) : 0)) }], fmt: showFin ? axisMoney : (v) => num(Math.round(v)) }); }
  const stc = cur.statusCounts;
  const statusParts = [['realizado', 'var(--good)'], ['agendado', 'var(--border-strong)'], ['confirmado', 'var(--info)'], ['chegou', 'var(--accent-500)'], ['em_atendimento', 'var(--accent-600)'], ['falta', 'var(--bad)'], ['cancelado', 'var(--text-3)'], ['reagendado', '#c9d1d4']].map(([k, c]) => ({ label: STATUS[k].label, value: stc[k] || 0, color: c }));
  const top = topServices(s, r, f); const byQty = [...top].sort((a, b) => b.qty + b.pkgQty - (a.qty + a.pkgQty)).slice(0, 8); const byVal = [...top].sort((a, b) => b.value - a.value).slice(0, 8);
  const pros = professionalsPerf(s, r, f);
  const clientSer = series(s, r, f, diffDays(r.to, r.from) > 62 ? 'mes' : diffDays(r.to, r.from) > 14 ? 'semana' : 'dia');
  const heat = demandHeatmap(s, r, f);
  const coh = cohorts(s, today(), 6);
  const svcTable = top.map((x) => { const pv = topServices(s, pr, f).find((y) => y.serviceId === x.serviceId); const q = x.qty + x.pkgQty, pq = pv ? pv.qty + pv.pkgQty : 0; return { ...x, q, pq, v: variation(q, pq) }; }).sort((a, b) => b.q - a.q);
  const charts = `
  <div class="grid g2" style="margin-bottom:16px">
    <section class="card"><div class="card-head"><h3>${showFin ? 'Evolução de vendas e recebimentos' : 'Evolução de atendimentos'}</h3>${seg('gran', [['auto', 'Auto'], ['dia', 'Dia'], ['semana', 'Semana'], ['mes', 'Mês']], D.gran, 'dash-gran')}</div><div class="card-body">${evo}</div></section>
    <section class="card"><div class="card-head"><h3>Comparação de períodos</h3><span class="small muted">${showFin ? 'vendas líquidas' : 'atendimentos'}</span></div><div class="card-body">${cmpChart}</div></section>
  </div>
  <div class="grid g3" style="margin-bottom:16px">
    <section class="card"><div class="card-head"><h3>Atendimentos por status</h3></div><div class="card-body">${stackBar(statusParts, { fmt: num })}<p class="xs subtle" style="margin-top:8px">Comparecimento ${pct(cur.attendance)} = realizados ÷ (realizados + faltas). Cancelamentos à parte.</p></div></section>
    <section class="card"><div class="card-head"><h3>Serviços mais realizados</h3><span class="small muted">quantidade</span></div><div class="card-body">${hbars(byQty.map((x) => ({ label: x.service.name, value: x.qty + x.pkgQty, tip: `${x.qty} vendidos + ${x.pkgQty} sessões de pacote` })), { fmt: num })}</div></section>
    ${showFin ? `<section class="card"><div class="card-head"><h3>Serviços por valor</h3><span class="small muted">vendas líquidas</span></div><div class="card-body">${hbars(byVal.map((x) => ({ label: x.service.name, value: x.value })), { fmt: money, color: SERIES[1] })}</div></section>` : ''}
  </div>
  <section class="card" style="margin-bottom:16px"><div class="card-head"><h3>Desempenho das profissionais</h3></div><div class="table-wrap"><table class="table"><thead><tr><th>Profissional</th><th class="num">Realizados</th>${showFin ? '<th class="num">Valor de serviços</th><th class="num">Ticket médio</th>' : ''}<th class="num">Ocupação</th><th class="num">Comparec.</th><th class="num">Faltas</th><th class="num">Clientes</th><th style="width:22%">Participação</th></tr></thead><tbody>
    ${(() => { const maxR = Math.max(1, ...pros.map((p) => p.realized)); return pros.map((p) => `<tr><td><span class="dot" style="background:${p.professional.color};margin-right:6px"></span>${esc(p.professional.name)}</td><td class="num">${p.realized}</td>${showFin ? `<td class="num">${money(p.value)}</td><td class="num">${money(p.ticket)}</td>` : ''}<td class="num">${pct(p.occupancy)}</td><td class="num">${pct(p.attendance)}</td><td class="num">${p.noShow}</td><td class="num">${p.attended}</td><td><div class="hb-track" style="height:10px;background:var(--muted-bg);border-radius:4px;overflow:hidden" data-tip="${esc(`<b>${esc(p.professional.name)}</b>: ${p.realized} atendimentos`)}"><div style="height:100%;width:${(p.realized / maxR) * 100}%;background:var(--series-1);border-radius:0 4px 4px 0"></div></div></td></tr>`).join(''); })()}
  </tbody></table></div></section>
  <div class="grid g2" style="margin-bottom:16px">
    <section class="card"><div class="card-head"><h3>Clientes novas, recorrentes e reativadas</h3></div><div class="card-body">${barChart({ labels: clientSer.map((x) => x.label), series: [{ label: 'Novas', values: clientSer.map((x) => x.newClients) }, { label: 'Recorrentes', values: clientSer.map((x) => x.recurrent) }, { label: 'Reativadas', values: clientSer.map((x) => x.reactivated) }], fmt: (v) => num(Math.round(v)) })}</div></section>
    ${showFin ? `<section class="card"><div class="card-head"><h3>Vendas, recebimentos, despesas e pendências</h3></div><div class="card-body">${barChart({ labels: ser.map((x) => x.label), series: [{ label: 'Vendas líquidas', values: ser.map((x) => x.net) }, { label: 'Recebido', values: ser.map((x) => x.received) }, { label: 'Despesas pagas', values: ser.map((x) => x.expenses) }, { label: 'A receber (posição)', values: ser.map((x) => x.receivable) }], fmt: axisMoney })}</div></section>` : `<section class="card"><div class="card-head"><h3>Faltas e cancelamentos</h3></div><div class="card-body">${barChart({ labels: ser.map((x) => x.label), series: [{ label: 'Faltas', values: ser.map((x) => x.noShow) }, { label: 'Cancelamentos', values: ser.map((x) => x.cancel) }], fmt: (v) => num(Math.round(v)) })}</div></section>`}
  </div>
  <div class="grid g2" style="margin-bottom:16px">
    <section class="card"><div class="card-head"><h3>Horários de maior procura</h3><span class="small muted">agendamentos por dia e hora</span></div><div class="card-body" style="overflow-x:auto">${heatmap({ rows: [1, 2, 3, 4, 5, 6], cols: Array.from({ length: 11 }, (_, i) => 9 + i), get: (d, h) => heat.grid[d + '|' + String(h).padStart(2, '0')] || 0, rowLabel: (d) => WEEKDAYS_SHORT[d], colLabel: (h) => h + 'h', tipFmt: (d, h, v) => `<b>${WEEKDAYS_SHORT[d]} ${h}h</b>: ${v} agendamento(s)` })}</div></section>
    <section class="card"><div class="card-head"><h3>Retenção por coorte</h3><span class="small muted">mês da 1ª visita</span></div><div class="table-wrap"><table class="table"><thead><tr><th>Coorte</th><th class="num">Clientes</th><th class="num">Voltou em 30 d</th><th class="num">60 d</th><th class="num">90 d</th></tr></thead><tbody>${coh.map((c) => `<tr><td>${c.label}</td><td class="num">${c.size}</td>${[c.r30, c.r60, c.r90].map((v) => `<td class="num">${v == null ? '<span class="subtle" title="Janela ainda não completa">—</span>' : pct(v, 0)}</td>`).join('')}</tr>`).join('')}</tbody></table></div><p class="xs subtle card-pad" style="padding-top:0">Percentual da coorte com nova visita realizada dentro da janela. “—” = janela ainda não completou.</p></section>
  </div>
  <section class="card" style="margin-bottom:16px"><div class="card-head"><h3>Serviços: crescimento e queda</h3><span class="small muted">quantidade vs. comparação</span></div><div class="table-wrap"><table class="table"><thead><tr><th>Serviço</th><th class="num">Atual</th><th class="num">Anterior</th><th>Variação</th>${showFin ? '<th class="num">Valor</th><th class="num">Ticket</th>' : ''}</tr></thead><tbody>${svcTable.map((x) => `<tr><td>${esc(x.service.name)}</td><td class="num">${x.q}</td><td class="num">${x.pq}</td><td>${deltaBadge(x.v)}</td>${showFin ? `<td class="num">${money(x.value)}</td><td class="num">${x.qty ? money(Math.round(x.value / x.qty)) : '—'}</td>` : ''}</tr>`).join('') || '<tr><td colspan="6" class="muted">Sem serviços no período.</td></tr>'}</tbody></table></div></section>`;
  return `<div class="page-head"><div><h1>Dashboard</h1><p class="small muted">Calculado a partir dos mesmos registros da agenda, finalizações, vendas e pagamentos</p></div><div class="btn-group"><button class="btn" data-action="go" data-to="/relatorios">${icon('file')}Relatórios</button></div></div>
  ${filters}
  ${ins.length ? `<section class="card" style="margin-bottom:16px"><div class="card-head"><h3 class="row">${icon('zap')}Insights automáticos</h3><span class="xs subtle">regras sobre os dados — sem suposições de causa</span></div><div class="card-body stack-sm">${ins.map((i) => `<div class="row small" style="align-items:flex-start"><span class="dot" style="margin-top:6px;background:${i.tone === 'good' ? 'var(--good)' : i.tone === 'warn' ? 'var(--warn)' : 'var(--info)'}"></span><span>${esc(i.text)}</span></div>`).join('')}</div></section>` : ''}
  ${finKpis}${opKpis}${charts}`;
}
export function bindDashboard(root) {
  root.querySelectorAll('[data-dash]').forEach((el) => el.addEventListener('change', () => { ui.dash[el.dataset.dash] = el.value; if (el.dataset.dash === 'category') ui.dash.service = ''; window.__rerender(); }));
  bindPeriod(root, 'dash', ui.dash);
}
registerActions({
  'dash-gran': (el) => { ui.dash.gran = el.dataset.value; window.__rerender(); },
  'dash-clear': () => { Object.assign(ui.dash, { pro: '', service: '', category: '', clientType: '', status: '' }); window.__rerender(); },
  'dash-dict': () => openSheet({ title: 'Dicionário de métricas', render: () => `<div class="sheet-body stack">${METRIC_DICTIONARY.map((m) => `<div><div class="strong">${esc(m.label)}</div><p class="small muted">${esc(m.def)}</p></div>`).join('')}<div><div class="strong">Variação</div><p class="small muted">((atual − anterior) ÷ anterior) × 100. Se o anterior for zero, a variação não é calculável. Taxas mostram também a diferença em pontos percentuais (p.p.). Alta de faltas, cancelamentos, despesas e valores a receber aparece como alerta.</p></div><div><div class="strong">Período equivalente</div><p class="small muted">Para períodos incompletos (mês atual, ano atual), compara os mesmos dias do período anterior — ex.: dias 1 a 18 contra dias 1 a 18. A opção “período anterior completo” fica identificada no filtro.</p></div></div>` }),
});
