// CRM e Campanhas — segmentos dinâmicos, campanhas, templates, jornadas e histórico de comunicações.
import { S, ui, today, now, go } from '../ctx.js';
import { esc, money, fmtDate, fmtDateTime, fmtPhone, norm } from '../../util.js';
import { CAMPAIGN_STATUS, MSG_STATUS, CHANNELS, PURPOSES } from '../../domain/rules.js';
import { client, user, byId, hasPerm, renderTemplate } from '../../services/core.js';
import { clientStats } from '../../metrics/metrics.js';
import * as crm from '../../services/crm.js';
import { icon, registerActions, openSheet, closeSheet, refreshSheet, toast, confirmDialog, field, options, empty, badge, tabs, simBadge } from '../dom.js';
import { pct } from '../../util.js';

const campTone = { rascunho: 'neutral', aguardando: 'warn', agendada: 'info', processando: 'accent', concluida: 'good', cancelada: 'muted', falha: 'bad' };
export function render() {
  const s = S(); const C = ui.crm;
  const T = tabs([['segmentos', 'Segmentos'], ['campanhas', 'Campanhas'], ['jornadas', 'Jornadas automáticas'], ['templates', 'Templates'], ['historico', 'Histórico de comunicações']], C.tab, 'crm-tab');
  const banner = `<div class="callout sim" style="margin-bottom:16px">${icon('info')}<div><b>Provedor simulado.</b> Nenhuma mensagem real é enviada no protótipo. Entregas e leituras exibidas são simulações identificadas; conversões usam regra de atribuição sobre dados demonstrativos. Integração oficial com WhatsApp Business Platform e e-mail: etapa futura, mediante aprovação.</div></div>`;
  let body = '';
  if (C.tab === 'segmentos') {
    const defs = crm.segmentDefs(s);
    const main = defs.filter((d) => !d.byService); const bySvc = defs.filter((d) => d.byService);
    const card = (d) => { const m = crm.segmentMembers(s, d.id); const el = crm.eligibleCount(s, m, 'whatsapp', 'promocional'); return `<button class="card card-pad" style="text-align:left;cursor:pointer;font:inherit;color:inherit" data-action="seg-open" data-id="${d.id}"><div class="row-between"><span class="strong">${esc(d.name)}</span><span class="badge accent">${m.length}</span></div><p class="xs subtle" style="margin:4px 0 8px">${esc(d.criteria)}</p><div class="xs muted">${el} elegíveis para WhatsApp promocional</div></button>`; };
    body = `<div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(240px,1fr))">${main.map(card).join('')}</div>
    <h2 style="margin:24px 0 12px;font-size:14px">Clientes por serviço contratado</h2><div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(240px,1fr))">${bySvc.map(card).join('')}</div>
    <p class="xs subtle" style="margin-top:12px">Segmentos são recalculados automaticamente a cada agendamento, finalização, venda, pagamento, pacote ou consentimento. Limites ajustáveis em Configurações → Parâmetros de CRM. Dados de saúde não são usados para segmentar.</p>`;
  }
  if (C.tab === 'campanhas') {
    const list = [...s.campaigns].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    body = `<div class="card"><div class="table-wrap"><table class="table"><thead><tr><th>Campanha</th><th>Público</th><th>Canal</th><th>Status</th><th class="num">Destinatárias</th><th>Data</th></tr></thead><tbody>
    ${list.map((c) => `<tr class="clickable" data-action="camp-open" data-id="${c.id}"><td><div class="strong">${esc(c.name)}</div><div class="xs subtle">${esc(c.objective || '')}</div></td><td class="small">${esc(segName(s, c.segmentId))}</td><td>${CHANNELS[c.channel]}</td><td>${badge(CAMPAIGN_STATUS[c.status], campTone[c.status])}${c.executedAt ? ' ' + simBadge() : ''}</td><td class="num">${c.recipients.filter((r) => r.status !== 'bloqueada').length || '—'}</td><td class="nowrap small">${fmtDate(c.executedAt || c.scheduledAt || c.createdAt)}</td></tr>`).join('') || `<tr><td colspan="6">${empty('Nenhuma campanha', 'Crie a partir de um segmento.')}</td></tr>`}
    </tbody></table></div></div>`;
  }
  if (C.tab === 'templates') {
    body = `<div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(300px,1fr))">${s.templates.map((t) => `<section class="card"><div class="card-head"><h3>${esc(t.name)}</h3><span class="row">${badge(PURPOSES[t.purpose], t.purpose === 'promocional' ? 'warn' : 'info')}${badge(CHANNELS[t.channel], 'neutral')}</span></div><div class="card-body stack-sm"><p class="small" style="white-space:pre-wrap">${esc(t.text)}</p>${hasPerm(s, 'campanhas.criar') ? `<div><button class="btn sm" data-action="tpl-edit" data-id="${t.id}">Editar</button></div>` : ''}</div></section>`).join('')}</div>
    <p class="xs subtle" style="margin-top:12px">Variáveis: {{nome}}, {{servico}}, {{profissional}}, {{data}}, {{horario}}, {{estabelecimento}}. No WhatsApp oficial, templates precisam de aprovação prévia da Meta.</p>`;
  }
  if (C.tab === 'jornadas') {
    const pend = s.journeyExecutions.filter((e) => e.status === 'pendente');
    body = `<div class="card card-pad row-between wrap" style="margin-bottom:16px"><div><div class="strong">Relógio demonstrativo: ${fmtDate(s.settings.refDate)} ${s.settings.demoTime}</div><div class="xs muted">${pend.length} execução(ões) na fila. Sem processamento em segundo plano: a fila só anda quando você processa ou avança o tempo.</div></div>
      <div class="btn-group"><button class="btn" data-action="jr-process">${icon('play')}Processar fila agora</button><button class="btn" data-action="jr-advance" data-h="2">+2 horas</button><button class="btn" data-action="jr-advance" data-d="1">+1 dia</button></div></div>
    <div class="stack">${s.journeys.map((j) => { const t = byId(s.templates, j.templateId); const ex = s.journeyExecutions.filter((e) => e.journeyId === j.id); return `<section class="card"><div class="card-head"><h3>${esc(j.name)}</h3><span class="row">${j.active ? badge('Ativa', 'good') : badge('Pausada', 'muted')}<label class="switch" aria-label="${j.active ? 'Pausar' : 'Ativar'} jornada"><input type="checkbox" data-action="jr-toggle" data-id="${j.id}" ${j.active ? 'checked' : ''}><span></span></label></span></div>
      <div class="card-body stack-sm"><div class="flow">
        <div class="flow-step"><div class="fs-k">Gatilho</div><div class="fs-v">${esc(crm.TRIGGERS[j.trigger])}</div></div><div class="flow-arrow">${icon('arrowRight')}</div>
        <div class="flow-step"><div class="fs-k">Condição</div><div class="fs-v">${esc(j.condition || 'Elegível e com consentimento')}</div></div><div class="flow-arrow">${icon('arrowRight')}</div>
        <div class="flow-step"><div class="fs-k">Espera</div><div class="fs-v">${j.waitHours === 0 ? 'Imediato' : j.waitHours < 0 ? `${-j.waitHours} h antes` : j.waitHours % 24 === 0 ? `${j.waitHours / 24} dia(s) depois` : `${j.waitHours} h depois`}</div></div><div class="flow-arrow">${icon('arrowRight')}</div>
        <div class="flow-step"><div class="fs-k">Ação</div><div class="fs-v">${CHANNELS[j.channel]}: ${esc(t?.name || '—')}</div></div>
      </div>
      <div class="row-between wrap"><span class="xs muted">${ex.filter((e) => e.status === 'executada').length} executadas · ${ex.filter((e) => e.status === 'pendente').length} na fila · ${ex.filter((e) => e.status === 'bloqueada').length} bloqueadas · ${ex.filter((e) => e.status === 'cancelada').length} canceladas · ${ex.filter((e) => e.status === 'falhou').length} falhas</span>
      <div class="btn-group">${hasPerm(s, 'campanhas.criar') ? `<button class="btn sm" data-action="jr-edit" data-id="${j.id}">Editar</button>` : ''}<button class="btn sm" data-action="jr-sim" data-id="${j.id}">Simular com uma cliente</button><button class="btn sm ghost" data-action="jr-hist" data-id="${j.id}">Histórico</button></div></div></div></section>`; }).join('')}</div>`;
  }
  if (C.tab === 'historico') {
    const H = C.hist || (C.hist = { ch: '', st: '', type: '', q: '' });
    const list = s.communications.filter((m) => (!H.ch || m.channel === H.ch) && (!H.st || m.status === H.st) && (!H.type || (H.type === 'campanha' ? m.campaignId : m.journeyId)) && (!H.q || norm(client(s, m.clientId)?.name).includes(norm(H.q)))).sort((a, b) => b.at.localeCompare(a.at));
    body = `<div class="card"><div class="card-pad filters" style="border-bottom:1px solid var(--border)"><input class="input" style="max-width:220px" id="ch-q" placeholder="Buscar cliente" value="${esc(H.q)}"><select class="select" data-ch="ch">${options(Object.entries(CHANNELS).slice(0, 2), H.ch, { placeholder: 'Todos os canais' })}</select><select class="select" data-ch="st">${options(Object.entries(MSG_STATUS), H.st, { placeholder: 'Todos os status' })}</select><select class="select" data-ch="type">${options([['campanha', 'Campanhas'], ['jornada', 'Jornadas']], H.type, { placeholder: 'Campanhas e jornadas' })}</select></div>
    <div class="table-wrap"><table class="table"><thead><tr><th>Data</th><th>Cliente</th><th>Origem</th><th>Canal</th><th>Finalidade</th><th>Status</th></tr></thead><tbody>
    ${list.slice(0, 200).map((m) => `<tr><td class="nowrap small">${fmtDateTime(m.at)}</td><td>${esc(client(s, m.clientId)?.name)}</td><td class="small">${esc(byId(s.campaigns, m.campaignId)?.name || byId(s.journeys, m.journeyId)?.name || '—')}</td><td>${CHANNELS[m.channel]}</td><td class="small">${PURPOSES[m.purpose] || '—'}</td><td>${m.status === 'bloqueada' ? badge('Bloqueada' + (m.reason ? ': ' + m.reason : ''), 'warn') : simBadge(MSG_STATUS[m.status] || m.status)}</td></tr>`).join('') || `<tr><td colspan="6">${empty('Nenhuma comunicação', 'Ajuste os filtros.')}</td></tr>`}
    </tbody></table></div><p class="xs subtle card-pad">${list.length} registro(s). Todos os status são simulados — nenhuma mensagem real foi enviada.</p></div>`;
  }
  return `<div class="page-head"><div><h1>CRM e Campanhas</h1><p class="small muted">Relacionamento integrado à operação</p></div><div class="btn-group">${hasPerm(s, 'campanhas.criar') ? `<button class="btn" data-action="tpl-edit">${icon('file')}Novo template</button><button class="btn" data-action="jr-edit">${icon('zap')}Nova jornada</button><button class="btn primary" data-action="new-campaign">${icon('plus')}Nova campanha</button>` : ''}</div></div>${banner}${T}${body}`;
}
const segName = (s, id) => crm.segmentDefs(s).find((d) => d.id === id)?.name || id;
export function bindCRM(root) {
  const H = ui.crm.hist; if (!H) return;
  root.querySelectorAll('[data-ch]').forEach((el) => el.addEventListener('change', () => { H[el.dataset.ch] = el.value; window.__rerender(); }));
  root.querySelector('#ch-q')?.addEventListener('input', (e) => { H.q = e.target.value; clearTimeout(window.__cht); window.__cht = setTimeout(() => { window.__rerender(); const i = document.querySelector('#ch-q'); i?.focus(); i?.setSelectionRange(i.value.length, i.value.length); }, 250); });
}

function openSegment(id) {
  const st = { ch: 'whatsapp', pu: 'promocional' };
  openSheet({ title: 'Segmento', wide: true, render: () => {
    const s = S(); const d = crm.segmentDefs(s).find((x) => x.id === id); const m = crm.segmentMembers(s, id);
    const rows = m.map((c) => ({ c, el: crm.eligibility(s, c, st.ch, st.pu), stt: clientStats(s, c.id) }));
    const elig = rows.filter((r) => r.el.ok).length;
    return { title: d.name, html: `<div class="sheet-body stack"><div class="callout info">${icon('filter')}<div><b>Critério:</b> ${esc(d.criteria)}</div></div>
      <div class="kpis"><div class="kpi"><div class="k-label">Clientes no segmento</div><div class="k-value">${m.length}</div></div><div class="kpi"><div class="k-label">Elegíveis para ${CHANNELS[st.ch]} ${PURPOSES[st.pu].toLowerCase()}</div><div class="k-value">${elig}</div><div class="k-sub">${m.length - elig} sem consentimento ou contato</div></div></div>
      <div class="row wrap"><select class="select" style="width:auto" data-sg="ch">${options([['whatsapp', 'WhatsApp'], ['email', 'E-mail']], st.ch)}</select><select class="select" style="width:auto" data-sg="pu">${options([['promocional', 'Promocional'], ['operacional', 'Operacional']], st.pu)}</select><span class="xs subtle">Classificação comercial ≠ elegibilidade para mensagens.</span></div>
      <div class="card"><div class="table-wrap"><table class="table"><thead><tr><th>Cliente</th><th>Telefone</th><th>Última visita</th><th class="num">Valor</th><th>Elegível</th></tr></thead><tbody>${rows.slice(0, 150).map((r) => `<tr class="clickable" data-action="seg-go-client" data-id="${r.c.id}"><td>${esc(r.c.name)}</td><td class="nowrap">${fmtPhone(r.c.phone)}</td><td class="nowrap">${r.stt.lastVisit ? fmtDate(r.stt.lastVisit) : '—'}</td><td class="num">${money(r.stt.totalSales)}</td><td>${r.el.ok ? badge('Sim', 'good') : `<span class="badge muted" title="${esc(r.el.reason)}">Não — ${esc(r.el.reason)}</span>`}</td></tr>`).join('') || `<tr><td colspan="5">${empty('Segmento vazio', 'Nenhuma cliente atende ao critério agora.')}</td></tr>`}</tbody></table></div></div>
    </div><div class="sheet-foot">${hasPerm(s, 'campanhas.criar') ? `<button class="btn primary" data-action="new-campaign" data-seg="${id}">${icon('megaphone')}Criar campanha para este segmento</button>` : ''}</div>` };
  }, onMount: (root) => { root.querySelectorAll('[data-sg]').forEach((el) => el.addEventListener('change', () => { st[el.dataset.sg] = el.value; refreshSheet(); })); } });
}

export function openCampaignForm(id, segId) {
  const s0 = S(); const c0 = id ? byId(s0.campaigns, id) : null;
  const d = c0 ? { ...c0 } : { name: '', objective: '', segmentId: segId || 'sem_retorno_60', channel: 'whatsapp', purpose: 'promocional', templateId: 'tpl_reativacao', text: byId(s0.templates, 'tpl_reativacao').text, scheduledAt: '' };
  openSheet({ title: c0 ? 'Editar campanha' : 'Nova campanha', wide: true, render: () => {
    const s = S(); const m = crm.segmentMembers(s, d.segmentId); const elig = m.filter((c) => crm.eligibility(s, c, d.channel, d.purpose).ok); const sample = elig[0] || m[0];
    const preview = sample ? renderTemplate(d.text, crm.templateVars(s, sample, null)) : d.text;
    const tpls = s.templates.filter((t) => t.channel === d.channel);
    return `<form class="sheet-body stack" data-submit="camp-save" data-id="${id || ''}" id="camp-form" novalidate><div class="form-grid">
      ${field('Nome *', `<input class="input" name="name" value="${esc(d.name)}" data-cf="name">`)}
      ${field('Objetivo', `<input class="input" name="objective" value="${esc(d.objective)}" data-cf="objective" placeholder="Ex.: reativar clientes de sobrancelha">`)}
      ${field('Público (segmento) *', `<select class="select" name="segmentId" data-cf="segmentId">${options(crm.segmentDefs(s).map((x) => [x.id, `${x.name} (${crm.segmentMembers(s, x.id).length})`]), d.segmentId)}</select>`)}
      ${field('Canal', `<select class="select" data-cf="channel">${options([['whatsapp', 'WhatsApp'], ['email', 'E-mail'], ['sms', 'SMS (planejado)']], d.channel)}</select>`)}
      ${field('Finalidade', `<select class="select" data-cf="purpose">${options([['promocional', 'Promocional (exige consentimento)'], ['operacional', 'Operacional']], d.purpose)}</select>`)}
      ${field('Template', `<select class="select" data-cf="templateId">${options(tpls.map((t) => [t.id, t.name]), d.templateId, { placeholder: 'Sem template' })}</select>`)}
      <div class="full field"><label for="cf-text">Mensagem *</label><textarea class="textarea" id="cf-text" name="text" rows="4" data-cf="text">${esc(d.text)}</textarea><div class="row wrap" style="gap:4px">${['nome', 'servico', 'profissional', 'data', 'horario', 'estabelecimento'].map((v) => `<button type="button" class="btn sm ghost" data-action="cf-var" data-v="${v}">{{${v}}}</button>`).join('')}</div></div>
      ${field('Agendar envio para', `<input class="input" type="datetime-local" data-cf="scheduledAt" value="${esc(d.scheduledAt || '')}">`, { hint: 'Vazio = após a aprovação.' })}
    </div>
    <div class="grid g2"><div class="summary"><div class="strong" style="margin-bottom:6px">Verificação de elegibilidade</div><dl class="kv"><dt>No segmento</dt><dd>${m.length}</dd><dt>Elegíveis (${CHANNELS[d.channel]}, ${PURPOSES[d.purpose].toLowerCase()})</dt><dd>${d.channel === 'sms' ? 0 : elig.length}</dd><dt>Excluídas</dt><dd>${m.length - (d.channel === 'sms' ? 0 : elig.length)}</dd></dl><p class="xs subtle" style="margin-top:6px">A elegibilidade é verificada de novo no momento do envio.</p></div>
    <div><div class="label" style="margin-bottom:4px">Prévia${sample ? ' — ' + esc(sample.name.split(' ')[0]) : ''}</div><div style="background:#e7f6ea;border-radius:12px 12px 12px 2px;padding:10px 12px;font-size:13px;white-space:pre-wrap">${esc(preview)}</div></div></div>
    </form><div class="sheet-foot"><button class="btn" data-action="sheet-close">Cancelar</button><button class="btn primary" type="submit" form="camp-form">Salvar rascunho</button></div>`;
  }, onMount: (root) => { root._cf = d; root.querySelectorAll('[data-cf]').forEach((el) => { const ev = el.tagName === 'SELECT' || el.type === 'datetime-local' ? 'change' : 'input'; el.addEventListener(ev, () => { d[el.dataset.cf] = el.value; if (el.dataset.cf === 'templateId' && el.value) { const t = byId(S().templates, el.value); d.text = t.text; d.purpose = t.purpose; } if (el.dataset.cf === 'channel') d.templateId = ''; if (ev === 'change') refreshSheet(); }); el.addEventListener('blur', () => { if (el.dataset.cf === 'text') refreshSheet(); }); }); } });
}
function openCampaign(id) {
  openSheet({ title: 'Campanha', wide: true, render: () => {
    const s = S(); const c = byId(s.campaigns, id); const r = crm.campaignResults(s, c); const canApprove = hasPerm(s, 'campanhas.aprovar');
    const k = (l, v, sub = '') => `<div class="kpi"><div class="k-label">${l}</div><div class="k-value">${v}</div>${sub ? `<div class="k-sub">${sub}</div>` : ''}</div>`;
    const done = c.status === 'concluida';
    return { title: c.name, html: `<div class="sheet-body stack"><div class="row wrap">${badge(CAMPAIGN_STATUS[c.status], campTone[c.status])}${done ? simBadge('Execução simulada') : ''}<span class="small muted">${esc(segName(s, c.segmentId))} · ${CHANNELS[c.channel]} · ${PURPOSES[c.purpose || 'promocional']}</span></div>
      ${c.objective ? `<p class="small"><b>Objetivo:</b> ${esc(c.objective)}</p>` : ''}
      <div style="background:#e7f6ea;border-radius:12px 12px 12px 2px;padding:10px 12px;font-size:13px;white-space:pre-wrap">${esc(c.text)}</div>
      <dl class="kv small"><dt>Criada</dt><dd>${fmtDateTime(c.createdAt)} · ${esc(user(s, c.createdBy)?.name || '—')}</dd><dt>Aprovação</dt><dd>${c.approvedBy ? `${esc(user(s, c.approvedBy)?.name)} · ${fmtDateTime(c.approvedAt)}` : '—'}</dd><dt>Agendada para</dt><dd>${c.scheduledAt ? fmtDateTime(c.scheduledAt.replace(' ', 'T')) : '—'}</dd><dt>Executada</dt><dd>${c.executedAt ? fmtDateTime(c.executedAt) : '—'}</dd></dl>
      ${done ? `<h3>Relatório da campanha</h3><div class="kpis">${k('Público', r.audience)}${k('Elegíveis', r.eligible, `${r.blocked} bloqueadas por consentimento`)}${k('Enviadas', r.sent, 'simulado')}${k('Entregues', r.delivered, 'simulado')}${k('Lidas', r.read, 'simulado')}${k('Falhas', r.failed, 'simulado')}${k('Cliques', '—', 'indisponível: requer rastreamento real')}${k('Descadastros', r.optOuts, `em ${s.org.crm.attributionDays} dias`)}${k('Agendamentos atribuídos', r.bookings, `janela de ${s.org.crm.attributionDays} dias`)}${k('Vendas atribuídas', r.sales)}${k('Receita atribuída', money(r.revenue))}${k('Custo', '—', 'indisponível: sem provedor real')}</div>
      <p class="xs subtle">Atribuição demonstrativa: destinatária com mensagem simulada entregue que agendou ou comprou em até ${s.org.crm.attributionDays} dias após a execução. Não comprova causalidade. Métricas de entrega são simuladas.</p>
      <div class="card"><div class="table-wrap" style="max-height:280px"><table class="table"><thead><tr><th>Cliente</th><th>Status</th></tr></thead><tbody>${c.recipients.slice(0, 100).map((x) => `<tr><td>${esc(client(s, x.clientId)?.name)}</td><td>${x.status === 'bloqueada' ? badge('Bloqueada: ' + (x.reason || ''), 'warn') : simBadge(MSG_STATUS[x.status])}</td></tr>`).join('')}</tbody></table></div></div>` : `<div class="callout info">${icon('info')}<div>Fluxo: Rascunho → Aguardando aprovação → Agendada → Execução (simulada) → Concluída.</div></div>`}
    </div><div class="sheet-foot" style="flex-wrap:wrap">
      ${['rascunho', 'aguardando'].includes(c.status) && hasPerm(s, 'campanhas.criar') ? `<button class="btn" data-action="camp-edit" data-id="${c.id}">Editar</button>` : ''}
      ${c.status === 'rascunho' ? `<button class="btn primary" data-action="camp-submit" data-id="${c.id}">Enviar para aprovação</button>` : ''}
      ${c.status === 'aguardando' ? (canApprove ? `<button class="btn primary" data-action="camp-approve" data-id="${c.id}">Aprovar</button>` : '<span class="small muted">Aguardando aprovação da proprietária ou gestora.</span>') : ''}
      ${c.status === 'agendada' ? `<button class="btn accent" data-action="camp-exec" data-id="${c.id}">${icon('send')}Executar agora (simulado)</button>` : ''}
      ${!['concluida', 'cancelada'].includes(c.status) ? `<button class="btn danger" data-action="camp-cancel" data-id="${c.id}">Cancelar</button>` : ''}
      <button class="btn ghost" data-action="camp-dup" data-id="${c.id}">Duplicar</button></div>` };
  } });
}
function openTemplate(id) {
  const s = S(); const t = id ? byId(s.templates, id) : null;
  openSheet({ title: t ? 'Editar template' : 'Novo template', render: () => `<form class="sheet-body stack" data-submit="tpl-save" data-id="${id || ''}" id="tpl-form"><div class="form-grid">
    ${field('Nome *', `<input class="input" name="name" value="${esc(t?.name || '')}">`, { full: true })}
    ${field('Tipo', `<select class="select" name="type">${options([['confirmacao', 'Confirmação'], ['lembrete', 'Lembrete'], ['pos', 'Pós-atendimento'], ['aniversario', 'Aniversário'], ['reativacao', 'Reativação'], ['pacote', 'Pacote próximo do fim'], ['promocional', 'Promocional']], t?.type || 'promocional')}</select>`)}
    ${field('Finalidade', `<select class="select" name="purpose">${options([['operacional', 'Operacional'], ['promocional', 'Promocional']], t?.purpose || 'promocional')}</select>`)}
    ${field('Canal', `<select class="select" name="channel">${options([['whatsapp', 'WhatsApp'], ['email', 'E-mail']], t?.channel || 'whatsapp')}</select>`)}
    ${field('Assunto (e-mail)', `<input class="input" name="subject" value="${esc(t?.subject || '')}">`)}
    ${field('Texto *', `<textarea class="textarea" name="text" rows="5">${esc(t?.text || '')}</textarea>`, { full: true, hint: 'Variáveis: {{nome}} {{servico}} {{profissional}} {{data}} {{horario}} {{estabelecimento}}' })}
  </div></form><div class="sheet-foot"><button class="btn" data-action="sheet-close">Cancelar</button><button class="btn primary" type="submit" form="tpl-form">Salvar</button></div>` });
}
function openJourney(id) {
  const s = S(); const j = id ? byId(s.journeys, id) : null;
  openSheet({ title: j ? 'Editar jornada' : 'Nova jornada', render: () => `<form class="sheet-body stack" data-submit="jr-save" data-id="${id || ''}" id="jr-form"><p class="small muted">Estrutura: Gatilho → Condição → Espera → Ação. Elegibilidade e consentimento são revalidados antes de cada envio.</p><div class="form-grid">
    ${field('Nome *', `<input class="input" name="name" value="${esc(j?.name || '')}">`, { full: true })}
    ${field('1. Gatilho', `<select class="select" name="trigger">${options(Object.entries(crm.TRIGGERS), j?.trigger || 'appointment.completed')}</select>`, { full: true })}
    ${field('2. Condição', `<input class="input" name="condition" value="${esc(j?.condition || '')}" placeholder="Ex.: atendimento realizado">`, { full: true, hint: 'Descritiva no protótipo. Sempre exige elegibilidade e consentimento.' })}
    ${field('3. Espera (horas)', `<input class="input" type="number" name="waitHours" value="${j?.waitHours ?? 24}">`, { hint: 'Negativo = antes do horário (lembretes).' })}
    ${field('Canal', `<select class="select" name="channel">${options([['whatsapp', 'WhatsApp'], ['email', 'E-mail']], j?.channel || 'whatsapp')}</select>`)}
    ${field('4. Ação: template', `<select class="select" name="templateId">${options(s.templates, j?.templateId, { placeholder: 'Escolha' })}</select>`, { full: true })}
  </div></form><div class="sheet-foot"><button class="btn" data-action="sheet-close">Cancelar</button><button class="btn primary" type="submit" form="jr-form">Salvar</button></div>` });
}
function openJourneyHistory(id) {
  openSheet({ title: 'Histórico de execução', wide: true, render: () => { const s = S(); const list = s.journeyExecutions.filter((e) => e.journeyId === id).sort((a, b) => (b.at || b.dueAt).localeCompare(a.at || a.dueAt));
    return `<div class="sheet-body"><div class="card"><div class="table-wrap"><table class="table"><thead><tr><th>Cliente</th><th>Previsto</th><th>Status</th><th>Observação</th></tr></thead><tbody>${list.map((e) => `<tr><td>${esc(client(s, e.clientId)?.name)}</td><td class="nowrap small">${fmtDateTime(e.dueAt)}</td><td>${badge({ pendente: 'Na fila', executada: 'Executada (sim.)', bloqueada: 'Bloqueada', cancelada: 'Cancelada', falhou: 'Falhou (sim.)' }[e.status], { pendente: 'info', executada: 'good', bloqueada: 'warn', cancelada: 'muted', falhou: 'bad' }[e.status])}</td><td class="small">${esc(e.note || e.source || '')}</td></tr>`).join('') || `<tr><td colspan="4">${empty('Sem execuções', 'Crie agendamentos, finalize atendimentos ou simule.')}</td></tr>`}</tbody></table></div></div></div>`; } });
}
function openJourneySim(id) {
  const st = { clientId: '' };
  openSheet({ title: 'Simular jornada', render: () => { const s = S(); const j = byId(s.journeys, id); return `<div class="sheet-body stack"><p class="small muted">Dispara a jornada “${esc(j.name)}” agora para a cliente escolhida, passando pelas mesmas verificações de elegibilidade e consentimento. O envio é simulado.</p>
    <div class="field"><label>Cliente</label><select class="select" id="sim-c">${options(s.clients.filter((c) => !c.mergedInto).slice(0, 300).map((c) => [c.id, `${c.name} — ${c.consents[j.channel]?.[byId(s.templates, j.templateId)?.purpose || 'operacional'] ? 'com consentimento' : 'SEM consentimento'}`]), st.clientId, { placeholder: 'Escolha' })}</select></div></div>
    <div class="sheet-foot"><button class="btn" data-action="sheet-close">Fechar</button><button class="btn primary" data-action="jr-sim-run" data-id="${id}">Simular agora</button></div>`; } });
}
registerActions({
  'crm-tab': (el) => { ui.crm.tab = el.dataset.value; window.__rerender(); },
  'seg-open': (el) => openSegment(el.dataset.id),
  'seg-go-client': (el) => { import('../dom.js').then((m) => { m.closeAllSheets(); go('/clientes/' + el.dataset.id + '/crm'); }); },
  'new-campaign': (el) => { closeIfSegment(); openCampaignForm(null, el?.dataset?.seg); },
  'camp-open': (el) => openCampaign(el.dataset.id),
  'camp-edit': (el) => openCampaignForm(el.dataset.id),
  'cf-var': (el) => { const root = el.closest('.overlay'); const ta = root.querySelector('#cf-text'); const v = `{{${el.dataset.v}}}`; const p = ta.selectionStart ?? ta.value.length; ta.value = ta.value.slice(0, p) + v + ta.value.slice(ta.selectionEnd ?? p); root._cf.text = ta.value; refreshSheet(); },
  'camp-save': (form) => { const d = form.closest('.overlay')._cf; const c = crm.saveCampaign({ id: form.dataset.id || undefined, ...d, scheduledAt: d.scheduledAt ? d.scheduledAt.replace('T', 'T').slice(0, 16) : null }); closeSheet(); toast('Campanha salva como rascunho.'); ui.crm.tab = 'campanhas'; window.__rerender(); openCampaign(c.id); },
  'camp-submit': (el) => { crm.submitCampaign(el.dataset.id); toast('Enviada para aprovação.'); },
  'camp-approve': (el) => { crm.approveCampaign(el.dataset.id); toast('Campanha aprovada e agendada.'); },
  'camp-exec': async (el) => { if (await confirmDialog({ title: 'Executar campanha (simulado)?', message: 'Nenhuma mensagem real será enviada. O provedor simulado registra entregas fictícias apenas para demonstração.', confirmLabel: 'Executar simulação' })) { const c = crm.executeCampaign(el.dataset.id); toast(`Simulação concluída: ${c.recipients.filter((r) => r.status !== 'bloqueada').length} mensagens simuladas.`); } },
  'camp-cancel': async (el) => { if (await confirmDialog({ title: 'Cancelar campanha?', message: 'Ela não poderá mais ser executada.', confirmLabel: 'Cancelar campanha', danger: true })) { crm.cancelCampaign(el.dataset.id); toast('Campanha cancelada.'); } },
  'camp-dup': (el) => { const c = crm.duplicateCampaign(el.dataset.id); closeSheet(); toast('Cópia criada como rascunho.'); openCampaign(c.id); },
  'tpl-edit': (el) => openTemplate(el?.dataset?.id),
  'tpl-save': (form, d) => { crm.saveTemplate({ id: form.dataset.id || undefined, ...d }); closeSheet(); toast('Template salvo.'); },
  'jr-edit': (el) => openJourney(el?.dataset?.id),
  'jr-save': (form, d) => { crm.saveJourney({ id: form.dataset.id || undefined, ...d }); closeSheet(); toast('Jornada salva. Ative-a para começar a usar.'); },
  'jr-toggle': (el) => { crm.toggleJourney(el.dataset.id); toast('Jornada atualizada.'); },
  'jr-hist': (el) => openJourneyHistory(el.dataset.id),
  'jr-sim': (el) => openJourneySim(el.dataset.id),
  'jr-sim-run': (el) => { const v = el.closest('.overlay').querySelector('#sim-c').value; if (!v) { toast('Escolha a cliente.', 'err'); return; } const r = crm.simulateTrigger(el.dataset.id, v); closeSheet(); toast(r.sent ? 'Mensagem simulada registrada no histórico.' : r.blocked ? 'Bloqueada: a cliente não tem consentimento para este tipo de mensagem.' : 'Nada a enviar.'); },
  'jr-process': () => { const r = crm.processQueue(); toast(`Fila processada: ${r.sent} simuladas, ${r.blocked} bloqueadas, ${r.cancelled} canceladas.`); },
  'jr-advance': (el) => { const r = crm.advanceTime({ days: Number(el.dataset.d || 0), hours: Number(el.dataset.h || 0) }); toast(`Relógio avançado. ${r.sent} mensagem(ns) simulada(s), ${r.blocked} bloqueada(s).`); },
});
function closeIfSegment() { const o = document.querySelector('.overlay'); if (o && o.querySelector('.sheet-head h2')) import('../dom.js').then(() => {}); }
