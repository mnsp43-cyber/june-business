// Clientes — base pesquisável, perfil completo, cadastro, duplicidades e consentimentos.
import { S, ui, today, go } from '../ctx.js';
import { esc, money, fmtDate, fmtDateTime, fmtPhone, maskPhoneInput, initials, diffDays, normalizePhone, toCSV, norm } from '../../util.js';
import { STATUS, ORIGINS, CHANNELS, PURPOSES, SETTLEMENT } from '../../domain/rules.js';
import { client, service, professional, user, byId, activeClients, duplicateCandidates, searchClients, hasPerm, saleTotal, salePaid, saleSituation, packageRemaining, packageState, packageUsed } from '../../services/core.js';
import { clientStats } from '../../metrics/metrics.js';
import { clientSegments } from '../../services/crm.js';
import * as op from '../../services/operations.js';
import { icon, registerActions, openSheet, closeSheet, toast, confirmDialog, field, options, empty, badge, statusBadge, tabs, simBadge } from '../dom.js';
import { openNewAppointment } from '../appointments.js';
import { methodLabel } from '../appointments.js';
import { download } from '../util-ui.js';

const PAGE = 40;
export function render() {
  const s = S(); const C = ui.clientes;
  const dups = duplicateCandidates(s);
  let list = C.q ? searchClients(s, C.q) : activeClients(s);
  const inact = s.org.crm.inactivityDays;
  const f = C.filter;
  if (f) list = list.filter((c) => { const st = clientStats(s, c.id); return f === 'novas' ? st.firstVisit && diffDays(today(), st.firstVisit) <= 30 : f === 'recorrentes' ? st.visitCount >= 2 && st.daysSince <= inact : f === 'inativas' ? st.daysSince > inact : f === 'leads' ? st.visitCount === 0 : f === 'pendencia' ? st.pending > 0 : f === 'pacote' ? st.activePackages.length > 0 : true; });
  const sorters = { nome: (a, b) => a.name.localeCompare(b.name), recente: (a, b) => (clientStats(s, b.id).lastVisit || '').localeCompare(clientStats(s, a.id).lastVisit || ''), valor: (a, b) => clientStats(s, b.id).totalSales - clientStats(s, a.id).totalSales, cadastro: (a, b) => b.createdAt.localeCompare(a.createdAt) };
  list = [...list].sort(sorters[C.sort] || sorters.nome);
  const shown = list.slice(0, C.page * PAGE);
  return `
  <div class="page-head"><div><h1>Clientes</h1><p class="small muted">${activeClients(s).length} cadastros · construídos automaticamente a partir dos agendamentos</p></div>
    <div class="btn-group"><button class="btn" data-action="cli-export">${icon('download')}CSV</button><button class="btn primary" data-action="new-client">${icon('plus')}Novo cliente</button></div></div>
  ${dups.length ? `<div class="callout warn" style="margin-bottom:12px">${icon('merge')}<div class="grow">${dups.length} possível(is) duplicidade(s) encontrada(s). Nada é mesclado sem sua autorização. <button class="btn sm" style="margin-left:8px" data-action="cli-dups">Revisar</button></div></div>` : ''}
  <div class="card">
    <div class="card-pad stack-sm" style="border-bottom:1px solid var(--border)">
      <div class="input-icon">${icon('search')}<input class="input" id="cli-q" placeholder="Buscar por nome, telefone ou e-mail" value="${esc(C.q)}" aria-label="Buscar clientes"></div>
      <div class="row wrap" style="justify-content:space-between">
        <div class="chips">${[['', 'Todas'], ['novas', 'Novas (30 dias)'], ['recorrentes', 'Recorrentes'], ['inativas', `Inativas (+${inact} dias)`], ['leads', 'Leads'], ['pendencia', 'Com pendência'], ['pacote', 'Com pacote']].map(([v, l]) => `<button class="chip" aria-pressed="${C.filter === v}" data-action="cli-filter" data-v="${v}">${l}</button>`).join('')}</div>
        <select class="select" style="width:auto;height:32px;font-size:12px" id="cli-sort" aria-label="Ordenar">${options([['nome', 'Nome A–Z'], ['recente', 'Visita mais recente'], ['valor', 'Maior valor'], ['cadastro', 'Cadastro mais novo']], C.sort)}</select>
      </div>
    </div>
    <div id="cli-list">${listHtml(s, shown, list.length)}</div>
  </div>`;
}
function listHtml(s, shown, total) {
  if (!shown.length) return empty('Nenhuma cliente encontrada', 'Ajuste a busca ou os filtros.', '', 'search');
  return `<div class="table-wrap hide-mobile"><table class="table"><thead><tr><th>Cliente</th><th>Telefone</th><th>Última visita</th><th class="num">Atend.</th><th class="num">Valor acumulado</th><th class="num">Pendente</th><th>Segmento</th></tr></thead><tbody>
  ${shown.map((c) => { const st = clientStats(s, c.id); const seg = st.visitCount === 0 ? badge('Lead', 'info') : st.daysSince > s.org.crm.inactivityDays ? badge('Inativa', 'muted') : st.visitCount === 1 ? badge('Nova', 'accent') : badge('Recorrente', 'good'); return `<tr class="clickable" data-action="go" data-to="/clientes/${c.id}"><td><div class="row"><div class="avatar">${initials(c.name)}</div><div><div class="strong">${esc(c.name)}</div><div class="xs subtle">${esc(c.origin)}</div></div></div></td><td class="nowrap">${fmtPhone(c.phone)}</td><td class="nowrap">${st.lastVisit ? `${fmtDate(st.lastVisit)} <span class="xs subtle">(${st.daysSince} d)</span>` : '—'}</td><td class="num">${st.visitCount}</td><td class="num">${money(st.totalSales)}</td><td class="num" style="color:${st.pending ? 'var(--bad)' : 'inherit'}">${st.pending ? money(st.pending) : '—'}</td><td>${seg}</td></tr>`; }).join('')}
  </tbody></table></div>
  <div class="list show-mobile">${shown.map((c) => { const st = clientStats(s, c.id); return `<button class="list-item" data-action="go" data-to="/clientes/${c.id}"><div class="avatar">${initials(c.name)}</div><div class="li-main"><div class="li-title">${esc(c.name)}</div><div class="li-sub">${fmtPhone(c.phone)} · ${st.lastVisit ? 'últ. ' + fmtDate(st.lastVisit) : 'sem visitas'}</div></div>${st.pending ? `<span class="badge bad">${money(st.pending)}</span>` : ''}</button>`; }).join('')}</div>
  ${shown.length < total ? `<div class="card-pad" style="text-align:center"><button class="btn" data-action="cli-more">Mostrar mais (${total - shown.length})</button></div>` : `<p class="xs subtle card-pad">${total} cliente(s)</p>`}`;
}
export function bindClientes(root) {
  const q = root.querySelector('#cli-q'); if (q) q.addEventListener('input', () => { ui.clientes.q = q.value; ui.clientes.page = 1; const s = S(); const C = ui.clientes; let list = C.q ? searchClients(s, C.q) : activeClients(s); root.querySelector('#cli-list').innerHTML = listHtml(s, list.slice(0, PAGE), list.length); });
  root.querySelector('#cli-sort')?.addEventListener('change', (e) => { ui.clientes.sort = e.target.value; window.__rerender(); });
}

// ---------- Perfil completo ----------
export function renderProfile(id, tab = 'visao') {
  const s = S(); const c = client(s, id);
  if (!c) return empty('Cliente não encontrada', 'O cadastro pode ter sido mesclado.', '<button class="btn" data-action="go" data-to="/clientes">Voltar</button>');
  if (c.mergedInto) return empty('Cadastro mesclado', `Este cadastro foi mesclado em outro.`, `<button class="btn primary" data-action="go" data-to="/clientes/${c.mergedInto}">Abrir cadastro principal</button>`, 'merge');
  const st = clientStats(s, id); const segs = clientSegments(s, id);
  const appts = s.appointments.filter((a) => a.clientId === id).sort((a, b) => (b.date + b.start).localeCompare(a.date + a.start));
  const T = [['visao', 'Visão geral'], ['historico', 'Histórico'], ['pacotes', 'Pacotes'], ['financeiro', 'Financeiro'], ['crm', 'CRM']];
  let body = '';
  if (tab === 'visao') body = `<div class="kpis">${[['Atendimentos', st.visitCount], ['Primeira visita', st.firstVisit ? fmtDate(st.firstVisit) : '—'], ['Última visita', st.lastVisit ? fmtDate(st.lastVisit) : '—'], ['Dias sem visita', st.daysSince ?? '—'], ['Frequência média', st.avgFrequency ? `${st.avgFrequency} dias` : '—'], ['Compras', st.purchases], ['Valor acumulado', money(st.totalSales)], ['Ticket médio', st.ticket ? money(st.ticket) : '—'], ['Pendente', money(st.pending)], ['Sessões de pacote', st.sessionsLeft], ['Faltas', st.noShows], ['Cancelamentos', st.cancels]].map(([l, v]) => `<div class="kpi"><div class="k-label">${l}</div><div class="k-value" style="font-size:17px">${v}</div></div>`).join('')}</div>
    <div class="grid g2" style="margin-top:16px">
      <section class="card card-pad stack-sm"><h3>Cadastro</h3><dl class="kv"><dt>Telefone/WhatsApp</dt><dd>${fmtPhone(c.phone)}</dd><dt>E-mail</dt><dd>${esc(c.email || '—')}</dd><dt>Nascimento</dt><dd>${c.birth ? fmtDate(c.birth) : '—'}</dd><dt>Origem</dt><dd>${esc(c.origin)}</dd><dt>Cadastro</dt><dd>${fmtDate(c.createdAt)}</dd><dt>Identificador</dt><dd class="xs subtle">${c.id}</dd></dl>${c.preferences ? `<p class="small"><b>Preferências:</b> ${esc(c.preferences)}</p>` : ''}${c.notes ? `<p class="small"><b>Observações:</b> ${esc(c.notes)}</p>` : ''}</section>
      <section class="card card-pad stack-sm"><h3>Serviços e profissionais</h3><div class="chips">${st.services.map((x) => badge(service(s, x)?.name || '', 'neutral')).join('') || '<span class="small subtle">Nenhum serviço realizado ainda.</span>'}</div><div class="chips">${st.professionals.map((x) => badge(professional(s, x)?.name || '', 'accent')).join('')}</div>
        <h3 style="margin-top:8px">Próximos agendamentos</h3>${st.future.length ? st.future.map((a) => `<button class="list-item" style="padding:6px 0;min-height:40px" data-action="appt-open" data-id="${a.id}"><div class="li-main"><div class="li-sub" style="color:var(--text)">${fmtDate(a.date)} ${a.start} · ${esc(service(s, a.serviceId).name)}</div></div>${statusBadge(a.status)}</button>`).join('') : '<p class="small subtle">Nenhum.</p>'}
        <h3 style="margin-top:8px">Segmentos CRM</h3><div class="chips">${segs.map((x) => badge(x.name, 'info')).join('') || '<span class="small subtle">Nenhum.</span>'}</div></section></div>`;
  if (tab === 'historico') body = timelineHtml(s, c, appts);
  if (tab === 'pacotes') body = packagesHtml(s, c, st);
  if (tab === 'financeiro') body = financeHtml(s, c);
  if (tab === 'crm') body = crmHtml(s, c, segs);
  return `
  <div class="row" style="margin-bottom:8px"><button class="btn ghost sm" data-action="go" data-to="/clientes">${icon('left')}Clientes</button></div>
  <div class="card card-pad" style="margin-bottom:16px"><div class="row-between wrap"><div class="row" style="gap:12px"><div class="avatar lg">${initials(c.name)}</div><div><h1>${esc(c.name)}</h1><div class="small muted">${fmtPhone(c.phone)}${c.email ? ' · ' + esc(c.email) : ''}</div><div class="chips" style="margin-top:6px">${segs.slice(0, 4).map((x) => badge(x.name, 'info')).join('')}</div></div></div>
    <div class="btn-group"><button class="btn primary" data-action="cli-new-appt" data-id="${c.id}">${icon('calendar')}Agendar</button>${hasPerm(s, 'pagamentos.registrar') ? `<button class="btn" data-action="cli-sell-pkg" data-id="${c.id}">${icon('box')}Vender pacote</button>` : ''}<button class="btn" data-action="cli-edit" data-id="${c.id}">${icon('edit')}Editar</button></div></div></div>
  ${tabs(T, tab, 'cli-tab')}
  ${body}`;
}
function timelineHtml(s, c, appts) {
  const ev = [];
  for (const a of appts) { const sv = service(s, a.serviceId); ev.push({ at: `${a.date}T${a.start}`, tone: STATUS[a.status].tone === 'good' ? 'good' : STATUS[a.status].tone === 'bad' ? 'bad' : 'info', ic: 'calendar', text: `${STATUS[a.status].label}: ${sv.name} com ${professional(s, a.professionalId).name.split(' ')[0]}${a.checkout ? ` · ${SETTLEMENT[a.checkout.settlement]}` : ''}`, id: a.id }); }
  for (const x of s.sales.filter((y) => y.clientId === c.id && !y.appointmentId)) ev.push({ at: x.createdAt, tone: 'accent', ic: 'cash', text: `Venda${x.type === 'pacote' ? ' de pacote' : ' avulsa'}: ${x.items.map((i) => i.description).join(', ')} · ${money(saleTotal(x))}${x.status !== 'valida' ? ' (cancelada)' : ''}` });
  for (const p of s.payments.filter((y) => y.clientId === c.id)) ev.push({ at: p.createdAt, tone: p.kind === 'estorno' ? 'bad' : 'good', ic: 'wallet', text: `${p.kind === 'estorno' ? 'Estorno' : 'Pagamento recebido'}: ${money(Math.abs(p.amount))} · ${methodLabel(p.method)}${p.date !== p.createdAt.slice(0, 10) ? ` (data ${fmtDate(p.date)})` : ''}` });
  for (const m of s.communications.filter((y) => y.clientId === c.id)) ev.push({ at: m.at, tone: 'info', ic: 'message', text: `${m.campaignId ? 'Campanha' : 'Jornada'}: ${esc(byId(s.campaigns, m.campaignId)?.name || byId(s.journeys, m.journeyId)?.name || 'mensagem')} — ${m.status === 'bloqueada' ? 'bloqueada (consentimento)' : m.status + ' (simulado)'}`, sim: true });
  for (const h of s.consentHistory.filter((y) => y.clientId === c.id)) ev.push({ at: h.at, tone: h.value ? 'good' : 'bad', ic: 'lock', text: `Consentimento ${CHANNELS[h.channel]}/${PURPOSES[h.purpose].toLowerCase()}: ${h.value ? 'autorizado' : 'revogado'} · ${esc(h.origin)}` });
  ev.sort((a, b) => b.at.localeCompare(a.at));
  return `<div class="card card-pad">${ev.length ? `<ol class="timeline">${ev.slice(0, 120).map((e) => `<li><span class="t-dot ${e.tone}">${icon(e.ic)}</span><div><div class="t-text">${e.id ? `<a href="#" data-action="appt-open" data-id="${e.id}">${esc(e.text)}</a>` : esc(e.text)}</div><div class="t-when">${fmtDateTime(e.at)}</div></div></li>`).join('')}</ol>` : empty('Sem histórico', 'Os eventos aparecem aqui automaticamente.')}</div>`;
}
function packagesHtml(s, c, st) {
  const list = st.packages;
  return `<div class="stack">${hasPerm(s, 'pagamentos.registrar') ? `<div><button class="btn" data-action="cli-sell-pkg" data-id="${c.id}">${icon('plus')}Vender pacote</button></div>` : ''}
  ${list.length ? list.map((cp) => { const p = byId(s.packages, cp.packageId); const ps = packageState(s, cp, today()); const uses = s.packageUsage.filter((u) => u.clientPackageId === cp.id); return `<section class="card"><div class="card-head"><h3>${esc(p.name)}</h3>${badge(ps.label, ps.tone)}</div><div class="card-body stack-sm"><dl class="kv"><dt>Compra</dt><dd>${fmtDate(cp.purchaseDate)}</dd><dt>Validade</dt><dd>${fmtDate(cp.expiresAt)}</dd><dt>Sessões</dt><dd>${packageUsed(s, cp)} usadas de ${cp.sessionsTotal} · <b>${packageRemaining(s, cp)} restantes</b></dd>${cp.items.length > 1 ? cp.items.map((it) => `<dt>${esc(service(s, it.serviceId).name)}</dt><dd>${packageRemaining(s, cp, it.serviceId)} de ${it.sessions}</dd>`).join('') : ''}</dl>
    <div class="small muted"><b>Consumo:</b> ${uses.length ? uses.map((u) => `${fmtDate(u.date)} (${esc(service(s, u.serviceId).name)})`).join(' · ') : 'nenhuma sessão usada'}</div></div></section>`; }).join('') : `<div class="card">${empty('Nenhum pacote', 'Pacotes vendidos para esta cliente aparecem aqui com saldo e validade.', '', 'box')}</div>`}</div>`;
}
function financeHtml(s, c) {
  const sales = s.sales.filter((x) => x.clientId === c.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return `<div class="card"><div class="table-wrap"><table class="table"><thead><tr><th>Data</th><th>Itens</th><th class="num">Total</th><th class="num">Recebido</th><th class="num">Saldo</th><th>Situação</th><th></th></tr></thead><tbody>
  ${sales.length ? sales.map((x) => { const sit = saleSituation(s, x); const bal = x.status === 'valida' ? saleTotal(x) - salePaid(s, x.id) : 0; return `<tr><td class="nowrap">${fmtDate(x.date)}</td><td>${esc(x.items.map((i) => i.description).join(', '))}</td><td class="num">${money(saleTotal(x))}</td><td class="num">${money(salePaid(s, x.id))}</td><td class="num">${money(bal)}</td><td>${badge(sit.label, sit.tone)}</td><td class="right">${bal > 0 && hasPerm(s, 'pagamentos.registrar') ? `<button class="btn sm" data-action="fin-receive" data-id="${x.id}">Receber</button>` : `<button class="btn sm ghost" data-action="fin-sale" data-id="${x.id}">Ver</button>`}</td></tr>`; }).join('') : `<tr><td colspan="7">${empty('Sem vendas', 'Vendas e recebimentos aparecem aqui.')}</td></tr>`}
  </tbody></table></div></div>`;
}
function crmHtml(s, c, segs) {
  const row = (ch) => `<tr><td>${CHANNELS[ch]}</td>${['operacional', 'promocional'].map((pu) => `<td><label class="switch" aria-label="${CHANNELS[ch]} ${pu}"><input type="checkbox" data-action="cli-consent" data-id="${c.id}" data-ch="${ch}" data-pu="${pu}" ${c.consents[ch]?.[pu] ? 'checked' : ''} ${ch === 'sms' ? 'disabled' : ''}><span></span></label></td>`).join('')}</tr>`;
  const msgs = s.communications.filter((m) => m.clientId === c.id).sort((a, b) => b.at.localeCompare(a.at));
  return `<div class="grid g2"><section class="card"><div class="card-head"><h3>Consentimentos por canal e finalidade</h3></div><div class="card-body stack-sm"><table class="table"><thead><tr><th>Canal</th><th>Operacional</th><th>Promocional</th></tr></thead><tbody>${row('whatsapp')}${row('email')}${row('sms')}</tbody></table>
    <p class="xs subtle">Operacional: confirmações e lembretes. Promocional: campanhas e ofertas — exige autorização. SMS planejado para evolução.</p>
    <h3 style="margin-top:8px">Histórico de consentimento</h3><div class="small">${s.consentHistory.filter((h) => h.clientId === c.id).sort((a, b) => b.at.localeCompare(a.at)).map((h) => `<div class="row-between" style="padding:4px 0;border-bottom:1px solid var(--border)"><span>${CHANNELS[h.channel]} · ${PURPOSES[h.purpose]} · ${h.value ? 'autorizado' : '<b style="color:var(--bad)">revogado</b>'}<br><span class="xs subtle">${esc(h.origin)}</span></span><span class="xs subtle nowrap">${fmtDateTime(h.at)}</span></div>`).join('') || '<p class="subtle">Sem registros.</p>'}</div></div></section>
    <section class="card"><div class="card-head"><h3>Segmentos e comunicações</h3></div><div class="card-body stack-sm"><div class="chips">${segs.map((x) => badge(x.name, 'info')).join('') || '<span class="small subtle">Nenhum segmento.</span>'}</div>
    <h3 style="margin-top:8px">Comunicações</h3>${msgs.length ? msgs.slice(0, 20).map((m) => `<div class="row-between small" style="padding:4px 0;border-bottom:1px solid var(--border)"><span class="ellipsis">${esc(byId(s.campaigns, m.campaignId)?.name || byId(s.journeys, m.journeyId)?.name || 'Mensagem')}<br><span class="xs subtle">${CHANNELS[m.channel]} · ${PURPOSES[m.purpose] || ''} · ${fmtDateTime(m.at)}</span></span>${simBadge(m.status === 'bloqueada' ? 'Bloqueada' : (m.status || '') + ' (sim.)')}</div>`).join('') : '<p class="small subtle">Nenhuma comunicação.</p>'}
    </div></section></div>`;
}

// ---------- Cadastro / edição ----------
export function openClientForm(id) {
  const s = S(); const c = id ? client(s, id) : null;
  openSheet({ title: c ? 'Editar cliente' : 'Novo cliente', render: () => `<form class="sheet-body stack" data-submit="cli-save" data-id="${id || ''}" id="cli-form" novalidate>
    <div class="form-grid">
      ${field('Nome completo *', `<input class="input" name="name" value="${esc(c?.name || '')}" autocomplete="off">`, { full: true })}
      ${field('Telefone / WhatsApp *', `<input class="input" name="phone" inputmode="tel" value="${c ? fmtPhone(c.phone) : ''}" data-mask="phone" placeholder="(11) 90000-0000">`)}
      ${field('E-mail', `<input class="input" name="email" type="email" value="${esc(c?.email || '')}">`)}
      ${field('Nascimento', `<input class="input" name="birth" type="date" value="${c?.birth || ''}">`)}
      ${field('Origem comercial', `<select class="select" name="origin">${options(ORIGINS.map((o) => [o, o]), c?.origin || 'Indicação')}</select>`)}
      ${field('Preferências', `<input class="input" name="preferences" value="${esc(c?.preferences || '')}" placeholder="Ex.: prefere horários pela manhã">`, { full: true })}
      ${field('Observações administrativas', `<textarea class="textarea" name="notes">${esc(c?.notes || '')}</textarea>`, { full: true, hint: 'Não registre prontuário, diagnóstico ou dados de saúde.' })}
      ${!c ? `<div class="full stack-sm"><span class="label">Consentimentos informados pela cliente</span><label class="check"><input type="checkbox" name="wOp" checked>WhatsApp — mensagens operacionais (confirmação, lembrete)</label><label class="check"><input type="checkbox" name="wPr">WhatsApp — mensagens promocionais</label><label class="check"><input type="checkbox" name="ePr">E-mail — mensagens promocionais</label></div>` : ''}
    </div><div id="cli-dupwarn"></div></form>
    <div class="sheet-foot"><button class="btn" data-action="sheet-close">Cancelar</button><button class="btn primary" type="submit" form="cli-form">Salvar</button></div>`,
    onMount: (root) => { const ph = root.querySelector('[data-mask=phone]'); ph.addEventListener('input', () => { ph.value = maskPhoneInput(ph.value); const m = activeClients(S()).filter((x) => x.phone === normalizePhone(ph.value) && x.id !== id); root.querySelector('#cli-dupwarn').innerHTML = m.length ? `<div class="callout warn">${icon('alert')}<div>Já existe cadastro com este telefone: ${m.map((x) => `<b>${esc(x.name)}</b>`).join(', ')}. Se for a mesma pessoa, use o cadastro existente; se for telefone compartilhado, pode salvar.</div></div>` : ''; }); } });
}
registerActions({
  'cli-save': (form, d) => {
    const id = form.dataset.id;
    if (id) { op.updateClient(id, { name: d.name, phone: d.phone, email: d.email, birth: d.birth, origin: d.origin, notes: d.notes, preferences: d.preferences }); closeSheet(); toast('Cadastro atualizado.'); return; }
    const c = op.createClient({ name: d.name, phone: d.phone, email: d.email, birth: d.birth, origin: d.origin, notes: d.notes, preferences: d.preferences, consentOrigin: 'Informado no cadastro', consents: { whatsapp: { operacional: !!d.wOp, promocional: !!d.wPr }, email: { operacional: !!d.email, promocional: !!d.ePr && !!d.email }, sms: { operacional: false, promocional: false } } });
    closeSheet(); toast('Cliente cadastrada.'); go('/clientes/' + c.id);
  },
  'cli-edit': (el) => openClientForm(el.dataset.id),
  'cli-new-appt': (el) => openNewAppointment({ clientId: el.dataset.id }),
  'cli-tab': (el) => { const id = el.closest('#main').querySelector('[data-action=cli-edit]').dataset.id; go(`/clientes/${id}/${el.dataset.value}`); },
  'cli-filter': (el) => { ui.clientes.filter = el.dataset.v; ui.clientes.page = 1; window.__rerender(); },
  'cli-more': () => { ui.clientes.page++; window.__rerender(); },
  'cli-consent': async (el) => { const v = el.checked; try { op.updateConsent(el.dataset.id, el.dataset.ch, el.dataset.pu, v, v ? 'Autorizado pela cliente (registro manual)' : 'Revogado a pedido da cliente'); toast(v ? 'Consentimento registrado.' : 'Consentimento revogado. Comunicações pendentes deste tipo foram canceladas.'); } catch (e) { el.checked = !v; toast(e.message, 'err'); } },
  'cli-sell-pkg': (el) => import('./servicos.js').then((m) => m.openSellPackage(el.dataset.id)),
  'cli-export': () => { const s = S(); const rows = activeClients(s).map((c) => ({ c, st: clientStats(s, c.id) })); download('clientes.csv', toCSV(rows, [{ label: 'ID', value: (r) => r.c.id }, { label: 'Nome', value: (r) => r.c.name }, { label: 'Telefone', value: (r) => fmtPhone(r.c.phone) }, { label: 'E-mail', value: (r) => r.c.email }, { label: 'Origem', value: (r) => r.c.origin }, { label: 'Cadastro', value: (r) => fmtDate(r.c.createdAt) }, { label: 'Primeira visita', value: (r) => fmtDate(r.st.firstVisit) }, { label: 'Última visita', value: (r) => fmtDate(r.st.lastVisit) }, { label: 'Atendimentos', value: (r) => r.st.visitCount }, { label: 'Valor acumulado (R$)', value: (r) => (r.st.totalSales / 100).toFixed(2).replace('.', ',') }, { label: 'Pendente (R$)', value: (r) => (r.st.pending / 100).toFixed(2).replace('.', ',') }])); },
  'cli-dups': () => openDuplicates(),
  'dup-merge': async (el) => { const s = S(); const keep = client(s, el.dataset.keep), drop = client(s, el.dataset.drop); if (await confirmDialog({ title: 'Mesclar cadastros?', message: `O histórico de <b>${esc(drop.name)}</b> será movido para <b>${esc(keep.name)}</b>. O cadastro mesclado fica registrado no histórico de auditoria.`, confirmLabel: 'Mesclar' })) { const r = op.mergeClients(keep.id, drop.id); toast(`Cadastros mesclados (${r.moved} registros movidos).`); } },
  'dup-dismiss': (el) => { op.dismissDuplicate(el.dataset.a, el.dataset.b); toast('Marcado como pessoas diferentes.'); },
});
function openDuplicates() {
  openSheet({ title: 'Possíveis duplicidades', wide: true, render: () => {
    const s = S(); const d = duplicateCandidates(s); const merges = s.clientMerges;
    const card = (c) => { const st = clientStats(s, c.id); return `<div class="grow"><div class="strong">${esc(c.name)}</div><div class="xs muted">${fmtPhone(c.phone)} · ${st.visitCount} atend. · cadastro ${fmtDate(c.createdAt)}</div></div>`; };
    return `<div class="sheet-body stack">${d.length ? d.map((x) => `<section class="card card-pad stack-sm"><div class="small strong" style="color:var(--warn)">${esc(x.reason)}</div><div class="row" style="gap:16px;align-items:flex-start">${card(x.a)}${card(x.b)}</div><div class="btn-group"><button class="btn sm" data-action="dup-merge" data-keep="${x.a.id}" data-drop="${x.b.id}">Manter “${esc(x.a.name)}”</button><button class="btn sm" data-action="dup-merge" data-keep="${x.b.id}" data-drop="${x.a.id}">Manter “${esc(x.b.name)}”</button><button class="btn sm ghost" data-action="dup-dismiss" data-a="${x.a.id}" data-b="${x.b.id}">São pessoas diferentes</button></div></section>`).join('') : empty('Nenhuma duplicidade pendente', 'Ótimo! Todos os casos foram revisados.', '', 'checkCircle')}
    ${merges.length ? `<div><h3 style="margin-bottom:8px">Mesclagens realizadas</h3>${merges.map((m) => `<p class="small">${fmtDateTime(m.at)} · “${esc(m.mergedName)}” → “${esc(client(s, m.keepId)?.name)}” · ${m.movedRecords} registros · por ${esc(user(s, m.by)?.name)}</p>`).join('')}</div>` : ''}</div>`;
  } });
}
