// Serviços e Pacotes — catálogo, preços (com histórico preservado), pacotes e venda de pacotes.
import { S, ui, today } from '../ctx.js';
import { esc, money, moneyInput, parseMoney, fmtDate, norm, addDays } from '../../util.js';
import { PAYMENT_METHODS } from '../../domain/rules.js';
import { service, professional, client, byId, hasPerm, packageRemaining, packageState, activeClients, searchClients, saleTotal, salePaid } from '../../services/core.js';
import * as op from '../../services/operations.js';
import { icon, registerActions, openSheet, closeSheet, refreshSheet, toast, confirmDialog, field, options, empty, badge, tabs } from '../dom.js';
import { clientPicker, bindClientPicker } from '../pickers.js';

export function render() {
  const s = S(); const V = ui.serv; const canEdit = hasPerm(s, 'servicos.editar');
  const T = tabs([['servicos', 'Serviços'], ['pacotes', 'Pacotes'], ['vendidos', 'Pacotes vendidos']], V.tab, 'sv-tab');
  let body = '';
  if (V.tab === 'servicos') {
    const list = s.services.filter((x) => (!V.cat || x.category === V.cat) && (!V.q || norm(x.name).includes(norm(V.q)))).sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name));
    body = `<div class="card"><div class="card-pad row wrap" style="border-bottom:1px solid var(--border)"><div class="input-icon grow" style="min-width:200px">${icon('search')}<input class="input" id="sv-q" placeholder="Buscar serviço" value="${esc(V.q)}" aria-label="Buscar serviço"></div><select class="select" style="width:auto" id="sv-cat" aria-label="Categoria">${options(s.org.categories.map((c) => [c, c]), V.cat, { placeholder: 'Todas as categorias' })}</select></div>
    <div class="table-wrap"><table class="table"><thead><tr><th>Serviço</th><th>Categoria</th><th class="num">Preço</th><th class="num">Duração</th><th>Profissionais</th><th class="num">Comissão</th><th>Status</th><th></th></tr></thead><tbody>
    ${list.map((x) => `<tr><td><div class="strong">${esc(x.name)}</div>${x.description ? `<div class="xs subtle">${esc(x.description)}</div>` : ''}</td><td>${esc(x.category)}</td><td class="num">${money(x.price)}</td><td class="num">${x.duration} min</td><td class="small">${x.professionalIds.map((p) => esc(professional(s, p)?.name.split(' ')[0])).join(', ')}</td><td class="num">${x.commissionPct}%</td><td>${x.active ? badge('Ativo', 'good') : badge('Inativo', 'muted')}</td><td class="right nowrap">${canEdit ? `<button class="btn sm ghost" data-action="sv-edit" data-id="${x.id}">Editar</button><button class="btn sm ghost" data-action="sv-toggle" data-id="${x.id}">${x.active ? 'Inativar' : 'Ativar'}</button>` : ''}</td></tr>`).join('') || `<tr><td colspan="8">${empty('Nenhum serviço', 'Ajuste a busca.')}</td></tr>`}
    </tbody></table></div></div><p class="xs subtle" style="margin-top:8px">Alterar preço não muda atendimentos e vendas já registrados: cada agendamento guarda o preço do momento (snapshot) e o histórico de preços fica salvo.</p>`;
  }
  if (V.tab === 'pacotes') {
    body = `<div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(280px,1fr))">${s.packages.map((p) => { const sold = s.clientPackages.filter((cp) => cp.packageId === p.id && cp.status !== 'cancelado'); const full = p.items.reduce((t, i) => t + service(s, i.serviceId).price * i.sessions, 0); return `<section class="card"><div class="card-head"><h3>${esc(p.name)}</h3>${p.active ? badge('Ativo', 'good') : badge('Inativo', 'muted')}</div><div class="card-body stack-sm">
      <div class="row-between"><span class="strong" style="font-size:18px">${money(p.price)}</span>${full > p.price ? `<span class="badge accent">economia de ${money(full - p.price)}</span>` : ''}</div>
      <div class="small">${p.items.map((i) => `${i.sessions}× ${esc(service(s, i.serviceId).name)}`).join('<br>')}</div>
      <div class="xs subtle">Validade ${p.validityDays} dias · ${sold.length} vendido(s)${p.rules ? ' · ' + esc(p.rules) : ''}</div>
      <div class="btn-group">${hasPerm(s, 'pagamentos.registrar') && p.active ? `<button class="btn sm primary" data-action="pk-sell" data-pkg="${p.id}">Vender</button>` : ''}<button class="btn sm" data-action="pk-details" data-id="${p.id}">Detalhes</button>${canEdit ? `<button class="btn sm ghost" data-action="pk-edit" data-id="${p.id}">Editar</button><button class="btn sm ghost" data-action="pk-toggle" data-id="${p.id}">${p.active ? 'Inativar' : 'Ativar'}</button>` : ''}</div></div></section>`; }).join('')}</div>`;
  }
  if (V.tab === 'vendidos') {
    const list = [...s.clientPackages].filter((cp) => cp.status !== 'cancelado').sort((a, b) => b.purchaseDate.localeCompare(a.purchaseDate));
    body = `<div class="card"><div class="table-wrap"><table class="table"><thead><tr><th>Cliente</th><th>Pacote</th><th>Compra</th><th>Validade</th><th class="num">Restantes</th><th>Situação</th></tr></thead><tbody>
    ${list.map((cp) => { const st = packageState(s, cp, today()); return `<tr class="clickable" data-action="go" data-to="/clientes/${cp.clientId}/pacotes"><td>${esc(client(s, cp.clientId)?.name)}</td><td>${esc(byId(s.packages, cp.packageId)?.name)}</td><td>${fmtDate(cp.purchaseDate)}</td><td>${fmtDate(cp.expiresAt)}</td><td class="num">${packageRemaining(s, cp)} / ${cp.sessionsTotal}</td><td>${badge(st.label, st.tone)}</td></tr>`; }).join('')}</tbody></table></div></div>`;
  }
  return `<div class="page-head"><div><h1>Serviços e Pacotes</h1><p class="small muted">${s.services.filter((x) => x.active).length} serviços ativos · ${s.packages.filter((x) => x.active).length} pacotes</p></div>
  <div class="btn-group">${canEdit ? `<button class="btn" data-action="pk-new">${icon('box')}Novo pacote</button><button class="btn primary" data-action="sv-new">${icon('plus')}Novo serviço</button>` : ''}</div></div>${T}${body}`;
}
export function bindServicos(root) {
  root.querySelector('#sv-q')?.addEventListener('input', (e) => { ui.serv.q = e.target.value; clearTimeout(window.__svt); window.__svt = setTimeout(() => { window.__rerender(); const i = document.querySelector('#sv-q'); i?.focus(); i?.setSelectionRange(i.value.length, i.value.length); }, 200); });
  root.querySelector('#sv-cat')?.addEventListener('change', (e) => { ui.serv.cat = e.target.value; window.__rerender(); });
}

function serviceForm(id) {
  const s = S(); const x = id ? service(s, id) : null;
  openSheet({ title: x ? 'Editar serviço' : 'Novo serviço', render: () => `<form class="sheet-body stack" data-submit="sv-save" data-id="${id || ''}" id="sv-form" novalidate><div class="form-grid">
    ${field('Nome do serviço *', `<input class="input" name="name" value="${esc(x?.name || '')}">`, { full: true })}
    ${field('Categoria *', `<select class="select" name="category">${options(s.org.categories.map((c) => [c, c]), x?.category, { placeholder: 'Escolha' })}</select>`)}
    ${field('Preço padrão (R$) *', `<input class="input" name="price" inputmode="decimal" value="${x ? moneyInput(x.price) : ''}">`, { hint: x ? 'Novos agendamentos usarão o novo preço; o histórico não muda.' : '' })}
    ${field('Duração (min) *', `<input class="input" name="duration" type="number" min="5" step="5" value="${x?.duration || 60}">`)}
    ${field('Comissão (%)', `<input class="input" name="commissionPct" type="number" min="0" max="100" value="${x?.commissionPct ?? 40}">`)}
    ${field('Sala ou equipamento necessário', `<select class="select" name="resourceId">${options(s.resources, x?.resourceId, { placeholder: 'Nenhum' })}</select>`, { full: true })}
    ${field('Descrição comercial', `<textarea class="textarea" name="description">${esc(x?.description || '')}</textarea>`, { full: true })}
    <div class="full field" data-field="professionalIds"><span class="label">Profissionais habilitadas *</span>${s.professionals.filter((p) => p.active).map((p) => `<label class="check"><input type="checkbox" name="pros[]" value="${p.id}" ${x?.professionalIds.includes(p.id) ? 'checked' : ''}>${esc(p.name)}</label>`).join('')}</div>
    ${x ? `<div class="full small muted"><b>Histórico de preços:</b> ${s.servicePriceHistory.filter((h) => h.serviceId === x.id).map((h) => `${money(h.price)} desde ${fmtDate(h.from)}`).join(' · ')}</div>` : ''}
  </div></form><div class="sheet-foot"><button class="btn" data-action="sheet-close">Cancelar</button><button class="btn primary" type="submit" form="sv-form">Salvar</button></div>` });
}
function packageForm(id) {
  const s = S(); const p = id ? byId(s.packages, id) : null;
  const d = { items: p ? p.items.map((i) => ({ ...i })) : [{ serviceId: '', sessions: 4 }] };
  openSheet({ title: p ? 'Editar pacote' : 'Criar pacote', render: () => `<form class="sheet-body stack" data-submit="pk-save" data-id="${id || ''}" id="pk-form" novalidate><div class="form-grid">
    ${field('Nome do pacote *', `<input class="input" name="name" value="${esc(p?.name || '')}">`, { full: true })}
    <div class="full stack-sm" data-field="items"><span class="label">Serviços e sessões *</span>${d.items.map((it, i) => `<div class="row"><select class="select" data-pk-svc="${i}">${options(s.services.filter((x) => x.active), it.serviceId, { placeholder: 'Serviço' })}</select><input class="input" type="number" min="1" style="width:90px" value="${it.sessions}" data-pk-n="${i}" aria-label="Sessões"><button type="button" class="btn icon ghost" data-action="pk-del-item" data-i="${i}" aria-label="Remover">${icon('x')}</button></div>`).join('')}<div><button type="button" class="btn sm" data-action="pk-add-item">${icon('plus')}Adicionar serviço (combinação)</button></div></div>
    ${field('Preço do pacote (R$) *', `<input class="input" name="price" inputmode="decimal" value="${p ? moneyInput(p.price) : ''}">`)}
    ${field('Validade (dias) *', `<input class="input" name="validityDays" type="number" min="1" value="${p?.validityDays || 90}">`)}
    ${field('Regras de utilização', `<textarea class="textarea" name="rules">${esc(p?.rules || '')}</textarea>`, { full: true })}
  </div></form><div class="sheet-foot"><button class="btn" data-action="sheet-close">Cancelar</button><button class="btn primary" type="submit" form="pk-form">Salvar pacote</button></div>`,
  onMount: (root) => { root._pk = d; root.querySelectorAll('[data-pk-svc]').forEach((el) => el.addEventListener('change', () => { d.items[el.dataset.pkSvc].serviceId = el.value; })); root.querySelectorAll('[data-pk-n]').forEach((el) => el.addEventListener('input', () => { d.items[el.dataset.pkN].sessions = Number(el.value); })); } });
}
export function openSellPackage(clientId, packageId) {
  const d = { clientId: clientId || '', packageId: packageId || '', method: 'pix', mode: 'total', amount: '' };
  openSheet({ title: 'Venda de pacote', render: () => {
    const s = S(); const p = d.packageId ? byId(s.packages, d.packageId) : null;
    return `<form class="sheet-body stack" data-submit="pk-sell-save" id="pks-form" novalidate>
      ${clientPicker(d.clientId)}
      ${field('Pacote *', `<select class="select" name="packageId" id="pks-pkg">${options(s.packages.filter((x) => x.active).map((x) => [x.id, `${x.name} — ${money(x.price)}`]), d.packageId, { placeholder: 'Escolha o pacote' })}</select>`)}
      ${p ? `<div class="summary small"><dl class="kv"><dt>Sessões</dt><dd>${p.items.map((i) => `${i.sessions}× ${esc(service(s, i.serviceId).name)}`).join(', ')}</dd><dt>Validade</dt><dd>até ${fmtDate(addDays(today(), p.validityDays))}</dd><dt>Valor</dt><dd>${money(p.price)}</dd></dl></div>` : ''}
      <div class="stack-sm"><span class="label">Pagamento</span>${['total', 'parcial', 'pendente'].map((m) => `<label class="check"><input type="radio" name="mode" value="${m}" ${d.mode === m ? 'checked' : ''} data-pks-mode>${{ total: 'Recebido integralmente agora', parcial: 'Entrada agora, restante pendente', pendente: 'Tudo pendente' }[m]}</label>`).join('')}</div>
      ${d.mode !== 'pendente' ? `<div class="chips" data-field="method">${PAYMENT_METHODS.map((m) => `<button type="button" class="chip" aria-pressed="${d.method === m.id}" data-action="pks-method" data-v="${m.id}">${m.label}</button>`).join('')}</div>` : ''}
      ${d.mode === 'parcial' ? field('Valor da entrada (R$)', `<input class="input" name="amount" inputmode="decimal" value="${esc(d.amount)}">`) : ''}
      <p class="xs subtle">A venda do pacote gera a venda e o recebimento. Cada sessão usada depois é registrada na Finalização Expressa, sem nova venda.</p>
    </form><div class="sheet-foot"><button class="btn" data-action="sheet-close">Cancelar</button><button class="btn primary" type="submit" form="pks-form">Registrar venda</button></div>`;
  }, onMount: (root) => { root._pks = d; bindClientPicker(root, (id) => { d.clientId = id; }); root.querySelector('#pks-pkg').addEventListener('change', (e) => { d.packageId = e.target.value; refreshSheet(); }); root.querySelectorAll('[data-pks-mode]').forEach((r) => r.addEventListener('change', () => { d.mode = r.value; refreshSheet(); })); root.querySelector('[name=amount]')?.addEventListener('input', (e) => { d.amount = e.target.value; }); } });
}
function packageDetails(id) {
  openSheet({ title: 'Detalhes do pacote', wide: true, render: () => {
    const s = S(); const p = byId(s.packages, id); const sold = s.clientPackages.filter((cp) => cp.packageId === id && cp.status !== 'cancelado');
    const active = sold.filter((cp) => packageState(s, cp, today()).key === 'ativo').length;
    return `<div class="sheet-body stack"><div class="kpis">${[['Preço', money(p.price)], ['Validade', p.validityDays + ' dias'], ['Vendidos', sold.length], ['Ativos', active], ['Sessões usadas', s.packageUsage.filter((u) => sold.some((cp) => cp.id === u.clientPackageId)).length]].map(([l, v]) => `<div class="kpi"><div class="k-label">${l}</div><div class="k-value" style="font-size:17px">${v}</div></div>`).join('')}</div>
    <p class="small">${p.items.map((i) => `${i.sessions}× ${esc(service(s, i.serviceId).name)}`).join(' + ')}${p.rules ? ' · ' + esc(p.rules) : ''}</p>
    <div class="card"><div class="table-wrap"><table class="table"><thead><tr><th>Cliente</th><th>Compra</th><th>Validade</th><th class="num">Usadas</th><th class="num">Restantes</th><th>Situação</th></tr></thead><tbody>${sold.map((cp) => { const st = packageState(s, cp, today()); return `<tr><td>${esc(client(s, cp.clientId)?.name)}</td><td>${fmtDate(cp.purchaseDate)}</td><td>${fmtDate(cp.expiresAt)}</td><td class="num">${cp.sessionsTotal - packageRemaining(s, cp)}</td><td class="num">${packageRemaining(s, cp)}</td><td>${badge(st.label, st.tone)}</td></tr>`; }).join('') || `<tr><td colspan="6">${empty('Nenhuma venda ainda', 'Vendas aparecem aqui.')}</td></tr>`}</tbody></table></div></div></div>`;
  } });
}

registerActions({
  'sv-tab': (el) => { ui.serv.tab = el.dataset.value; window.__rerender(); },
  'sv-new': () => serviceForm(), 'sv-edit': (el) => serviceForm(el.dataset.id),
  'sv-toggle': async (el) => { const x = service(S(), el.dataset.id); if (x.active && !(await confirmDialog({ title: 'Inativar serviço?', message: 'Ele deixa de aparecer em novos agendamentos. O histórico é mantido.', confirmLabel: 'Inativar' }))) return; op.toggleService(el.dataset.id); toast(x.active ? 'Serviço inativado.' : 'Serviço ativado.'); },
  'sv-save': (form, d) => { const price = parseMoney(d.price); if (isNaN(price)) throw Object.assign(new Error('Preço inválido.'), { field: 'price' }); op.saveService({ id: form.dataset.id || undefined, name: d.name, category: d.category, price, duration: Number(d.duration), commissionPct: d.commissionPct, resourceId: d.resourceId, description: d.description, professionalIds: d.pros || [] }); closeSheet(); toast('Serviço salvo.'); },
  'pk-new': () => packageForm(), 'pk-edit': (el) => packageForm(el.dataset.id), 'pk-details': (el) => packageDetails(el.dataset.id),
  'pk-toggle': (el) => { op.togglePackage(el.dataset.id); toast('Pacote atualizado.'); },
  'pk-add-item': (el) => { el.closest('.overlay')._pk.items.push({ serviceId: '', sessions: 1 }); refreshSheet(); },
  'pk-del-item': (el) => { const d = el.closest('.overlay')._pk; if (d.items.length > 1) d.items.splice(Number(el.dataset.i), 1); refreshSheet(); },
  'pk-save': (form, data) => { const d = form.closest('.overlay')._pk; const price = parseMoney(data.price); op.savePackage({ id: form.dataset.id || undefined, name: data.name, items: d.items, price, validityDays: Number(data.validityDays), rules: data.rules }); closeSheet(); toast('Pacote salvo.'); },
  'pk-sell': (el) => openSellPackage('', el.dataset.pkg),
  'pks-method': (el) => { el.closest('.overlay')._pks.method = el.dataset.v; el.closest('.chips').querySelectorAll('.chip').forEach((b) => b.setAttribute('aria-pressed', b === el)); },
  'pk-sell-save': (form) => {
    const d = form.closest('.overlay')._pks; const p = byId(S().packages, d.packageId);
    if (!d.clientId) throw Object.assign(new Error('Escolha a cliente.'), { field: 'clientId' });
    if (!p) throw Object.assign(new Error('Escolha o pacote.'), { field: 'packageId' });
    const amount = d.mode === 'total' ? p.price : d.mode === 'pendente' ? 0 : parseMoney(d.amount);
    if (d.mode === 'parcial' && (isNaN(amount) || amount <= 0 || amount >= p.price)) throw Object.assign(new Error('Informe uma entrada maior que zero e menor que o preço.'), { field: 'amount' });
    op.sellPackage({ clientId: d.clientId, packageId: p.id, method: d.method, amountReceived: amount });
    closeSheet(); toast('Pacote vendido e vinculado à cliente.');
  },
});
