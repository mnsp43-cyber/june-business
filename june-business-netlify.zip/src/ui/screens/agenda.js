// Agenda — visão diária por profissional, semanal e lista; filtros e criação a partir do horário livre.
import { S, ui, today, now } from '../ctx.js';
import { esc, money, addDays, fmtDate, fmtLongDate, startOfWeek, dow, timeToMin, minToTime, WEEKDAYS_SHORT, parseDate } from '../../util.js';
import { STATUS } from '../../domain/rules.js';
import { client, service, professional, hasPerm, currentUser, proSchedule, blocksFor } from '../../services/core.js';
import { apptCard, openApptDetails, openNewAppointment } from '../appointments.js';
import { icon, registerActions, options, seg, empty, openSheet, closeSheet, toast, field, confirmDialog } from '../dom.js';
import * as op from '../../services/operations.js';

const START = 8 * 60, END = 20 * 60, PX = 0.8; // 30 min = 24 px

export function render() {
  const s = S(); const u = currentUser(s); const A = ui.agenda;
  if (!A.date) A.date = today();
  if (!A.viewSet && innerWidth < 768) A.view = 'lista';
  const ownOnly = !hasPerm(s, 'agenda.ver_todas'); if (ownOnly) A.pro = u.professionalId;
  const pros = s.professionals.filter((p) => p.active && (!A.pro || p.id === A.pro));
  const match = (a) => (!A.pro || a.professionalId === A.pro) && (!A.service || a.serviceId === A.service) && (!A.category || service(s, a.serviceId).category === A.category) && (!A.status || a.status === A.status) && (A.showResched || a.status !== 'reagendado');
  const weekStart = startOfWeek(A.date);
  const title = A.view === 'semana' ? `${fmtDate(weekStart)} a ${fmtDate(addDays(weekStart, 6))}` : (fmtLongDate(A.date).charAt(0).toUpperCase() + fmtLongDate(A.date).slice(1));
  const activeN = [A.pro && !ownOnly, A.service, A.category, A.status].filter(Boolean).length;
  const filters = `<details ${innerWidth >= 768 || activeN ? 'open' : ''}><summary class="small strong" style="cursor:pointer;padding:4px 0">Filtros${activeN ? ` (${activeN})` : ''}</summary><div class="filters" style="margin-top:8px">
    ${ownOnly ? '' : `<select class="select" data-af="pro" aria-label="Profissional">${options(s.professionals.filter((p) => p.active), A.pro, { placeholder: 'Todas as profissionais' })}</select>`}
    <select class="select" data-af="category" aria-label="Categoria">${options(s.org.categories.map((c) => [c, c]), A.category, { placeholder: 'Todas as categorias' })}</select>
    <select class="select" data-af="service" aria-label="Serviço">${options(s.services.filter((x) => !A.category || x.category === A.category), A.service, { placeholder: 'Todos os serviços' })}</select>
    <select class="select" data-af="status" aria-label="Status">${options(Object.entries(STATUS).map(([k, v]) => [k, v.label]), A.status, { placeholder: 'Todos os status' })}</select>
    <select class="select hide-mobile" aria-label="Unidade" disabled title="Multiunidade planejada para evolução"><option>Unidade única</option></select>
    <label class="check small"><input type="checkbox" data-af="showResched" ${A.showResched ? 'checked' : ''}>Mostrar reagendados</label>
  </div></details>`;
  let body = '';
  if (A.view === 'dia') body = dayGrid(s, A.date, pros, match);
  else if (A.view === 'semana') body = weekGrid(s, weekStart, match);
  else body = listView(s, A.date, match);
  return `
  <div class="page-head"><div class="row wrap" style="gap:8px">
      <button class="btn icon" data-action="ag-nav" data-d="-1" aria-label="Anterior">${icon('left')}</button>
      <button class="btn" data-action="ag-today">Hoje</button>
      <button class="btn icon" data-action="ag-nav" data-d="1" aria-label="Próximo">${icon('right')}</button>
      <input type="date" class="input" style="width:auto;height:36px" value="${A.date}" data-af="date" aria-label="Escolher data">
      <h1 style="font-size:16px" class="hide-mobile">${title}</h1></div>
    <div class="row wrap">${seg('view', [['dia', 'Dia'], ['semana', 'Semana'], ['lista', 'Lista']], A.view, 'ag-view')}
      <button class="btn" data-action="ag-block">${icon('lock')}Bloquear horário</button>
      <button class="btn primary hide-mobile" data-action="new-appt">${icon('plus')}Novo agendamento</button></div></div>
  <h1 class="show-mobile" style="font-size:15px;margin-bottom:8px">${title}</h1>
  <div style="margin-bottom:12px">${filters}</div>
  ${body}
  <p class="xs subtle" style="margin-top:8px">Clique em um horário livre para agendar. Áreas hachuradas: fora da jornada, intervalo ou bloqueio. Agendamento online público: planejado (sem integração no protótipo).</p>`;
}

function hours() { const out = []; for (let m = START; m < END; m += 60) out.push(m); return out; }
function column(s, p, date, match, header) {
  const sch = proSchedule(p, date); const blocks = blocksFor(s, p.id, date);
  const appts = s.appointments.filter((a) => a.date === date && a.professionalId === p.id && match(a));
  let slots = '';
  for (let m = START; m < END; m += 30) {
    const t = minToTime(m); let off = !sch || m < timeToMin(sch.start) || m + 30 > timeToMin(sch.end) || (sch.breakStart && m < timeToMin(sch.breakEnd) && m + 30 > timeToMin(sch.breakStart));
    if (!off) for (const b of blocks) { const bs = b.start.slice(0, 10) < date ? 0 : timeToMin(b.start.slice(11, 16)); const be = b.end.slice(0, 10) > date ? 1440 : timeToMin(b.end.slice(11, 16)); if (m < be && m + 30 > bs) off = true; }
    const past = `${date}T${t}` < now();
    slots += off || past ? `<div class="cal-slot off" aria-hidden="true"></div>` : `<div class="cal-slot" role="button" tabindex="0" aria-label="Agendar ${esc(p.name)} ${t}" data-action="ag-slot" data-pro="${p.id}" data-date="${date}" data-t="${t}"></div>`;
  }
  const evs = appts.map((a) => { const top = (timeToMin(a.start) - START) * PX; const h = Math.max(20, a.duration * PX - 2); const c = client(s, a.clientId); const sv = service(s, a.serviceId);
    return `<button class="cal-ev st-${a.status}" style="top:${top}px;height:${h}px" data-action="appt-open" data-id="${a.id}" data-tip="${esc(`<b>${a.start} ${esc(c.name)}</b><br>${esc(sv.name)}<br>${STATUS[a.status].label} · ${money(a.price)}`)}"><strong>${a.start} ${esc(c.name)}</strong><span>${esc(sv.name)}</span></button>`; }).join('');
  const blk = blocks.map((b) => { const bs = b.start.slice(0, 10) < date ? (sch ? timeToMin(sch.start) : START) : timeToMin(b.start.slice(11, 16)); const be = b.end.slice(0, 10) > date ? (sch ? timeToMin(sch.end) : END) : timeToMin(b.end.slice(11, 16)); return `<div class="cal-block" style="top:${(Math.max(bs, START) - START) * PX}px;height:${(Math.min(be, END) - Math.max(bs, START)) * PX}px">${esc(b.reason)}</div>`; }).join('');
  const nowM = timeToMin(S().settings.demoTime); const nowLine = date === today() && nowM >= START && nowM <= END ? `<div class="now-line" style="top:${(nowM - START) * PX}px"></div>` : '';
  return { head: header, body: `<div class="cal-col">${slots}${blk}${evs}${nowLine}</div>` };
}
function gridShell(cols, labels) {
  const times = `<div class="cal-times">${hours().map((m) => `<div class="cal-time">${minToTime(m)}</div>`).join('')}</div>`;
  return `<div class="cal" style="grid-template-columns:52px repeat(${cols.length},minmax(130px,1fr))"><div class="cal-head" style="position:sticky;left:0;z-index:4"></div>${cols.map((c) => c.head).join('')}${times}${cols.map((c) => c.body).join('')}</div>`;
}
function dayGrid(s, date, pros, match) {
  if (!pros.length) return `<div class="card">${empty('Nenhuma profissional ativa', 'Cadastre ou ative profissionais em Configurações.')}</div>`;
  return gridShell(pros.map((p) => column(s, p, date, match, `<div class="cal-head"><span class="dot" style="background:${p.color};margin-right:6px"></span>${esc(p.name.split(' ')[0])}${proSchedule(p, date) ? '' : ' <span class="subtle">(folga)</span>'}</div>`)));
}
function weekGrid(s, ws, match) {
  const A = ui.agenda;
  const days = Array.from({ length: 7 }, (_, i) => addDays(ws, i)).filter((d) => s.org.hours[dow(d)]);
  if (!A.pro) {
    // Semana da equipe: lista compacta por dia
    return `<div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(220px,1fr))">${days.map((d) => { const list = s.appointments.filter((a) => a.date === d && match(a)).sort((x, y) => x.start.localeCompare(y.start)); return `<section class="card"><div class="card-head"><h3 style="text-transform:capitalize" class="${d === today() ? '' : ''}">${WEEKDAYS_SHORT[dow(d)]} ${fmtDate(d).slice(0, 5)}</h3><span class="badge ${d === today() ? 'accent' : 'neutral'}">${list.length}</span></div><div class="list">${list.length ? list.map((a) => `<button class="list-item" style="min-height:44px;padding:6px 12px" data-action="appt-open" data-id="${a.id}"><span class="num strong small" style="width:40px">${a.start}</span><span class="dot" style="background:${professional(s, a.professionalId).color}"></span><div class="li-main"><div class="li-sub" style="color:var(--text)">${esc(client(s, a.clientId).name)}</div><div class="xs subtle ellipsis">${esc(service(s, a.serviceId).name)} · ${STATUS[a.status].label}</div></div></button>`).join('') : '<p class="small subtle card-pad">Sem agendamentos.</p>'}</div></section>`; }).join('')}</div><p class="xs subtle" style="margin-top:8px">Para ver a grade de horários livres na semana, escolha uma profissional no filtro.</p>`;
  }
  const p = professional(s, A.pro);
  return gridShell(days.map((d) => column(s, p, d, match, `<div class="cal-head ${d === today() ? 'today' : ''}" style="text-transform:capitalize">${WEEKDAYS_SHORT[dow(d)]} ${fmtDate(d).slice(0, 5)}</div>`)));
}
function listView(s, date, match) {
  const list = s.appointments.filter((a) => a.date === date && match(a)).sort((x, y) => x.start.localeCompare(y.start));
  if (!list.length) return `<div class="card">${empty('Nenhum agendamento nesta data', 'Use “Novo agendamento” ou escolha outra data.', '<button class="btn primary" data-action="new-appt">Novo agendamento</button>', 'calendar')}</div>`;
  return `<div class="appt-list" style="max-width:760px">${list.map((a) => apptCard(a)).join('')}</div>`;
}

registerActions({
  'ag-view': (el) => { ui.agenda.view = el.dataset.value; ui.agenda.viewSet = true; window.__rerender(); },
  'ag-nav': (el) => { const st = ui.agenda.view === 'semana' ? 7 : 1; ui.agenda.date = addDays(ui.agenda.date, st * Number(el.dataset.d)); window.__rerender(); },
  'ag-today': () => { ui.agenda.date = today(); window.__rerender(); },
  'ag-slot': (el) => openNewAppointment({ professionalId: el.dataset.pro, date: el.dataset.date, start: el.dataset.t }),
  'ag-block': () => openBlockSheet(),
  'blk-del': async (el) => { if (await confirmDialog({ title: 'Remover bloqueio?', message: 'O horário volta a ficar disponível.', confirmLabel: 'Remover' })) { op.removeBlock(el.dataset.id); toast('Bloqueio removido.'); } },
  'blk-save': (form, d) => { const allDay = !!d.allDay; op.addBlock({ professionalId: d.professionalId, start: `${d.dateStart}T${allDay ? '00:00' : d.timeStart}`, end: `${d.dateEnd || d.dateStart}T${allDay ? '23:59' : d.timeEnd}`, reason: d.reason, allDay }); closeSheet(); toast('Bloqueio salvo. Os horários ficaram indisponíveis.'); },
});
export function bindAgenda(root) {
  root.querySelectorAll('[data-af]').forEach((el) => el.addEventListener('change', () => { const k = el.dataset.af; ui.agenda[k] = el.type === 'checkbox' ? el.checked : el.value; if (k === 'category') ui.agenda.service = ''; if (k === 'date' && !el.value) ui.agenda.date = today(); window.__rerender(); }));
  root.querySelectorAll('.cal-slot[tabindex]').forEach((el) => el.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); el.click(); } }));
}

export function openBlockSheet() {
  const s = S(); const u = currentUser(s); const own = !hasPerm(s, 'agenda.ver_todas');
  openSheet({ title: 'Bloquear horário', render: () => {
    const s2 = S(); const list = s2.blocks.filter((b) => b.end.slice(0, 10) >= today() && (!own || b.professionalId === u.professionalId)).sort((a, b) => a.start.localeCompare(b.start));
    return `<form class="sheet-body stack" data-submit="blk-save" id="blk-form">
      <p class="small muted">Use para férias, cursos, folgas e compromissos. O horário deixa de aparecer como disponível.</p>
      <div class="form-grid">
        ${field('Profissional', `<select class="select" name="professionalId">${options(s2.professionals.filter((p) => p.active && (!own || p.id === u.professionalId)), own ? u.professionalId : '', { placeholder: own ? undefined : 'Escolha' })}</select>`, { full: true })}
        ${field('Data inicial', `<input class="input" type="date" name="dateStart" value="${today()}">`)}
        ${field('Data final', `<input class="input" type="date" name="dateEnd" value="${today()}">`)}
        <label class="check full"><input type="checkbox" name="allDay" checked>Dia inteiro</label>
        ${field('Das', `<input class="input" type="time" name="timeStart" value="12:00">`)}
        ${field('Até', `<input class="input" type="time" name="timeEnd" value="13:00">`)}
        ${field('Motivo', `<input class="input" name="reason" placeholder="Ex.: férias, curso">`, { full: true })}
      </div>
      <div><h3 style="margin:8px 0">Bloqueios ativos</h3>${list.length ? `<div class="list card">${list.map((b) => `<div class="list-item" style="cursor:default"><div class="li-main"><div class="li-title">${esc(professional(s2, b.professionalId).name)} · ${esc(b.reason)}</div><div class="li-sub">${b.allDay ? `${fmtDate(b.start)} a ${fmtDate(b.end)}` : `${fmtDate(b.start)} ${b.start.slice(11, 16)}–${b.end.slice(11, 16)}`}</div></div><button type="button" class="btn sm ghost danger" data-action="blk-del" data-id="${b.id}">Remover</button></div>`).join('')}</div>` : '<p class="small subtle">Nenhum bloqueio futuro.</p>'}</div>
    </form><div class="sheet-foot"><button class="btn" data-action="sheet-close">Fechar</button><button class="btn primary" type="submit" form="blk-form">Salvar bloqueio</button></div>`;
  } });
}
