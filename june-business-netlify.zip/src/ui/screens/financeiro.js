// Financeiro — vendas, recebimentos, saldos, despesas, estornos, caixa e comissões.
import { S, ui, today } from '../ctx.js';
import { esc, money, moneyInput, parseMoney, fmtDate, fmtDateTime, norm, toCSV } from '../../util.js';
import { PAYMENT_METHODS } from '../../domain/rules.js';
import { client, service, professional, user, byId, hasPerm, saleTotal, salePaid, saleSituation, saleGross, saleDiscount } from '../../services/core.js';
import { computeKPIs, presetRange, rangeLabel, series, autoGranularity, commissions } from '../../metrics/metrics.js';
import * as op from '../../services/operations.js';
import { icon, registerActions, openSheet, closeSheet, refreshSheet, toast, confirmDialog, field, options, empty, badge, tabs } from '../dom.js';
import { barChart, hbars, SERIES } from '../charts.js';
import { clientPicker, bindClientPicker } from '../pickers.js';
import { methodLabel } from '../appointments.js';
import { download } from '../util-ui.js';
import { periodControl, bindPeriod } from '../period.js';

const EXP_CATS = ['Aluguel', 'Contas de consumo', 'Produtos', 'Serviços', 'Marketing', 'Manutenção', 'Equipamentos', 'Impostos e taxas', 'Outras'];

export function render() {
  const s = S(); const F = ui.fin;
  const r = presetRange(F.preset, today(), F.custom);
  const f = { professionalId: F.pro || undefined, method: F.method || undefined };
  const k = computeKPIs(s, r, f);
  const T = tabs([['visao', 'Visão geral'], ['vendas', 'Vendas'], ['recebimentos', 'Recebimentos'], ['receber', 'A receber'], ['despesas', 'Despesas'], ['caixa', 'Fechamento de caixa'], ['comissoes', 'Comissões']], F.tab, 'fin-tab');
  const canExp = hasPerm(s, 'despesas.editar'); const seeRes = hasPerm(s, 'financeiro.ver');
  const head = `<div class="page-head"><div><h1>Financeiro</h1><p class="small muted">${rangeLabel(r)} · venda ≠ recebimento: dinheiro em caixa é só o que foi recebido</p></div>
    <div class="btn-group"><button class="btn" data-action="new-payment">${icon('wallet')}Registrar pagamento</button><button class="btn" data-action="new-sale">${icon('cash')}Nova venda</button>${canExp ? `<button class="btn primary" data-action="new-expense">${icon('plus')}Despesa</button>` : ''}</div></div>`;
  const filters = `<div class="filters" style="margin-bottom:16px">${periodControl('fin', F.preset, F.custom)}
    <select class="select" data-fin="pro" aria-label="Profissional">${options(s.professionals, F.pro, { placeholder: 'Todas as profissionais' })}</select>
    <select class="select" data-fin="method" aria-label="Forma de pagamento">${options(PAYMENT_METHODS.map((m) => [m.id, m.label]), F.method, { placeholder: 'Todas as formas' })}</select></div>`;
  let body = '';
  const kpi = (l, v, sub = '', tone = '') => `<div class="kpi ${tone ? 'tone-' + tone : ''}"><div class="k-label">${l}</div><div class="k-value">${v}</div>${sub ? `<div class="k-sub">${sub}</div>` : ''}</div>`;
  const na = (F.pro || F.method) ? '<span title="Filtro de profissional/forma não se aplica a despesas">filtro não se aplica</span>' : '';
  if (F.tab === 'visao') {
    const ser = series(s, r, f);
    body = `<div class="kpis">
      ${kpi('Faturamento bruto', money(k.gross), `${k.salesCount} vendas`)}
      ${kpi('Descontos e cortesias', money(k.discount), k.cancelled ? `cancelamentos ${money(k.cancelled)}` : '')}
      ${kpi('Vendas líquidas', money(k.net), k.reversals ? `estornos ${money(k.reversals)}` : 'por data da venda')}
      ${kpi('Recebido', money(k.receivedNet), 'por data do recebimento', 'good')}
      ${kpi('A receber', money(k.receivable), 'saldo de vendas válidas', k.receivable ? 'bad' : '')}
      ${kpi('Vendas de pacotes', money(k.pkgSales), 'no período')}
      ${kpi('Ticket médio', money(k.ticket), `${k.ticketN} atendimentos com venda`)}
      ${seeRes ? kpi('Despesas pagas', money(k.expensesPaid), na || `${money(k.expensesOpen)} em aberto`) : ''}
      ${seeRes ? kpi('Resultado de caixa estimado', money(k.cashResult), 'recebido − despesas pagas', k.cashResult < 0 ? 'bad' : 'good') : ''}
    </div>
    ${seeRes ? `<p class="xs subtle" style="margin:8px 0 0">Resultado por competência (vendas líquidas − despesas pelo vencimento): <b>${money(k.accrualResult)}</b>. Nenhum dos dois é lucro contábil.</p>` : ''}
    <div class="grid g-main-side" style="margin-top:16px">
      <section class="card"><div class="card-head"><h3>Vendas, recebimentos e despesas</h3><span class="small muted">por ${{ dia: 'dia', semana: 'semana', mes: 'mês' }[autoGranularity(r)]}</span></div><div class="card-body">${barChart({ labels: ser.map((x) => x.label), series: [{ label: 'Vendas líquidas', values: ser.map((x) => x.net) }, { label: 'Recebido', values: ser.map((x) => x.received) }, ...(seeRes ? [{ label: 'Despesas pagas', values: ser.map((x) => x.expenses) }] : [])], fmt: (v, axis) => axis ? (v >= 100000 ? (v / 100000).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' mil' : (v / 100).toLocaleString('pt-BR', { maximumFractionDigits: 0 })) : money(v) })}</div></section>
      <section class="card"><div class="card-head"><h3>Recebido por forma de pagamento</h3></div><div class="card-body">${hbars(PAYMENT_METHODS.map((m) => ({ label: m.label, value: Math.max(0, k.byMethod[m.id] || 0) })).sort((a, b) => b.value - a.value), { fmt: money })}</div></section>
    </div>`;
  }
  if (F.tab === 'vendas') {
    const list = s.sales.filter((x) => x.date >= r.from && x.date <= r.to && (!F.pro || x.items.some((i) => i.professionalId === F.pro)) && (!F.q || norm(client(s, x.clientId)?.name).includes(norm(F.q)))).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    body = `<div class="card"><div class="card-pad row" style="border-bottom:1px solid var(--border)"><div class="input-icon grow">${icon('search')}<input class="input" id="fin-q" placeholder="Buscar cliente" value="${esc(F.q)}"></div><button class="btn" data-action="fin-export" data-what="vendas">${icon('download')}CSV</button></div>
    <div class="table-wrap"><table class="table"><thead><tr><th>Data</th><th>Cliente</th><th>Origem</th><th>Itens</th><th class="num">Total</th><th class="num">Recebido</th><th class="num">Saldo</th><th>Situação</th></tr></thead><tbody>
    ${list.slice(0, 200).map((x) => { const sit = saleSituation(s, x); return `<tr class="clickable" data-action="fin-sale" data-id="${x.id}"><td class="nowrap">${fmtDate(x.date)}</td><td>${esc(client(s, x.clientId)?.name)}</td><td class="small">${{ servico: 'Atendimento', pacote: 'Pacote', avulsa: 'Avulsa', cortesia: 'Cortesia' }[x.type]}</td><td class="small">${esc(x.items.map((i) => i.description).join(', '))}</td><td class="num">${money(saleTotal(x))}</td><td class="num">${money(salePaid(s, x.id))}</td><td class="num">${money(x.status === 'valida' ? Math.max(0, saleTotal(x) - salePaid(s, x.id)) : 0)}</td><td>${badge(sit.label, sit.tone)}</td></tr>`; }).join('') || `<tr><td colspan="8">${empty('Nenhuma venda no período', 'Ajuste os filtros.')}</td></tr>`}
    </tbody></table></div>${list.length > 200 ? '<p class="xs subtle card-pad">Mostrando as 200 mais recentes. Use o CSV para a lista completa.</p>' : ''}</div>`;
  }
  if (F.tab === 'recebimentos') {
    const list = s.payments.filter((p) => p.date >= r.from && p.date <= r.to && (!F.method || p.method === F.method)).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    body = `<div class="card"><div class="card-head"><h3>${list.length} movimento(s) · ${money(list.reduce((t, p) => t + p.amount, 0))}</h3><button class="btn sm" data-action="fin-export" data-what="recebimentos">${icon('download')}CSV</button></div><div class="table-wrap"><table class="table"><thead><tr><th>Data do recebimento</th><th>Cliente</th><th>Forma</th><th>Tipo</th><th class="num">Valor</th><th>Venda de</th><th>Registrado por</th><th></th></tr></thead><tbody>
    ${list.slice(0, 200).map((p) => { const sl = byId(s.sales, p.saleId); const reversed = s.payments.some((x) => x.reversesId === p.id); return `<tr><td class="nowrap">${fmtDate(p.date)}</td><td>${esc(client(s, p.clientId)?.name)}</td><td>${methodLabel(p.method)}</td><td>${p.kind === 'estorno' ? badge('Estorno', 'bad') : reversed ? badge('Estornado', 'muted') : badge('Recebimento', 'good')}</td><td class="num" style="color:${p.amount < 0 ? 'var(--bad)' : 'inherit'}">${money(p.amount)}</td><td class="nowrap small">${sl ? fmtDate(sl.date) : '—'}</td><td class="small">${esc(user(s, p.createdBy)?.name || '—')}</td><td class="right">${p.kind === 'recebimento' && !reversed && hasPerm(s, 'estornos.autorizar') ? `<button class="btn sm ghost danger" data-action="fin-reverse" data-id="${p.id}">Estornar</button>` : ''}</td></tr>`; }).join('') || `<tr><td colspan="8">${empty('Nenhum recebimento', 'Ajuste o período.')}</td></tr>`}
    </tbody></table></div></div>`;
  }
  if (F.tab === 'receber') {
    const list = s.sales.filter((x) => x.status === 'valida' && saleTotal(x) > salePaid(s, x.id)).sort((a, b) => a.date.localeCompare(b.date));
    const tot = list.reduce((t, x) => t + saleTotal(x) - salePaid(s, x.id), 0);
    body = `<div class="callout info" style="margin-bottom:12px">${icon('info')}<div>Saldo a receber atual (todas as datas): <b>${money(tot)}</b> em ${list.length} venda(s). Recebimentos podem ser integrais ou parciais e ficam com a data em que entraram.</div></div>
    <div class="card"><div class="table-wrap"><table class="table"><thead><tr><th>Venda em</th><th>Dias</th><th>Cliente</th><th>Itens</th><th class="num">Total</th><th class="num">Recebido</th><th class="num">Saldo</th><th></th></tr></thead><tbody>
    ${list.map((x) => `<tr><td class="nowrap">${fmtDate(x.date)}</td><td class="num">${Math.round((new Date(today()) - new Date(x.date)) / 864e5)}</td><td>${esc(client(s, x.clientId)?.name)}</td><td class="small">${esc(x.items.map((i) => i.description).join(', '))}</td><td class="num">${money(saleTotal(x))}</td><td class="num">${money(salePaid(s, x.id))}</td><td class="num strong" style="color:var(--bad)">${money(saleTotal(x) - salePaid(s, x.id))}</td><td class="right"><button class="btn sm primary" data-action="fin-receive" data-id="${x.id}">Receber</button></td></tr>`).join('') || `<tr><td colspan="8">${empty('Nada a receber', 'Todas as vendas válidas estão quitadas.', '', 'checkCircle')}</td></tr>`}
    </tbody></table></div></div>`;
  }
  if (F.tab === 'despesas') {
    if (!seeRes) body = empty('Sem permissão', 'Seu perfil não acessa despesas.', '', 'lock');
    else {
      const list = s.expenses.filter((e) => (e.date >= r.from && e.date <= r.to) || (e.paidDate && e.paidDate >= r.from && e.paidDate <= r.to) || (!e.paid && e.date <= r.to)).sort((a, b) => b.date.localeCompare(a.date));
      body = `<div class="kpis" style="margin-bottom:12px">${kpi('Pagas no período', money(k.expensesPaid), 'pela data de pagamento')}${kpi('Por vencimento no período', money(k.expensesAccrual), 'competência')}${kpi('Em aberto', money(k.expensesOpen), 'vencidas ou a vencer', k.expensesOpen ? 'warn' : '')}</div>
      <div class="card"><div class="table-wrap"><table class="table"><thead><tr><th>Vencimento</th><th>Descrição</th><th>Categoria</th><th class="num">Valor</th><th>Situação</th><th></th></tr></thead><tbody>
      ${list.map((e) => `<tr><td class="nowrap">${fmtDate(e.date)}</td><td>${esc(e.description)}</td><td class="small">${esc(e.category)}</td><td class="num">${money(e.amount)}</td><td>${e.paid ? badge('Paga em ' + fmtDate(e.paidDate), 'good') : e.date < today() ? badge('Vencida', 'bad') : badge('A pagar', 'warn')}</td><td class="right nowrap">${canExp ? `${!e.paid ? `<button class="btn sm" data-action="exp-pay" data-id="${e.id}">Marcar paga</button>` : ''}<button class="btn sm ghost" data-action="new-expense" data-id="${e.id}">Editar</button>` : ''}</td></tr>`).join('') || `<tr><td colspan="6">${empty('Nenhuma despesa', 'Lance despesas para calcular o resultado.')}</td></tr>`}
      </tbody></table></div></div>`;
    }
  }
  if (F.tab === 'caixa') body = cashHtml(s);
  if (F.tab === 'comissoes') {
    if (!seeRes) body = empty('Sem permissão', 'Seu perfil não acessa comissões.', '', 'lock');
    else { const cm = commissions(s, r); body = `<div class="callout info" style="margin-bottom:12px">${icon('info')}<div>Cálculo simples: percentual do serviço sobre o valor realizado (inclui sessões de pacote pelo preço de tabela). Regras avançadas ficam para evolução.</div></div><div class="card"><div class="table-wrap"><table class="table"><thead><tr><th>Profissional</th><th class="num">Atendimentos/itens</th><th class="num">Base</th><th class="num">Comissão estimada</th></tr></thead><tbody>${s.professionals.map((p) => { const e = cm.get(p.id) || { base: 0, value: 0, count: 0 }; return `<tr><td>${esc(p.name)}</td><td class="num">${e.count}</td><td class="num">${money(e.base)}</td><td class="num strong">${money(e.value)}</td></tr>`; }).join('')}</tbody></table></div></div>`; }
  }
  return head + filters + T + body;
}
function cashHtml(s) {
  const d = today(); const pays = s.payments.filter((p) => p.date === d);
  const by = {}; for (const p of pays) by[p.method] = (by[p.method] || 0) + p.amount;
  const closed = s.cashClosings.find((c) => c.date === d);
  const hist = [...s.cashClosings].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 10);
  return `<div class="grid g2"><section class="card"><div class="card-head"><h3>Caixa de hoje · ${fmtDate(d)}</h3>${closed ? badge('Fechado', 'good') : badge('Aberto', 'warn')}</div>
  <form class="card-body stack" data-submit="cash-close" id="cash-form">${PAYMENT_METHODS.map((m) => `<div class="row-between"><span>${m.label}</span><span class="row"><span class="num strong" style="width:110px;text-align:right">${money(by[m.id] || 0)}</span>${!closed ? `<input class="input num" style="width:120px;height:34px" name="c_${m.id}" inputmode="decimal" placeholder="contado" aria-label="Valor contado ${m.label}" value="${moneyInput(by[m.id] || 0)}">` : `<span class="num small muted" style="width:120px;text-align:right">contado ${money(closed.counted[m.id] || 0)}</span>`}</span></div>`).join('')}
  <div class="divider"></div><div class="row-between"><b>Total esperado</b><b class="num">${money(pays.reduce((t, p) => t + p.amount, 0))}</b></div>
  ${!closed ? `${field('Observação', '<input class="input" name="note" placeholder="Ex.: troco inicial de R$ 100">')}<button class="btn primary" type="submit">Fechar caixa do dia</button>` : `<p class="small muted">Fechado por ${esc(user(s, closed.by)?.name)} em ${fmtDateTime(closed.at)}.</p>`}</form></section>
  <section class="card"><div class="card-head"><h3>Fechamentos anteriores</h3></div><div class="list">${hist.length ? hist.map((c) => { const exp = Object.values(c.expected).reduce((a, b) => a + b, 0); const cnt = Object.values(c.counted).reduce((a, b) => a + b, 0); return `<div class="list-item" style="cursor:default"><div class="li-main"><div class="li-title">${fmtDate(c.date)}</div><div class="li-sub">Esperado ${money(exp)} · contado ${money(cnt)}</div></div>${exp === cnt ? badge('Conferido', 'good') : badge(`Diferença ${money(cnt - exp)}`, 'warn')}</div>`; }).join('') : '<p class="small muted card-pad">Nenhum fechamento registrado ainda.</p>'}</div></section></div>`;
}
export function bindFinanceiro(root) {
  root.querySelectorAll('[data-fin]').forEach((el) => el.addEventListener('change', () => { ui.fin[el.dataset.fin] = el.value; window.__rerender(); }));
  bindPeriod(root, 'fin', ui.fin);
  root.querySelector('#fin-q')?.addEventListener('input', (e) => { ui.fin.q = e.target.value; clearTimeout(window.__ft); window.__ft = setTimeout(() => { window.__rerender(); const i = document.querySelector('#fin-q'); i?.focus(); i?.setSelectionRange(i.value.length, i.value.length); }, 250); });
}

// ---------- Folhas ----------
export function openReceive(saleId) {
  const d = { method: 'pix', key: 'rcv_' + Date.now() };
  openSheet({ title: 'Registrar pagamento', render: () => {
    const s = S(); const sl = byId(s.sales, saleId); const bal = saleTotal(sl) - salePaid(s, sl.id);
    if (bal <= 0) return `<div class="sheet-body">${empty('Venda quitada', 'Não há saldo pendente nesta venda.', '', 'checkCircle')}</div>`;
    return `<form class="sheet-body stack" data-submit="rcv-save" data-id="${sl.id}" id="rcv-form" novalidate>
      <div class="summary"><div class="strong">${esc(client(s, sl.clientId)?.name)}</div><div class="small muted">${esc(sl.items.map((i) => i.description).join(', '))} · venda de ${fmtDate(sl.date)}</div><dl class="kv" style="margin-top:8px"><dt>Total da venda</dt><dd>${money(saleTotal(sl))}</dd><dt>Já recebido</dt><dd>${money(salePaid(s, sl.id))}</dd><dt>Saldo pendente</dt><dd style="color:var(--bad)">${money(bal)}</dd></dl></div>
      ${field('Valor recebido agora (R$)', `<input class="input num" name="amount" inputmode="decimal" value="${moneyInput(bal)}">`, { hint: 'Pode ser parcial. O restante continua pendente.' })}
      <div class="stack-sm" data-field="method"><span class="label">Forma de pagamento</span><div class="chips">${PAYMENT_METHODS.map((m) => `<button type="button" class="chip" aria-pressed="${d.method === m.id}" data-action="rcv-method" data-v="${m.id}">${m.label}</button>`).join('')}</div></div>
      ${field('Data do recebimento', `<input class="input" type="date" name="date" value="${today()}" max="${today()}">`, { hint: 'Data própria do recebimento, independente da data da venda.' })}
    </form><div class="sheet-foot"><button class="btn" data-action="sheet-close">Cancelar</button><button class="btn primary" type="submit" form="rcv-form">Registrar recebimento</button></div>`;
  }, onMount: (root) => { root._rcv = d; } });
}
function openPaymentPicker() {
  openSheet({ title: 'Registrar pagamento', render: () => {
    const s = S(); const list = s.sales.filter((x) => x.status === 'valida' && saleTotal(x) > salePaid(s, x.id)).sort((a, b) => b.date.localeCompare(a.date));
    return `<div class="sheet-body stack"><p class="small muted">Escolha a venda com saldo pendente. Para vender algo novo, use “Nova venda”.</p><div class="input-icon">${icon('search')}<input class="input" id="pp-q" placeholder="Filtrar por cliente"></div><div class="list card" id="pp-list">${list.map((x) => `<button class="list-item" data-action="fin-receive" data-id="${x.id}" data-name="${esc(norm(client(s, x.clientId)?.name))}"><div class="li-main"><div class="li-title">${esc(client(s, x.clientId)?.name)}</div><div class="li-sub">${fmtDate(x.date)} · ${esc(x.items.map((i) => i.description).join(', '))}</div></div><span class="num strong" style="color:var(--bad)">${money(saleTotal(x) - salePaid(s, x.id))}</span></button>`).join('') || empty('Nada pendente', 'Todas as vendas estão quitadas.', '', 'checkCircle')}</div></div>`;
  }, onMount: (root) => { root.querySelector('#pp-q')?.addEventListener('input', (e) => { const v = norm(e.target.value); root.querySelectorAll('#pp-list .list-item').forEach((b) => { b.style.display = b.dataset.name.includes(v) ? '' : 'none'; }); }); } });
}
export function openNewSale(clientId) {
  const d = { clientId: clientId || '', items: [], method: 'pix', mode: 'total', amount: '', adding: '' };
  openSheet({ title: 'Nova venda avulsa', render: () => {
    const s = S(); const total = d.items.reduce((t, i) => t + i.unitPrice * i.qty, 0);
    return `<form class="sheet-body stack" data-submit="sale-save" id="sale-form" novalidate>
      ${clientPicker(d.clientId)}
      <div class="stack-sm"><span class="label">Itens</span>
        <div class="row"><select class="select" id="sl-svc">${options(s.services.filter((x) => x.active).map((x) => [x.id, `${x.name} — ${money(x.price)}`]), '', { placeholder: 'Adicionar serviço…' })}</select><button type="button" class="btn" data-action="sl-add">Adicionar</button></div>
        <div class="row"><input class="input" id="sl-desc" placeholder="Ou item livre (ex.: produto, taxa de cancelamento)"><input class="input" id="sl-price" placeholder="R$" style="width:100px" inputmode="decimal"><button type="button" class="btn" data-action="sl-add-free">Incluir</button></div>
        ${d.items.length ? d.items.map((i, n) => `<div class="row-between small card card-pad" style="padding:8px 12px"><span>${esc(i.description)}</span><span class="row"><span class="num">${money(i.unitPrice)}</span><button type="button" class="btn sm ghost icon" data-action="sl-del" data-i="${n}" aria-label="Remover">${icon('x')}</button></span></div>`).join('') : '<p class="xs subtle">Nenhum item adicionado.</p>'}
      </div>
      <div class="stack-sm"><span class="label">Pagamento</span>${['total', 'parcial', 'pendente'].map((m) => `<label class="check"><input type="radio" name="mode" value="${m}" ${d.mode === m ? 'checked' : ''} data-sl-mode>${{ total: 'Recebido integralmente', parcial: 'Recebido em parte', pendente: 'Pendente' }[m]}</label>`).join('')}</div>
      ${d.mode !== 'pendente' ? `<div class="chips">${PAYMENT_METHODS.map((m) => `<button type="button" class="chip" aria-pressed="${d.method === m.id}" data-action="sl-method" data-v="${m.id}">${m.label}</button>`).join('')}</div>` : ''}
      ${d.mode === 'parcial' ? field('Valor recebido (R$)', `<input class="input" name="amount" inputmode="decimal" value="${esc(d.amount)}" data-sl-amount>`) : ''}
      <div class="summary"><dl class="kv"><dt>Total da venda</dt><dd>${money(total)}</dd></dl></div>
    </form><div class="sheet-foot"><button class="btn" data-action="sheet-close">Cancelar</button><button class="btn primary" type="submit" form="sale-form">Registrar venda</button></div>`;
  }, onMount: (root) => { root._sl = d; bindClientPicker(root, (id) => { d.clientId = id; }); root.querySelectorAll('[data-sl-mode]').forEach((r) => r.addEventListener('change', () => { d.mode = r.value; refreshSheet(); })); root.querySelector('[data-sl-amount]')?.addEventListener('input', (e) => { d.amount = e.target.value; }); } });
}
export function openExpense(id) {
  const s = S(); const e = id ? byId(s.expenses, id) : null;
  openSheet({ title: e ? 'Editar despesa' : 'Registrar despesa', render: () => `<form class="sheet-body stack" data-submit="exp-save" data-id="${id || ''}" id="exp-form" novalidate><div class="form-grid">
    ${field('Descrição *', `<input class="input" name="description" value="${esc(e?.description || '')}">`, { full: true })}
    ${field('Categoria', `<select class="select" name="category">${options(EXP_CATS.map((c) => [c, c]), e?.category || 'Produtos')}</select>`)}
    ${field('Valor (R$) *', `<input class="input" name="amount" inputmode="decimal" value="${e ? moneyInput(e.amount) : ''}">`)}
    ${field('Vencimento *', `<input class="input" type="date" name="date" value="${e?.date || today()}">`)}
    ${field('Fornecedor', `<input class="input" name="supplier" value="${esc(e?.supplier || '')}">`)}
    <label class="check full"><input type="checkbox" name="paid" ${e?.paid ?? true ? 'checked' : ''}>Já foi paga</label>
    ${field('Data do pagamento', `<input class="input" type="date" name="paidDate" value="${e?.paidDate || today()}" max="${today()}">`)}
  </div><p class="xs subtle">Só despesas pagas entram no resultado de caixa estimado.</p></form><div class="sheet-foot"><button class="btn" data-action="sheet-close">Cancelar</button><button class="btn primary" type="submit" form="exp-form">Salvar</button></div>` });
}
function openSaleDetails(id) {
  openSheet({ title: 'Detalhes da venda', render: () => {
    const s = S(); const sl = byId(s.sales, id); const sit = saleSituation(s, sl); const pays = s.payments.filter((p) => p.saleId === id);
    const appt = sl.appointmentId ? byId(s.appointments, sl.appointmentId) : null;
    return `<div class="sheet-body stack"><div class="row-between"><div><div class="strong">${esc(client(s, sl.clientId)?.name)}</div><div class="small muted">Venda ${fmtDate(sl.date)} · ${{ servico: 'Atendimento', pacote: 'Pacote', avulsa: 'Avulsa', cortesia: 'Cortesia' }[sl.type]} · por ${esc(user(s, sl.createdBy)?.name || '—')}</div></div>${badge(sit.label, sit.tone)}</div>
    <div class="card"><table class="table"><thead><tr><th>Item</th><th class="num">Bruto</th><th class="num">Desconto</th><th class="num">Total</th></tr></thead><tbody>${sl.items.map((i) => `<tr><td>${esc(i.description)}${i.professionalId ? `<div class="xs subtle">${esc(professional(s, i.professionalId)?.name)}</div>` : ''}</td><td class="num">${money(i.unitPrice * i.qty)}</td><td class="num">${money(i.discount || 0)}</td><td class="num">${money(i.unitPrice * i.qty - (i.discount || 0))}</td></tr>`).join('')}</tbody></table></div>
    <dl class="kv summary"><dt>Bruto</dt><dd>${money(saleGross(sl))}</dd><dt>Descontos</dt><dd>${money(saleDiscount(sl))}</dd><dt>Total</dt><dd>${money(saleTotal(sl))}</dd><dt>Recebido</dt><dd>${money(salePaid(s, id))}</dd><dt>Saldo</dt><dd>${money(sl.status === 'valida' ? Math.max(0, saleTotal(sl) - salePaid(s, id)) : 0)}</dd></dl>
    ${sl.authorizedBy ? `<p class="small">Autorizada por <b>${esc(user(s, sl.authorizedBy)?.name)}</b>. ${esc(sl.note)}</p>` : ''}
    ${sl.status !== 'valida' ? `<div class="callout bad">${icon('ban')}<div>Cancelada em ${fmtDateTime(sl.cancelledAt)}: ${esc(sl.cancelReason)}</div></div>` : ''}
    <div><h3 style="margin-bottom:8px">Pagamentos</h3>${pays.length ? pays.map((p) => `<div class="row-between small" style="padding:6px 0;border-bottom:1px solid var(--border)"><span>${fmtDate(p.date)} · ${p.kind === 'estorno' ? `<b style="color:var(--bad)">Estorno</b> — ${esc(p.reason)}` : methodLabel(p.method)}</span><span class="row"><span class="num">${money(p.amount)}</span>${p.kind === 'recebimento' && !s.payments.some((x) => x.reversesId === p.id) && hasPerm(s, 'estornos.autorizar') ? `<button class="btn sm ghost danger" data-action="fin-reverse" data-id="${p.id}">Estornar</button>` : ''}</span></div>`).join('') : '<p class="small subtle">Nenhum pagamento.</p>'}</div>
    ${appt ? `<button class="btn ghost" data-action="appt-open" data-id="${appt.id}">${icon('calendar')}Ver atendimento</button>` : ''}
    </div><div class="sheet-foot">${sl.status === 'valida' && saleTotal(sl) > salePaid(s, id) ? `<button class="btn primary" data-action="fin-receive" data-id="${id}">Receber saldo</button>` : ''}${sl.status === 'valida' && hasPerm(s, 'estornos.autorizar') && !sl.appointmentId ? `<button class="btn danger" data-action="sale-cancel" data-id="${id}">Cancelar venda</button>` : ''}</div>`;
  } });
}

registerActions({
  'fin-tab': (el) => { ui.fin.tab = el.dataset.value; window.__rerender(); },
  'fin-receive': (el) => openReceive(el.dataset.id),
  'fin-sale': (el) => openSaleDetails(el.dataset.id),
  'new-payment': () => openPaymentPicker(),
  'new-sale': () => openNewSale(),
  'new-expense': (el) => openExpense(el?.dataset?.id),
  'rcv-method': (el) => { el.closest('.overlay')._rcv.method = el.dataset.v; el.closest('.chips').querySelectorAll('.chip').forEach((b) => b.setAttribute('aria-pressed', b === el)); },
  'rcv-save': (form, data) => { const d = form.closest('.overlay')._rcv; const amt = parseMoney(data.amount); if (isNaN(amt)) throw Object.assign(new Error('Valor inválido.'), { field: 'amount' }); op.registerPayment({ saleId: form.dataset.id, amount: amt, method: d.method, date: data.date, idempotencyKey: d.key }); closeSheet(); toast('Recebimento registrado.'); },
  'fin-reverse': async (el) => { const r = await confirmDialog({ title: 'Estornar recebimento?', message: 'O registro original é preservado e um movimento de estorno é criado. O valor volta a ficar pendente na venda.', confirmLabel: 'Estornar', danger: true, input: { label: 'Motivo *', required: true } }); if (r) { op.reversePayment(el.dataset.id, r); toast('Estorno registrado.'); } },
  'sale-cancel': async (el) => { const r = await confirmDialog({ title: 'Cancelar venda?', message: 'Só é possível sem recebimentos ativos. O registro fica no histórico como cancelado.', confirmLabel: 'Cancelar venda', danger: true, input: { label: 'Motivo *', required: true } }); if (r) { try { op.cancelSale(el.dataset.id, r); toast('Venda cancelada.'); } catch (e) { toast(e.message, 'err'); } } },
  'exp-save': (form, d) => { const amt = parseMoney(d.amount); op.saveExpense({ id: form.dataset.id || undefined, description: d.description, category: d.category, amount: amt, date: d.date, paid: d.paid, paidDate: d.paidDate, supplier: d.supplier }); closeSheet(); toast('Despesa salva.'); },
  'exp-pay': (el) => { op.payExpense(el.dataset.id); toast('Despesa marcada como paga hoje.'); },
  'cash-close': async (form, d) => { const counted = {}; for (const m of PAYMENT_METHODS) { const v = parseMoney(d['c_' + m.id]); counted[m.id] = isNaN(v) ? 0 : v; } if (await confirmDialog({ title: 'Fechar caixa do dia?', message: 'Depois de fechado, o resumo do dia fica registrado para conferência.', confirmLabel: 'Fechar caixa' })) { op.closeCash({ date: today(), counted, note: d.note }); toast('Caixa fechado.'); } },
  'sl-add': (el) => { const root = el.closest('.overlay'); const id = root.querySelector('#sl-svc').value; if (!id) return; const sv = service(S(), id); root._sl.items.push({ serviceId: id, description: sv.name, qty: 1, unitPrice: sv.price, discount: 0 }); refreshSheet(); },
  'sl-add-free': (el) => { const root = el.closest('.overlay'); const desc = root.querySelector('#sl-desc').value.trim(); const p = parseMoney(root.querySelector('#sl-price').value); if (!desc || isNaN(p) || p <= 0) { toast('Informe descrição e valor do item.', 'err'); return; } root._sl.items.push({ serviceId: null, description: desc, qty: 1, unitPrice: p, discount: 0 }); refreshSheet(); },
  'sl-del': (el) => { el.closest('.overlay')._sl.items.splice(Number(el.dataset.i), 1); refreshSheet(); },
  'sl-method': (el) => { el.closest('.overlay')._sl.method = el.dataset.v; el.closest('.chips').querySelectorAll('.chip').forEach((b) => b.setAttribute('aria-pressed', b === el)); },
  'sale-save': (form) => { const d = form.closest('.overlay')._sl; if (!d.clientId) throw Object.assign(new Error('Escolha a cliente.'), { field: 'clientId' }); const total = d.items.reduce((t, i) => t + i.unitPrice * i.qty, 0); const amt = d.mode === 'total' ? total : d.mode === 'pendente' ? 0 : parseMoney(d.amount); if (d.mode === 'parcial' && (isNaN(amt) || amt <= 0 || amt >= total)) throw Object.assign(new Error('Valor parcial deve ser maior que zero e menor que o total.'), { field: 'amount' }); op.createSale({ clientId: d.clientId, items: d.items, method: d.method, amountReceived: amt }); closeSheet(); toast('Venda registrada.'); },
  'fin-export': (el) => { const s = S(); const F = ui.fin; const r = presetRange(F.preset, today(), F.custom); if (el.dataset.what === 'vendas') { const rows = s.sales.filter((x) => x.date >= r.from && x.date <= r.to); download(`vendas_${r.from}_${r.to}.csv`, toCSV(rows, [{ label: 'ID', key: 'id' }, { label: 'Data', value: (x) => fmtDate(x.date) }, { label: 'Cliente', value: (x) => client(s, x.clientId)?.name }, { label: 'Tipo', key: 'type' }, { label: 'Itens', value: (x) => x.items.map((i) => i.description).join(' + ') }, { label: 'Bruto', value: (x) => (saleGross(x) / 100).toFixed(2).replace('.', ',') }, { label: 'Desconto', value: (x) => (saleDiscount(x) / 100).toFixed(2).replace('.', ',') }, { label: 'Total', value: (x) => (saleTotal(x) / 100).toFixed(2).replace('.', ',') }, { label: 'Recebido', value: (x) => (salePaid(s, x.id) / 100).toFixed(2).replace('.', ',') }, { label: 'Situação', value: (x) => saleSituation(s, x).label }])); } else { const rows = s.payments.filter((p) => p.date >= r.from && p.date <= r.to); download(`recebimentos_${r.from}_${r.to}.csv`, toCSV(rows, [{ label: 'ID', key: 'id' }, { label: 'Data', value: (p) => fmtDate(p.date) }, { label: 'Cliente', value: (p) => client(s, p.clientId)?.name }, { label: 'Forma', value: (p) => methodLabel(p.method) }, { label: 'Tipo', key: 'kind' }, { label: 'Valor', value: (p) => (p.amount / 100).toFixed(2).replace('.', ',') }, { label: 'Venda', key: 'saleId' }])); } },
});
