// Contexto compartilhado da interface (estado de tela, navegação).
import { getState } from '../data/store.js';
export const S = () => getState();
export const ui = {
  agenda: { view: 'dia', date: null, pro: '', service: '', category: '', status: '' },
  dash: { preset: 'mes', compare: 'equivalente', pro: '', service: '', category: '', clientType: '', status: '', unit: '', custom: null, gran: 'auto' },
  clientes: { q: '', filter: '', sort: 'nome', page: 1 },
  fin: { tab: 'visao', preset: 'mes', pro: '', method: '', q: '', custom: null },
  crm: { tab: 'segmentos', seg: 'recorrentes' },
  rel: { tab: 'operacional', preset: 'mes', custom: null },
  cfg: { tab: 'estabelecimento' },
  serv: { tab: 'servicos', q: '', cat: '' },
};
let navigator = () => {};
export function setNavigator(fn) { navigator = fn; }
export function go(path) { navigator(path); }
export function now() { const s = S(); return `${s.settings.refDate}T${s.settings.demoTime}`; }
export function today() { return S().settings.refDate; }
