// Controle de período reutilizável (presets + personalizado).
import { PRESETS } from '../metrics/metrics.js';
import { options } from './dom.js';
import { today } from './ctx.js';
import { startOfMonth } from '../util.js';

export function periodControl(key, preset, custom) {
  return `<select class="select" data-period="${key}" aria-label="Período">${options(PRESETS, preset)}</select>${preset === 'custom' ? `<input type="date" class="input" style="width:auto" data-period-from="${key}" value="${custom?.from || startOfMonth(today())}" max="${today()}" aria-label="De"><input type="date" class="input" style="width:auto" data-period-to="${key}" value="${custom?.to || today()}" max="${today()}" aria-label="Até">` : ''}`;
}
export function bindPeriod(root, key, st) {
  root.querySelector(`[data-period="${key}"]`)?.addEventListener('change', (e) => { st.preset = e.target.value; if (st.preset === 'custom' && !st.custom) st.custom = { from: startOfMonth(today()), to: today() }; window.__rerender(); });
  const f = root.querySelector(`[data-period-from="${key}"]`), t = root.querySelector(`[data-period-to="${key}"]`);
  const upd = () => { let from = f.value, to = t.value; if (from && to && from > to) [from, to] = [to, from]; st.custom = { from: from || startOfMonth(today()), to: to || today() }; window.__rerender(); };
  f?.addEventListener('change', upd); t?.addEventListener('change', upd);
}
