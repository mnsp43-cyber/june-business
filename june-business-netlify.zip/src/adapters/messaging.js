// Adaptadores de mensageria. A interface do CRM conhece apenas este contrato:
//   send({ channel, to, text, purpose, idempotencyKey }) -> { status, providerId, simulated }
// Protótipo: provedor SIMULADO (nenhuma mensagem real sai do navegador).
// MVP: WhatsAppBusinessPlatformAdapter (API oficial da Meta, templates aprovados,
// webhooks de entrega) e EmailAdapter (ex.: provedor transacional) no servidor.

function hash(str) { let h = 2166136261; for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0) / 4294967296; }

export const SimulatedProvider = {
  id: 'simulado', label: 'Provedor simulado (demonstração)', simulated: true,
  send({ channel, to, idempotencyKey }) {
    if (!to) return { status: 'falhou', error: channel === 'email' ? 'Cliente sem e-mail' : 'Cliente sem telefone', simulated: true };
    const r = hash(idempotencyKey || String(Math.random()));
    // Resultado determinístico a partir da chave, apenas para demonstrar estados.
    const status = r < 0.05 ? 'falhou' : r < 0.45 ? 'lida' : 'entregue';
    return { status, providerId: 'sim_' + Math.floor(r * 1e9).toString(36), simulated: true, error: status === 'falhou' ? 'Falha simulada de entrega' : null };
  },
};

export const WhatsAppBusinessPlatformAdapter = {
  id: 'whatsapp_cloud', label: 'WhatsApp Business Platform (oficial)', simulated: false,
  send() { throw new Error('Integração não conectada. Disponível a partir da etapa de integrações reais.'); },
};
export const EmailAdapter = {
  id: 'email', label: 'Provedor de e-mail', simulated: false,
  send() { throw new Error('Integração não conectada.'); },
};

export function providerFor(/* channel */) { return SimulatedProvider; }

// Abrir conversa individual (ação explícita da usuária). NÃO registra como enviada.
export function waLink(phoneE164, text) { return `https://wa.me/${String(phoneE164 || '').replace(/\D/g, '')}?text=${encodeURIComponent(text || '')}`; }
