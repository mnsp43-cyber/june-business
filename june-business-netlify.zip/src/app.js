// Aplicação: shell (menu lateral, barra inferior), roteamento, login e ações globais.
import { load, subscribe, getState, lastError } from './data/store.js';
import { S, setNavigator, go, ui } from './ui/ctx.js';
import { esc, initials, fmtDate, firstName } from './util.js';
import { MODULES, ROLES } from './domain/rules.js';
import { currentUser, hasPerm } from './services/core.js';
import * as op from './services/operations.js';
import './services/crm.js';
import { icon, registerActions, initDelegation, refreshAllSheets, closeAllSheets, openMenu, toast, empty, showError } from './ui/dom.js';
import { openNewAppointment } from './ui/appointments.js';
import * as MeuDia from './ui/screens/meudia.js';
import * as Agenda from './ui/screens/agenda.js';
import * as Clientes from './ui/screens/clientes.js';
import * as Servicos from './ui/screens/servicos.js';
import * as Financeiro from './ui/screens/financeiro.js';
import * as Dashboard from './ui/screens/dashboard.js';
import * as CRM from './ui/screens/crm.js';
import * as Relatorios from './ui/screens/relatorios.js';
import * as Config from './ui/screens/config.js';

const root = document.getElementById('app');
let current = null;

// Roteamento em memória; a hash guarda só o nome do módulo (#agenda), compatível com hospedagem em frames.
let routePath = (location.hash.replace(/^#\/?/, '') || 'meu-dia');
function parse() { const parts = routePath.split('/').filter(Boolean); return { path: '/' + parts.join('/'), parts }; }
function setHash(mod) { const h = '#' + mod; if (location.hash !== h) { try { history.replaceState(null, '', h); } catch { location.hash = h; } } }

function shell(route, title, content) {
  const s = S(); const u = currentUser(s);
  const mods = MODULES.filter((m) => !m.perm || hasPerm(s, m.perm));
  const active = route.parts[0];
  const isActive = (id) => active === id || (id === 'meu-dia' && !active);
  const bottom = [['meu-dia', 'Meu Dia', 'sun'], ['agenda', 'Agenda', 'calendar'], ['dashboard', 'Dados', 'chart'], ['clientes', 'Clientes', 'users'], ['financeiro', 'Finanças', 'wallet'], ['mais', 'Mais', 'grid']]
    .filter(([id]) => id === 'mais' || mods.some((m) => m.id === id));
  const moreActive = ['servicos', 'crm', 'relatorios', 'config', 'mais'].includes(active);
  return `<div class="app">
    <aside class="sidebar" aria-label="Menu principal"><div class="brand"><div class="brand-mark" aria-hidden="true">J</div><div class="brand-name">June Business<small>Gestão simples. Negócios mais inteligentes.</small></div></div>
      <nav class="nav">${mods.map((m) => `<a href="#${m.id}" data-action="go" data-to="/${m.id}" ${isActive(m.id) ? 'aria-current="page"' : ''} title="${m.label}">${icon(m.icon)}<span>${m.label}</span></a>`).join('')}</nav>
      <div class="side-foot">${esc(s.org.name)}<br>Ambiente demonstrativo · dados fictícios</div></aside>
    <div class="main">
      <header class="topbar"><div class="brand-mark mobile-brand" aria-hidden="true">J</div><div class="page-title"><span class="ellipsis">${esc(title)}</span></div>
        <button class="demo-pill" style="border:0;cursor:pointer" data-action="go" data-to="/config/dados" title="Dados fictícios. Data de referência da simulação — clique para ajustar">Demo · ${fmtDate(s.settings.refDate).slice(0, 5)} ${s.settings.demoTime}</button>
        <div class="row desktop-only">${hasPerm(s, 'agenda.editar') ? `<button class="btn primary" data-action="new-appt">${icon('plus')}Novo agendamento</button><button class="btn icon" data-action="quick-menu" aria-label="Outras ações rápidas">${icon('down')}</button>` : ''}</div>
        <button class="avatar" data-action="user-menu" aria-label="Menu do usuário: ${esc(u.name)}" title="${esc(u.name)} · ${ROLES[u.role]}">${initials(u.name)}</button></header>
      ${lastError() ? `<div class="callout bad" style="margin:12px 24px 0">${icon('alert')}<div>${esc(lastError())}</div></div>` : ''}
      <main class="content" id="main" tabindex="-1">${content}</main>
    </div>
    <nav class="bottomnav" aria-label="Navegação">${bottom.map(([id, label, ic]) => `<a href="#${id}" data-action="go" data-to="/${id}" ${(id === 'mais' ? moreActive : isActive(id)) ? 'aria-current="page"' : ''}>${icon(ic)}<span>${label}</span></a>`).join('')}</nav>
    ${hasPerm(s, 'agenda.editar') ? `<button class="fab" data-action="quick-menu" aria-label="Ação rápida: novo agendamento e outras">${icon('plus')}</button>` : ''}
  </div>`;
}

function renderLogin() {
  const saved = 'admin@junebusiness.com';
  root.innerHTML = `<div class="login"><form class="login-card" data-submit="login" novalidate>
    <div class="brand"><div class="brand-mark" aria-hidden="true">J</div><div class="brand-name">June Business<small>Gestão simples. Negócios mais inteligentes.</small></div></div>
    <h1 style="font-size:20px;margin-bottom:4px">Entrar</h1><p class="small muted" style="margin-bottom:20px">Acesse a gestão do seu negócio.</p>
    <div class="stack-sm">
      <div class="field"><label for="lg-email">E-mail</label><input class="input" id="lg-email" name="email" type="email" autocomplete="username" value="${saved}"></div>
      <div class="field"><label for="lg-pass">Senha</label><div class="input-affix"><input class="input" id="lg-pass" name="password" type="password" autocomplete="current-password" value="demo123" style="padding-right:44px"><button type="button" class="btn ghost icon sm affix" data-action="toggle-pass" aria-label="Mostrar senha" aria-pressed="false">${icon('eye')}</button></div></div>
      <button class="btn primary lg block" type="submit" style="margin-top:8px">Entrar</button>
    </div>
    <p class="login-foot">Versão de demonstração com dados fictícios. O acesso local não é uma autenticação segura.</p>
  </form></div>`;
  document.getElementById('lg-email').focus();
}

const titles = { 'meu-dia': 'Meu Dia', agenda: 'Agenda', dashboard: 'Dashboard', clientes: 'Clientes', servicos: 'Serviços e Pacotes', financeiro: 'Financeiro', crm: 'CRM e Campanhas', relatorios: 'Relatórios', config: 'Configurações', mais: 'Mais' };
function renderRoute({ keepScroll = false } = {}) {
  const s = getState(); const route = parse();
  if (!s.settings.session || !currentUser(s)) { if (route.parts[0] !== 'login') { routePath = 'login'; setHash('login'); } renderLogin(); current = 'login'; return; }
  if (route.parts[0] === 'login') { routePath = 'meu-dia'; setHash('meu-dia'); }
  const route2 = parse(); route.parts = route2.parts; route.path = route2.path;
  const id = route.parts[0] || 'meu-dia';
  const mod = MODULES.find((m) => m.id === id);
  const y = window.scrollY;
  let content = ''; let bind = null; let title = titles[id] || 'June Business';
  try {
    if (mod && mod.perm && !hasPerm(s, mod.perm)) content = empty('Acesso restrito', `O perfil ${ROLES[currentUser(s).role]} não tem acesso a ${mod.label}. Fale com a proprietária.`, '<button class="btn" data-action="go" data-to="/meu-dia">Ir para Meu Dia</button>', 'lock');
    else switch (id) {
      case 'meu-dia': content = MeuDia.render(); break;
      case 'agenda': content = Agenda.render(); bind = Agenda.bindAgenda; break;
      case 'clientes': if (route.parts[1]) { content = Clientes.renderProfile(route.parts[1], route.parts[2] || 'visao'); title = 'Perfil da cliente'; } else { content = Clientes.render(); bind = Clientes.bindClientes; } break;
      case 'servicos': content = Servicos.render(); bind = Servicos.bindServicos; break;
      case 'financeiro': content = Financeiro.render(); bind = Financeiro.bindFinanceiro; break;
      case 'dashboard': content = Dashboard.render(); bind = Dashboard.bindDashboard; break;
      case 'crm': content = CRM.render(); bind = CRM.bindCRM; break;
      case 'relatorios': content = Relatorios.render(); bind = Relatorios.bindRelatorios; break;
      case 'config': content = Config.render(route.parts[1]); break;
      case 'mais': content = moreHtml(); break;
      default: content = empty('Página não encontrada', 'Use o menu para navegar.', '<button class="btn" data-action="go" data-to="/meu-dia">Ir para Meu Dia</button>');
    }
  } catch (e) { console.error(e); content = `<div class="callout bad">${icon('alert')}<div>Erro ao montar a tela: ${esc(e.message)}</div></div>`; }
  root.innerHTML = shell(route, title, content);
  const main = document.getElementById('main'); bind?.(main);
  document.title = `${title} · June Business`;
  if (keepScroll) window.scrollTo(0, y); else if (current !== route.path) { window.scrollTo(0, 0); }
  current = route.path;
}
function moreHtml() {
  const s = S(); const items = [['servicos', 'tag', 'Serviços e Pacotes', 'Catálogo, preços e pacotes'], ['crm', 'megaphone', 'CRM e Campanhas', 'Segmentos, campanhas e jornadas'], ['relatorios', 'file', 'Relatórios', 'Tabelas e exportação CSV'], ['config', 'gear', 'Configurações', 'Estabelecimento, equipe e dados'], ['config/perfil', 'user', 'Meu perfil', 'Dados de acesso e troca de perfil'], ['config/equipe', 'users', 'Equipe e permissões', 'Usuários e papéis'], ['config/integracoes', 'link', 'Integrações', 'WhatsApp, e-mail, pagamentos']];
  const allowed = items.filter(([id]) => { const m = MODULES.find((x) => x.id === id.split('/')[0]); return !m?.perm || hasPerm(s, m.perm); }).filter(([id]) => id !== 'config/equipe' || hasPerm(s, 'equipe.gerir'));
  return `<div class="more-grid">${allowed.map(([id, ic, l, sub]) => `<a href="#${id.split('/')[0]}" data-action="go" data-to="/${id}">${icon(ic)}${l}<small>${sub}</small></a>`).join('')}</div>
  <div class="card card-pad" style="margin-top:16px"><div class="row-between"><div class="row"><div class="avatar">${initials(currentUser(s).name)}</div><div><div class="strong">${esc(currentUser(s).name)}</div><div class="xs muted">${ROLES[currentUser(s).role]}</div></div></div><button class="btn sm danger" data-action="logout">${icon('logout')}Sair</button></div></div>`;
}

registerActions({
  'go': (el) => { closeAllSheets(); go(el.dataset.to); },
  'new-appt': () => openNewAppointment(),
  'new-client': () => Clientes.openClientForm(),
  'quick-menu': (el) => { const s = S(); const items = [{ label: 'Novo agendamento', action: 'new-appt', icon: 'calendar' }, { label: 'Novo cliente', action: 'new-client', icon: 'user' }]; if (hasPerm(s, 'pagamentos.registrar')) items.push({ label: 'Nova venda', action: 'new-sale', icon: 'cash' }, { label: 'Registrar pagamento', action: 'new-payment', icon: 'wallet' }); if (hasPerm(s, 'campanhas.criar')) items.push({ label: 'Criar campanha', action: 'new-campaign', icon: 'megaphone' }); openMenu(el, items); },
  'user-menu': (el) => { const s = S(); openMenu(el, [{ label: 'Meu perfil', action: 'go', icon: 'user', data: { to: '/config/perfil' } }, ...(hasPerm(s, 'equipe.gerir') ? [{ label: 'Equipe e permissões', action: 'go', icon: 'users', data: { to: '/config/equipe' } }] : []), { label: 'Trocar perfil (demonstração)', action: 'go', icon: 'refresh', data: { to: '/config/perfil' } }, { label: 'Dados demonstrativos', action: 'go', icon: 'gear', data: { to: '/config/dados' } }, '-', { label: 'Sair', action: 'logout', icon: 'logout', danger: true }]); },
  'toggle-pass': (el) => { const i = document.getElementById('lg-pass'); const show = i.type === 'password'; i.type = show ? 'text' : 'password'; el.innerHTML = icon(show ? 'eyeOff' : 'eye'); el.setAttribute('aria-pressed', String(show)); el.setAttribute('aria-label', show ? 'Ocultar senha' : 'Mostrar senha'); },
  'login': (form, d) => { routePath = 'meu-dia'; op.login(d.email, d.password); setHash('meu-dia'); },
});

setNavigator((path) => { routePath = path.replace(/^\//, ''); setHash(routePath.split('/')[0]); closeAllSheets(); renderRoute(); });
export function currentRoute() { return parse(); }
window.__rerender = () => renderRoute({ keepScroll: true });

initDelegation();
load();
subscribe(() => { if (current === 'login' && !getState().settings.session) return; renderRoute({ keepScroll: true }); refreshAllSheets(); });
window.addEventListener('hashchange', () => { const h = location.hash.replace(/^#\/?/, ''); if (h && h.split('/')[0] !== routePath.split('/')[0]) { routePath = h; closeAllSheets(); renderRoute(); } });
renderRoute();
// Exposto apenas para depuração no console do navegador
window.juneBusiness = { state: () => getState() };
