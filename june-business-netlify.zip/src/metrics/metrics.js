// Motor de métricas: funções puras sobre os registros de origem.
// Dashboard, Relatórios, Meu Dia, Clientes e CRM usam estas mesmas definições.
import { addDays, addMonths, diffDays, startOfMonth, endOfMonth, startOfWeek, dow, timeToMin, parseDate, fmtDate, fmtMonth, fmtDateShort, MONTHS } from '../util.js';
import { saleTotal, saleGross, saleDiscount, packageRemaining, blocksFor } from '../services/core.js';

export const METRIC_DICTIONARY = [
  { key: 'gross', label: 'Faturamento bruto', def: 'Soma do valor bruto dos itens das vendas registradas no período (antes de descontos), pela data da venda.' },
  { key: 'net', label: 'Vendas líquidas', def: 'Faturamento bruto − descontos (inclui cortesias) − vendas canceladas − estornos do período.' },
  { key: 'received', label: 'Recebido', def: 'Entradas confirmadas pela data do recebimento, já descontados os estornos do período.' },
  { key: 'receivable', label: 'A receber', def: 'Saldo ainda não pago das vendas válidas, na posição do último dia do período.' },
  { key: 'ticket', label: 'Ticket médio por atendimento', def: 'Vendas vinculadas a atendimentos realizados com venda ÷ quantidade desses atendimentos. Sessões de pacote e cortesias ficam fora.' },
  { key: 'attendance', label: 'Taxa de comparecimento', def: 'Realizados ÷ (realizados + faltas). Cancelamentos são tratados à parte.' },
  { key: 'occupancy', label: 'Taxa de ocupação', def: 'Minutos de atendimentos realizados ÷ minutos disponíveis (jornada − intervalos − bloqueios).' },
  { key: 'attended', label: 'Clientes atendidas', def: 'Clientes distintas com pelo menos uma visita realizada no período.' },
  { key: 'newClients', label: 'Clientes novas', def: 'Primeira visita realizada dentro do período.' },
  { key: 'recurrent', label: 'Clientes recorrentes', def: 'Visita realizada no período e pelo menos uma visita anterior.' },
  { key: 'reactivated', label: 'Clientes reativadas', def: 'Voltaram no período depois de ultrapassar o limite de inatividade configurado.' },
  { key: 'inactive', label: 'Clientes inativas', def: 'Tinham visita realizada e estão sem visita há mais que o limite de inatividade (posição no fim do período).' },
  { key: 'expensesPaid', label: 'Despesas pagas', def: 'Despesas pela data efetiva de pagamento.' },
  { key: 'cashResult', label: 'Resultado de caixa estimado', def: 'Recebido líquido − despesas pagas. Não é lucro contábil.' },
  { key: 'accrualResult', label: 'Resultado por competência', def: 'Vendas líquidas − despesas pela data de vencimento. Critério separado, apenas estimativo.' },
];

// ---------- Índices por estado (memo por objeto de estado) ----------
const memo = new WeakMap();
export function idx(s) {
  let m = memo.get(s); if (m) return m;
  const saleById = new Map(s.sales.map((x) => [x.id, x]));
  const serviceById = new Map(s.services.map((x) => [x.id, x]));
  const paysBySale = new Map(); for (const p of s.payments) { if (!paysBySale.has(p.saleId)) paysBySale.set(p.saleId, []); paysBySale.get(p.saleId).push(p); }
  const apptsByClient = new Map(); for (const a of s.appointments) { if (!apptsByClient.has(a.clientId)) apptsByClient.set(a.clientId, []); apptsByClient.get(a.clientId).push(a); }
  for (const l of apptsByClient.values()) l.sort((x, y) => (x.date + x.start).localeCompare(y.date + y.start));
  const salesByClient = new Map(); for (const x of s.sales) { if (!salesByClient.has(x.clientId)) salesByClient.set(x.clientId, []); salesByClient.get(x.clientId).push(x); }
  const saleTot = new Map(s.sales.map((x) => [x.id, saleTotal(x)]));
  m = { saleById, serviceById, paysBySale, apptsByClient, salesByClient, saleTot, cache: new Map() };
  memo.set(s, m); return m;
}
const paidUntil = (I, saleId, until) => { let t = 0; for (const p of I.paysBySale.get(saleId) || []) if (!until || p.date <= until) t += p.amount; return t; };

// ---------- Estatísticas por cliente ----------
export function clientStats(s, clientId, refDate = s.settings.refDate) {
  const I = idx(s); const key = 'cs:' + clientId + refDate; if (I.cache.has(key)) return I.cache.get(key);
  const appts = I.apptsByClient.get(clientId) || [];
  const visits = appts.filter((a) => a.status === 'realizado' && a.date <= refDate);
  const sales = (I.salesByClient.get(clientId) || []).filter((x) => x.status === 'valida');
  const totalSales = sales.reduce((t, x) => t + I.saleTot.get(x.id), 0);
  const paidSales = sales.filter((x) => I.saleTot.get(x.id) > 0);
  let pending = 0; for (const x of sales) pending += Math.max(0, I.saleTot.get(x.id) - paidUntil(I, x.id));
  const gaps = []; for (let i = 1; i < visits.length; i++) gaps.push(diffDays(visits[i].date, visits[i - 1].date));
  const cps = s.clientPackages.filter((cp) => cp.clientId === clientId && cp.status !== 'cancelado');
  const activePkgs = cps.filter((cp) => cp.expiresAt >= refDate && packageRemaining(s, cp) > 0);
  const last12 = addDays(refDate, -365);
  const r = {
    visits, visitCount: visits.length,
    firstVisit: visits[0]?.date || null, lastVisit: visits.at(-1)?.date || null,
    daysSince: visits.length ? diffDays(refDate, visits.at(-1).date) : null,
    avgFrequency: gaps.length ? Math.round(gaps.reduce((a, b) => a + b, 0) / gaps.length) : null,
    purchases: paidSales.length, totalSales, ticket: paidSales.length ? Math.round(totalSales / paidSales.length) : 0,
    sales12m: sales.filter((x) => x.date >= last12).reduce((t, x) => t + I.saleTot.get(x.id), 0),
    pending,
    noShows: appts.filter((a) => a.status === 'falta').length, cancels: appts.filter((a) => a.status === 'cancelado').length,
    services: [...new Set(visits.map((a) => a.serviceId))], professionals: [...new Set(visits.map((a) => a.professionalId))],
    packages: cps, activePackages: activePkgs, sessionsLeft: activePkgs.reduce((t, cp) => t + packageRemaining(s, cp), 0),
    future: appts.filter((a) => (a.date > refDate || (a.date === refDate && a.start >= s.settings.demoTime)) && ['agendado', 'confirmado'].includes(a.status)),
  };
  I.cache.set(key, r); return r;
}

// ---------- Períodos ----------
export const PRESETS = [
  ['hoje', 'Hoje'], ['ontem', 'Ontem'], ['7d', 'Últimos 7 dias'], ['mes', 'Mês atual'], ['mes_ant', 'Mês anterior'],
  ['3m', 'Últimos 3 meses'], ['6m', 'Últimos 6 meses'], ['ano', 'Ano atual'], ['custom', 'Período personalizado'],
];
export function presetRange(preset, ref, custom) {
  switch (preset) {
    case 'hoje': return { from: ref, to: ref };
    case 'ontem': { const y = addDays(ref, -1); return { from: y, to: y }; }
    case '7d': return { from: addDays(ref, -6), to: ref };
    case 'mes': return { from: startOfMonth(ref), to: ref, partialMonth: true };
    case 'mes_ant': { const p = addMonths(startOfMonth(ref), -1); return { from: p, to: endOfMonth(p) }; }
    case '3m': return { from: addDays(addMonths(ref, -3), 1), to: ref };
    case '6m': return { from: addDays(addMonths(ref, -6), 1), to: ref };
    case 'ano': return { from: ref.slice(0, 4) + '-01-01', to: ref, partialYear: true };
    case 'custom': return { from: custom?.from || startOfMonth(ref), to: custom?.to || ref };
    default: return { from: startOfMonth(ref), to: ref };
  }
}
// mode: 'equivalente' (padrão para períodos incompletos) ou 'completo'
export function previousRange(r, preset, mode = 'equivalente') {
  const len = diffDays(r.to, r.from) + 1;
  if (preset === 'mes' || (r.partialMonth)) {
    const pm = addMonths(r.from, -1);
    if (mode === 'completo') return { from: pm, to: endOfMonth(pm), label: 'mês anterior completo' };
    const day = Number(r.to.slice(8)); const end = Math.min(day, Number(endOfMonth(pm).slice(8)));
    return { from: pm, to: pm.slice(0, 8) + String(end).padStart(2, '0'), label: `dias 1 a ${end} do mês anterior` };
  }
  if (preset === 'ano') {
    const py = String(Number(r.from.slice(0, 4)) - 1);
    if (mode === 'completo') return { from: py + '-01-01', to: py + '-12-31', label: 'ano anterior completo' };
    return { from: py + '-01-01', to: py + r.to.slice(4), label: 'mesmo período do ano anterior' };
  }
  if (preset === 'mes_ant') { const pm = addMonths(r.from, -1); return { from: pm, to: endOfMonth(pm), label: 'mês anterior a ele' }; }
  return { from: addDays(r.from, -len), to: addDays(r.from, -1), label: `${len} ${len === 1 ? 'dia' : 'dias'} anteriores` };
}
export function rangeLabel(r) { return r.from === r.to ? fmtDate(r.from) : `${fmtDate(r.from)} a ${fmtDate(r.to)}`; }

// ---------- Variação ----------
// ((atual − anterior) ÷ anterior) × 100; anterior = 0 → não calculável. Taxas também em p.p.
export function variation(cur, prev, { isRate = false, goodWhenUp = true } = {}) {
  const calculable = prev !== 0 && prev != null && cur != null;
  const pctv = calculable ? ((cur - prev) / Math.abs(prev)) * 100 : null;
  const dir = cur > prev ? 'up' : cur < prev ? 'down' : 'flat';
  const pp = isRate && cur != null && prev != null ? cur - prev : null;
  const good = dir === 'flat' ? null : (dir === 'up') === goodWhenUp;
  return { cur, prev, pct: pctv, pp, dir, calculable, good };
}

// ---------- Filtros ----------
// filters: { professionalId, serviceId, category, clientType: 'novo'|'recorrente'|'', status, unit }
function itemMatch(I, it, f) {
  if (f.professionalId && it.professionalId !== f.professionalId) return false;
  if (f.serviceId && it.serviceId !== f.serviceId) return false;
  if (f.category) { const sv = it.serviceId ? I.serviceById.get(it.serviceId) : null; if (!sv || sv.category !== f.category) return false; }
  return true;
}
const hasItemFilter = (f) => !!(f.professionalId || f.serviceId || f.category);
function apptMatch(s, I, a, f) {
  if (f.professionalId && a.professionalId !== f.professionalId) return false;
  if (f.serviceId && a.serviceId !== f.serviceId) return false;
  if (f.category && I.serviceById.get(a.serviceId)?.category !== f.category) return false;
  return true;
}
function clientTypeSet(s, r, type) {
  if (!type) return null; const set = new Set();
  for (const [cid, list] of idx(s).apptsByClient) {
    const vis = list.filter((a) => a.status === 'realizado');
    const inP = vis.filter((a) => a.date >= r.from && a.date <= r.to); if (!inP.length) continue;
    const before = vis.some((a) => a.date < r.from);
    if (type === 'novo' && !before) set.add(cid); if (type === 'recorrente' && before) set.add(cid);
  }
  return set;
}

// ---------- KPIs ----------
export function computeKPIs(s, r, f = {}) {
  const I = idx(s); const ck = 'k:' + JSON.stringify([r.from, r.to, f]); if (I.cache.has(ck)) return I.cache.get(ck);
  const cset = clientTypeSet(s, r, f.clientType);
  const okClient = (id) => !cset || cset.has(id);
  const inR = (d) => d >= r.from && d <= r.to;
  const itemsF = hasItemFilter(f);
  let gross = 0, discount = 0, cancelled = 0, salesCount = 0, pkgSales = 0;
  for (const sl of s.sales) {
    if (!inR(sl.date) || !okClient(sl.clientId)) continue;
    const items = itemsF ? sl.items.filter((it) => itemMatch(I, it, f)) : sl.items; if (!items.length) continue;
    const g = items.reduce((t, i) => t + i.qty * i.unitPrice, 0), dc = items.reduce((t, i) => t + (i.discount || 0), 0);
    gross += g; discount += dc; salesCount++;
    if (sl.status !== 'valida') cancelled += g - dc;
    if (sl.type === 'pacote') pkgSales += g - dc;
  }
  // Recebimentos com atribuição proporcional aos itens filtrados.
  const share = (sl) => { if (!itemsF) return 1; const tot = I.saleTot.get(sl.id); if (!tot) return 0; const part = sl.items.filter((it) => itemMatch(I, it, f)).reduce((t, i) => t + i.qty * i.unitPrice - (i.discount || 0), 0); return part / tot; };
  let received = 0, reversals = 0; const byMethod = {};
  for (const p of s.payments) {
    if (!inR(p.date) || !okClient(p.clientId)) continue; if (f.method && p.method !== f.method) continue;
    const sl = I.saleById.get(p.saleId); if (!sl) continue; const k = share(sl); if (!k) continue;
    const v = Math.round(p.amount * k);
    if (p.kind === 'estorno') reversals += -v; else received += v;
    byMethod[p.method] = (byMethod[p.method] || 0) + v;
  }
  let receivable = 0;
  for (const sl of s.sales) {
    if (sl.status !== 'valida' || sl.date > r.to || !okClient(sl.clientId)) continue;
    const k = share(sl); if (!k) continue;
    receivable += Math.max(0, Math.round((I.saleTot.get(sl.id) - paidUntil(I, sl.id, r.to)) * k));
  }
  // Atendimentos
  let scheduled = 0, realized = 0, noShow = 0, cancel = 0, resched = 0, realizedMin = 0, ticketSum = 0, ticketN = 0, pkgSessions = 0, courtesy = 0;
  const attended = new Set(); const st = {};
  for (const a of s.appointments) {
    if (!inR(a.date) || !apptMatch(s, I, a, f) || !okClient(a.clientId)) continue;
    if (f.status && a.status !== f.status) continue;
    st[a.status] = (st[a.status] || 0) + 1;
    if (a.status !== 'reagendado') scheduled++; else resched++;
    if (a.status === 'realizado') {
      realized++; realizedMin += a.duration; attended.add(a.clientId);
      const ck2 = a.checkout;
      if (ck2?.settlement === 'pacote') pkgSessions++;
      else if (ck2?.saleId) { const sl = I.saleById.get(ck2.saleId); const v = sl && sl.status === 'valida' ? I.saleTot.get(sl.id) : 0; if (v > 0) { ticketSum += v; ticketN++; } else courtesy++; }
    }
    if (a.status === 'falta') noShow++; if (a.status === 'cancelado') cancel++;
  }
  // Clientes
  const cs = clientSegmentsInRange(s, r, f, okClient);
  // Despesas (filtro de profissional/serviço não se aplica)
  let expensesPaid = 0, expensesAccrual = 0, expensesOpen = 0;
  for (const e of s.expenses) { if (e.paid && e.paidDate && inR(e.paidDate)) expensesPaid += e.amount; if (inR(e.date)) expensesAccrual += e.amount; if (!e.paid && e.date <= r.to) expensesOpen += e.amount; }
  const available = availableMinutes(s, r, f);
  const net = gross - discount - cancelled - reversals;
  const receivedNet = received - reversals;
  const res = {
    gross, discount, cancelled, reversals, net, salesCount, pkgSales, received, receivedNet, receivable, byMethod,
    scheduled, realized, noShow, cancel, resched, statusCounts: st,
    attendance: realized + noShow ? (realized / (realized + noShow)) * 100 : null,
    ticket: ticketN ? Math.round(ticketSum / ticketN) : 0, ticketN, pkgSessions, courtesy,
    occupancy: available ? (realizedMin / available) * 100 : null, realizedMin, available,
    attended: attended.size, newClients: cs.newC, recurrent: cs.rec, reactivated: cs.react, inactive: cs.inactive, leads: cs.leads,
    expensesPaid, expensesAccrual, expensesOpen,
    cashResult: receivedNet - expensesPaid, accrualResult: net - expensesAccrual,
    notApplicable: { expenses: hasItemFilter(f) || !!f.clientType, occupancy: !!(f.serviceId || f.category || f.clientType) },
  };
  I.cache.set(ck, res); return res;
}

function clientSegmentsInRange(s, r, f, okClient) {
  const I = idx(s); const inact = s.org.crm.inactivityDays;
  let newC = 0, rec = 0, react = 0, inactive = 0, leads = 0;
  for (const c of s.clients) {
    if (c.mergedInto || !okClient(c.id)) continue;
    const list = (I.apptsByClient.get(c.id) || []).filter((a) => a.status === 'realizado' && apptMatch(s, I, a, f));
    const inP = list.filter((a) => a.date >= r.from && a.date <= r.to);
    const before = list.filter((a) => a.date < r.from);
    if (inP.length) {
      if (!before.length) newC++; else rec++;
      const prevVisit = before.at(-1); if (prevVisit && diffDays(inP[0].date, prevVisit.date) > inact) react++;
    }
    const upTo = list.filter((a) => a.date <= r.to);
    if (upTo.length && diffDays(r.to, upTo.at(-1).date) > inact) inactive++;
    if (!f.professionalId && !f.serviceId && !f.category && !list.length && c.createdAt.slice(0, 10) <= r.to) leads++;
  }
  return { newC, rec, react, inactive, leads };
}

export function availableMinutes(s, r, f = {}) {
  let total = 0;
  for (let d = r.from; d <= r.to; d = addDays(d, 1)) {
    for (const p of s.professionals) {
      if (f.professionalId && p.id !== f.professionalId) continue;
      if (!p.active || (p.since && d < p.since)) continue;
      const sch = p.schedule[dow(d)]; if (!sch) continue;
      let m = timeToMin(sch.end) - timeToMin(sch.start); if (sch.breakStart) m -= timeToMin(sch.breakEnd) - timeToMin(sch.breakStart);
      for (const b of blocksFor(s, p.id, d)) { const bs = b.start.slice(0, 10) < d ? timeToMin(sch.start) : Math.max(timeToMin(sch.start), timeToMin(b.start.slice(11, 16))); const be = b.end.slice(0, 10) > d ? timeToMin(sch.end) : Math.min(timeToMin(sch.end), timeToMin(b.end.slice(11, 16))); if (be > bs) m -= be - bs; }
      total += Math.max(0, m);
    }
  }
  return total;
}

// ---------- Séries ----------
export function bucketsFor(r, gran) {
  const out = [];
  if (gran === 'dia') for (let d = r.from; d <= r.to; d = addDays(d, 1)) out.push({ from: d, to: d, label: fmtDateShort(d) });
  else if (gran === 'semana') { for (let d = startOfWeek(r.from); d <= r.to; d = addDays(d, 7)) out.push({ from: d < r.from ? r.from : d, to: addDays(d, 6) > r.to ? r.to : addDays(d, 6), label: fmtDateShort(d < r.from ? r.from : d) }); }
  else for (let d = startOfMonth(r.from); d <= r.to; d = addMonths(d, 1)) out.push({ from: d < r.from ? r.from : d, to: endOfMonth(d) > r.to ? r.to : endOfMonth(d), label: fmtMonth(d) });
  return out;
}
export function autoGranularity(r) { const n = diffDays(r.to, r.from) + 1; return n <= 31 ? 'dia' : n <= 120 ? 'semana' : 'mes'; }
export function series(s, r, f, gran = autoGranularity(r)) {
  return bucketsFor(r, gran).map((b) => { const k = computeKPIs(s, b, f); return { ...b, net: k.net, received: k.receivedNet, expenses: k.expensesPaid, receivable: k.receivable, realized: k.realized, newClients: k.newClients, recurrent: k.recurrent, reactivated: k.reactivated, noShow: k.noShow, cancel: k.cancel, ticket: k.ticket }; });
}

export function topServices(s, r, f = {}) {
  const I = idx(s); const m = new Map();
  for (const sl of s.sales) {
    if (sl.status !== 'valida' || sl.date < r.from || sl.date > r.to) continue;
    for (const it of sl.items) { if (!it.serviceId || !itemMatch(I, it, { ...f, serviceId: f.serviceId })) continue; const e = m.get(it.serviceId) || { serviceId: it.serviceId, qty: 0, value: 0, pkgQty: 0 }; e.qty += it.qty; e.value += it.qty * it.unitPrice - (it.discount || 0); m.set(it.serviceId, e); }
  }
  for (const u of s.packageUsage) { if (u.date < r.from || u.date > r.to) continue; if (f.serviceId && u.serviceId !== f.serviceId) continue; const e = m.get(u.serviceId) || { serviceId: u.serviceId, qty: 0, value: 0, pkgQty: 0 }; e.pkgQty++; m.set(u.serviceId, e); }
  return [...m.values()].map((e) => ({ ...e, service: I.serviceById.get(e.serviceId) })).filter((e) => e.service && (!f.category || e.service.category === f.category));
}

export function professionalsPerf(s, r, f = {}) {
  return s.professionals.filter((p) => !f.professionalId || p.id === f.professionalId).map((p) => {
    const k = computeKPIs(s, r, { ...f, professionalId: p.id });
    return { professional: p, realized: k.realized, value: k.net, ticket: k.ticket, occupancy: k.occupancy, noShow: k.noShow, attended: k.attended, attendance: k.attendance };
  });
}

// Mapa de procura: agendamentos (exceto reagendados) por dia da semana × hora
export function demandHeatmap(s, r, f = {}) {
  const I = idx(s); const grid = {}; let max = 0;
  for (const a of s.appointments) {
    if (a.date < r.from || a.date > r.to || a.status === 'reagendado' || !apptMatch(s, I, a, f)) continue;
    const k = dow(a.date) + '|' + a.start.slice(0, 2); grid[k] = (grid[k] || 0) + 1; if (grid[k] > max) max = grid[k];
  }
  return { grid, max };
}

// Retenção por coorte: mês da primeira visita × voltou em 30/60/90 dias
export function cohorts(s, refDate, months = 6) {
  const I = idx(s); const rows = [];
  for (let i = months; i >= 1; i--) {
    const m0 = addMonths(startOfMonth(refDate), -i); const m1 = endOfMonth(m0);
    let size = 0; const back = { 30: 0, 60: 0, 90: 0 }; const eligible = { 30: 0, 60: 0, 90: 0 };
    for (const [, list] of I.apptsByClient) {
      const vis = list.filter((a) => a.status === 'realizado'); if (!vis.length) continue;
      const first = vis[0].date; if (first < m0 || first > m1) continue; size++;
      for (const w of [30, 60, 90]) { if (addDays(first, w) > refDate) continue; eligible[w]++; if (vis.some((a) => a.date > first && diffDays(a.date, first) <= w)) back[w]++; }
    }
    rows.push({ month: m0, label: fmtMonth(m0), size, r30: eligible[30] ? (back[30] / eligible[30]) * 100 : null, r60: eligible[60] ? (back[60] / eligible[60]) * 100 : null, r90: eligible[90] ? (back[90] / eligible[90]) * 100 : null });
  }
  return rows;
}

// Comissões: % do serviço sobre o valor realizado (vendas de atendimentos realizados por profissional)
export function commissions(s, r) {
  const I = idx(s); const out = new Map();
  for (const sl of s.sales) {
    if (sl.status !== 'valida' || sl.date < r.from || sl.date > r.to || !sl.appointmentId) continue;
    for (const it of sl.items) { if (!it.professionalId || !it.serviceId) continue; const sv = I.serviceById.get(it.serviceId); const base = it.qty * it.unitPrice - (it.discount || 0); const e = out.get(it.professionalId) || { base: 0, value: 0, count: 0 }; e.base += base; e.value += Math.round(base * (sv?.commissionPct || 0) / 100); e.count++; out.set(it.professionalId, e); }
  }
  for (const u of s.packageUsage) { if (u.date < r.from || u.date > r.to) continue; const a = s.appointments.find((x) => x.id === u.appointmentId); if (!a) continue; const sv = I.serviceById.get(u.serviceId); const e = out.get(a.professionalId) || { base: 0, value: 0, count: 0 }; e.base += sv.price; e.value += Math.round(sv.price * sv.commissionPct / 100); e.count++; out.set(a.professionalId, e); }
  return out;
}

// ---------- Insights determinísticos (sem inventar causas) ----------
export function insights(s, cur, prev, r, pr, f) {
  const out = []; const fmt = (v) => v.toLocaleString('pt-BR', { maximumFractionDigits: 0 });
  const v = (a, b) => (b ? ((a - b) / b) * 100 : null);
  const va = v(cur.realized, prev.realized);
  if (va != null && Math.abs(va) >= 10) out.push({ tone: va > 0 ? 'good' : 'warn', text: `Atendimentos realizados ${va > 0 ? 'subiram' : 'caíram'} ${fmt(Math.abs(va))}% (${cur.realized} contra ${prev.realized}) em relação a ${pr.label}.` });
  if (cur.attendance != null && prev.attendance != null && Math.abs(cur.attendance - prev.attendance) >= 3) out.push({ tone: cur.attendance > prev.attendance ? 'good' : 'warn', text: `Taxa de comparecimento ${cur.attendance > prev.attendance ? 'subiu' : 'caiu'} ${fmt(Math.abs(cur.attendance - prev.attendance))} p.p. (${fmt(cur.attendance)}% contra ${fmt(prev.attendance)}%).` });
  const top = topServices(s, r, f).sort((a, b) => b.qty + b.pkgQty - (a.qty + a.pkgQty));
  const totalQ = top.reduce((t, x) => t + x.qty + x.pkgQty, 0);
  if (top[0] && totalQ) { const sh = ((top[0].qty + top[0].pkgQty) / totalQ) * 100; if (sh >= 20) out.push({ tone: 'info', text: `${top[0].service.name} respondeu por ${fmt(sh)}% dos serviços realizados no período.` }); }
  if (cur.receivable > 0) out.push({ tone: 'warn', text: `Há ${moneyStr(cur.receivable)} a receber de vendas já registradas.` });
  const inact = s.org.crm.inactivityDays;
  if (cur.inactive) out.push({ tone: 'info', text: `${cur.inactive} clientes estão sem retorno há mais de ${inact} dias.` });
  if (cur.newClients && prev.newClients != null) { const vn = v(cur.newClients, prev.newClients); if (vn != null && Math.abs(vn) >= 15) out.push({ tone: vn > 0 ? 'good' : 'warn', text: `Clientes novas: ${cur.newClients} contra ${prev.newClients} (${vn > 0 ? '+' : ''}${fmt(vn)}%).` }); }
  return out.slice(0, 5);
}
const moneyStr = (c) => (c / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

// Agregado diário rápido (uma passada) para gráficos acumulados.
export function dailyTotals(s, r, f = {}) {
  const I = idx(s); const cset = clientTypeSet(s, r, f.clientType); const ok = (id) => !cset || cset.has(id);
  const net = {}, realized = {};
  for (const sl of s.sales) {
    if (sl.date < r.from || sl.date > r.to || sl.status !== 'valida' || !ok(sl.clientId)) continue;
    const items = hasItemFilter(f) ? sl.items.filter((it) => itemMatch(I, it, f)) : sl.items;
    net[sl.date] = (net[sl.date] || 0) + items.reduce((t, i) => t + i.qty * i.unitPrice - (i.discount || 0), 0);
  }
  for (const p of s.payments) if (p.kind === 'estorno' && p.date >= r.from && p.date <= r.to && ok(p.clientId)) { const sl = I.saleById.get(p.saleId); if (!sl) continue; const tot = I.saleTot.get(sl.id) || 1; const part = hasItemFilter(f) ? sl.items.filter((it) => itemMatch(I, it, f)).reduce((t, i) => t + i.qty * i.unitPrice - (i.discount || 0), 0) / tot : 1; net[p.date] = (net[p.date] || 0) + Math.round(p.amount * part); }
  for (const a of s.appointments) if (a.status === 'realizado' && a.date >= r.from && a.date <= r.to && apptMatch(s, I, a, f) && ok(a.clientId)) realized[a.date] = (realized[a.date] || 0) + 1;
  return { net, realized };
}
