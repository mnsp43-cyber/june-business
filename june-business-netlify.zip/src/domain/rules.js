// Regras de domínio centralizadas: estados, transições, papéis e permissões.

export const STATUS = {
  agendado: { label: 'Agendado', tone: 'neutral', final: false },
  confirmado: { label: 'Confirmado', tone: 'info', final: false },
  chegou: { label: 'Cliente chegou', tone: 'info', final: false },
  em_atendimento: { label: 'Em atendimento', tone: 'accent', final: false },
  realizado: { label: 'Realizado', tone: 'good', final: true },
  falta: { label: 'Falta', tone: 'bad', final: true },
  cancelado: { label: 'Cancelado', tone: 'muted', final: true },
  reagendado: { label: 'Reagendado', tone: 'muted', final: true },
};

// 'realizado' só é alcançado pela Finalização Expressa.
export const TRANSITIONS = {
  agendado: ['confirmado', 'chegou', 'cancelado', 'reagendado', 'falta', 'realizado'],
  confirmado: ['chegou', 'em_atendimento', 'cancelado', 'reagendado', 'falta', 'realizado'],
  chegou: ['em_atendimento', 'realizado', 'cancelado'],
  em_atendimento: ['realizado'],
  realizado: [], falta: [], cancelado: [], reagendado: [],
};
export function canTransition(from, to) { return (TRANSITIONS[from] || []).includes(to); }
export const ACTIVE_STATUSES = ['agendado', 'confirmado', 'chegou', 'em_atendimento'];

export const SETTLEMENT = {
  pago: 'Pago integralmente',
  parcial: 'Pagamento parcial',
  pendente: 'Pendente',
  pacote: 'Sessão de pacote pré-pago',
  cortesia: 'Cortesia autorizada',
};

export const PAYMENT_METHODS = [
  { id: 'pix', label: 'Pix' },
  { id: 'dinheiro', label: 'Dinheiro' },
  { id: 'debito', label: 'Cartão de débito' },
  { id: 'credito', label: 'Cartão de crédito' },
];

export const ORIGINS = ['Instagram', 'Indicação', 'Google', 'WhatsApp', 'Passou na frente', 'Agendamento', 'Outro'];

export const ROLES = {
  proprietaria: 'Proprietária',
  recepcionista: 'Recepcionista',
  profissional: 'Profissional',
  gestora: 'Gestora',
  admin_june: 'Administrador June',
};

// Matriz de permissões (no protótipo: aplicada na interface e nos serviços locais;
// no MVP: aplicada no servidor e no banco via RLS).
export const PERMISSIONS = [
  { key: 'agenda.ver_todas', label: 'Ver agenda de toda a equipe' },
  { key: 'agenda.editar', label: 'Criar e alterar agendamentos' },
  { key: 'atendimento.finalizar', label: 'Finalizar atendimentos' },
  { key: 'clientes.editar', label: 'Cadastrar e editar clientes' },
  { key: 'clientes.mesclar', label: 'Mesclar cadastros duplicados' },
  { key: 'pagamentos.registrar', label: 'Registrar pagamentos' },
  { key: 'financeiro.ver', label: 'Ver financeiro e resultado' },
  { key: 'despesas.editar', label: 'Lançar despesas' },
  { key: 'estornos.autorizar', label: 'Autorizar estornos e cortesias' },
  { key: 'dashboard.ver', label: 'Ver dashboard da empresa' },
  { key: 'servicos.editar', label: 'Editar serviços, preços e pacotes' },
  { key: 'crm.ver', label: 'Ver CRM e segmentos' },
  { key: 'campanhas.criar', label: 'Criar campanhas' },
  { key: 'campanhas.aprovar', label: 'Aprovar campanhas' },
  { key: 'equipe.gerir', label: 'Gerenciar equipe e permissões' },
  { key: 'config.editar', label: 'Configurar o estabelecimento' },
  { key: 'plataforma.suporte', label: 'Suporte e assinaturas da plataforma' },
];

export const ROLE_PERMS = {
  proprietaria: PERMISSIONS.map((p) => p.key).filter((k) => k !== 'plataforma.suporte'),
  recepcionista: ['agenda.ver_todas', 'agenda.editar', 'atendimento.finalizar', 'clientes.editar', 'pagamentos.registrar', 'crm.ver'],
  profissional: ['agenda.editar', 'atendimento.finalizar', 'clientes.editar'],
  gestora: ['agenda.ver_todas', 'agenda.editar', 'atendimento.finalizar', 'clientes.editar', 'pagamentos.registrar', 'financeiro.ver', 'despesas.editar', 'dashboard.ver', 'crm.ver', 'campanhas.criar', 'campanhas.aprovar'],
  admin_june: ['plataforma.suporte'],
};

export const MODULES = [
  { id: 'meu-dia', label: 'Meu Dia', icon: 'sun', perm: null },
  { id: 'dashboard', label: 'Dashboard', mobileLabel: 'Dados', icon: 'chart', perm: 'dashboard.ver' },
  { id: 'agenda', label: 'Agenda', icon: 'calendar', perm: null },
  { id: 'clientes', label: 'Clientes', icon: 'users', perm: null },
  { id: 'servicos', label: 'Serviços e Pacotes', icon: 'tag', perm: null },
  { id: 'financeiro', label: 'Financeiro', mobileLabel: 'Finanças', icon: 'wallet', perm: 'pagamentos.registrar' },
  { id: 'crm', label: 'CRM e Campanhas', icon: 'megaphone', perm: 'crm.ver' },
  { id: 'relatorios', label: 'Relatórios', icon: 'file', perm: 'dashboard.ver' },
  { id: 'config', label: 'Configurações', icon: 'gear', perm: null },
];

export const CHANNELS = { whatsapp: 'WhatsApp', email: 'E-mail', sms: 'SMS' };
export const PURPOSES = { operacional: 'Operacional', promocional: 'Promocional' };

export const CAMPAIGN_STATUS = {
  rascunho: 'Rascunho', aguardando: 'Aguardando aprovação', agendada: 'Agendada',
  processando: 'Em processamento', concluida: 'Concluída', cancelada: 'Cancelada', falha: 'Falha',
};
export const MSG_STATUS = {
  fila: 'Na fila', enviada: 'Enviada (simulada)', entregue: 'Entregue (simulada)', lida: 'Lida (simulada)',
  falhou: 'Falhou (simulada)', bloqueada: 'Bloqueada por consentimento', cancelada: 'Cancelada',
};
