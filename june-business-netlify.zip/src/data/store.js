// Repositório único de dados. Todos os módulos leem e gravam por aqui.
// Protótipo: persistência local no navegador (localStorage) com transação simulada
// (tudo ou nada). MVP: substituir por repositório Supabase/PostgreSQL com transações reais.
import { buildSeed, DEFAULT_REF_DATE } from './seed.js';

const KEY = 'june-business:v3';
const hasLS = (() => { try { return typeof localStorage !== 'undefined' && localStorage !== null; } catch { return false; } })();

let state = null;
let version = 0;
const listeners = new Set();
let lastSaveError = null;

export function getState() { return state; }
export function getVersion() { return version; }
export function lastError() { return lastSaveError; }
export function subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); }

export function load({ fresh = false, refDate } = {}) {
  if (!fresh && hasLS) {
    try { const raw = localStorage.getItem(KEY); if (raw) { state = JSON.parse(raw); version++; return { restored: true }; } } catch (e) { console.warn('Base local ilegível, recriando.', e); }
  }
  state = buildSeed(refDate || DEFAULT_REF_DATE);
  version++; save();
  return { restored: false };
}

export function save() {
  if (!hasLS) return true;
  try { localStorage.setItem(KEY, JSON.stringify(state)); lastSaveError = null; return true; }
  catch (e) { lastSaveError = 'Não foi possível salvar no navegador (armazenamento cheio ou bloqueado). As alterações valem até fechar a página.'; return false; }
}

export function resetDemo() { const s = state?.settings?.session; load({ fresh: true }); if (s) state.settings.session = s; save(); emit(); }

// Transação: executa fn sobre um rascunho. Se fn lançar erro, nada é gravado.
const handlers = [];
export function onEvent(fn) { handlers.push(fn); }

export function transaction(fn) {
  const draft = structuredClone(state);
  const pending = [];
  const ctx = {
    publish(type, payload) { const ev = { id: `evt_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`, type, at: nowStamp(draft), payload }; pending.push(ev); },
    audit(action, entity, entityId, detail) { draft.audit.unshift({ id: `aud_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`, at: nowStamp(draft), userId: draft.settings.session?.userId || null, action, entity, entityId, detail }); if (draft.audit.length > 800) draft.audit.length = 800; },
  };
  const result = fn(draft, ctx);
  // Outbox: eventos gravados na mesma transação; consumidores rodam aqui (síncronos, idempotentes).
  let guard = 0;
  while (pending.length && guard++ < 200) {
    const ev = pending.shift();
    draft.events.unshift(ev); if (draft.events.length > 600) draft.events.length = 600;
    for (const h of handlers) h(draft, ev, ctx);
  }
  state = draft; version++;
  save(); emit();
  return result;
}

export function setSilently(mutator) { mutator(state); version++; save(); emit(); }

function emit() { for (const l of listeners) { try { l(state); } catch (e) { console.error(e); } } }

export function nowStamp(s = state) { return `${s.settings.refDate}T${s.settings.demoTime}`; }
export function today(s = state) { return s.settings.refDate; }

// Para testes: injeta um estado sem tocar no armazenamento
export function __setState(s) { state = s; version++; }
