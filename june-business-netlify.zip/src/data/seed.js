// Base fictícia do June Studio: 12+ meses de histórico coerente, gerado de forma
// determinística (mesma semente = mesmos dados). Indicadores são CALCULADOS
// a partir destes registros pelo motor de métricas — nada é sorteado à parte.
import { rng, addDays, dow, timeToMin, minToTime, uid, diffDays, normalizePhone } from '../util.js';

export const DEFAULT_REF_DATE = '2026-11-18';

const FIRST = ['Ana', 'Beatriz', 'Carolina', 'Daniela', 'Eduarda', 'Fernanda', 'Gabriela', 'Heloísa', 'Isabela', 'Joana', 'Karina', 'Letícia', 'Mariana', 'Natália', 'Olívia', 'Patrícia', 'Rafaela', 'Sabrina', 'Tatiane', 'Valéria', 'Yasmin', 'Aline', 'Bianca', 'Camila', 'Débora', 'Elisa', 'Flávia', 'Giovana', 'Hellen', 'Ingrid', 'Jéssica', 'Larissa', 'Melissa', 'Nicole', 'Priscila', 'Renata', 'Simone', 'Thaís', 'Vanessa', 'Vitória', 'Alice', 'Bruna', 'Cecília', 'Lívia', 'Manuela', 'Luiza', 'Clara', 'Lorena', 'Marina', 'Paula', 'Raquel', 'Sílvia', 'Tânia', 'Úrsula', 'Vera', 'Bárbara', 'Cíntia', 'Denise', 'Érica', 'Fabiana', 'Gisele', 'Jaqueline', 'Kelly', 'Luana', 'Mônica', 'Nathalia', 'Pâmela', 'Roberta', 'Sandra', 'Tamires', 'Vivian', 'Lúcia', 'Rebeca', 'Sophia', 'Laura', 'Antônia', 'Miriam', 'Estela', 'Carla', 'Juliane', 'Lucas', 'Rafael', 'Thiago', 'Pedro'];
const LAST = ['Silva', 'Santos', 'Oliveira', 'Souza', 'Rodrigues', 'Ferreira', 'Alves', 'Pereira', 'Lima', 'Gomes', 'Costa', 'Ribeiro', 'Martins', 'Carvalho', 'Almeida', 'Lopes', 'Soares', 'Fernandes', 'Vieira', 'Barbosa', 'Rocha', 'Dias', 'Nascimento', 'Andrade', 'Moreira', 'Nunes', 'Marques', 'Machado', 'Mendes', 'Freitas', 'Cardoso', 'Ramos', 'Gonçalves', 'Santana', 'Teixeira', 'Prado', 'Campos', 'Moura', 'Pinto', 'Araújo'];

export function buildSeed(refDate = DEFAULT_REF_DATE, seed = 20261118) {
  const R = rng(seed);
  const pick = (arr) => arr[Math.floor(R() * arr.length)];
  const chance = (p) => R() < p;
  const between = (a, b) => a + Math.floor(R() * (b - a + 1));
  const START = addDays(refDate, -365);
  const HIST_START = addDays(START, -150);
  let seq = 0;
  const id = (p) => `${p}_${(++seq).toString(36).padStart(5, '0')}`;

  const org = {
    id: 'org_june_studio', name: 'June Studio', legalName: 'June Studio Estética Ltda. (fictício)', document: '00.000.000/0001-00',
    phone: '+5511930000000', email: 'contato@junestudio.demo', address: 'Rua Fictícia, 123 — Pinheiros, São Paulo/SP',
    timezone: 'America/Sao_Paulo', currency: 'BRL', segment: 'Estética e beleza',
    hours: { 0: null, 1: { open: '09:00', close: '19:00' }, 2: { open: '09:00', close: '19:00' }, 3: { open: '09:00', close: '19:00' }, 4: { open: '09:00', close: '19:00' }, 5: { open: '09:00', close: '19:00' }, 6: { open: '09:00', close: '17:00' } },
    categories: ['Sobrancelhas', 'Cílios', 'Unhas', 'Estética facial', 'Bem-estar', 'Depilação'],
    paymentMethods: ['pix', 'dinheiro', 'debito', 'credito'],
    cancellationPolicy: { enabled: false, minHours: 24, feePct: 30 },
    crm: { inactivityDays: 90, recentFirstVisitDays: 30, highValueTopPct: 20, noShowMin: 2, packageAlertSessions: 1, packageAlertDays: 15, reactivatedWindowDays: 30, attributionDays: 7 },
    comm: { senderName: 'June Studio', quietHoursStart: '20:00', quietHoursEnd: '09:00', defaultChannel: 'whatsapp' },
    slotStep: 15,
  };

  const professionals = [
    { id: 'pro_juliana', name: 'Juliana Alves', color: '#247B82', active: true, since: HIST_START, schedule: { 1: ['09:00', '18:00', '12:00', '13:00'], 2: ['09:00', '18:00', '12:00', '13:00'], 3: ['09:00', '18:00', '12:00', '13:00'], 4: ['09:00', '18:00', '12:00', '13:00'], 5: ['09:00', '18:00', '12:00', '13:00'] } },
    { id: 'pro_bruna', name: 'Bruna Lima', color: '#6A5ACD', active: true, since: HIST_START, schedule: { 2: ['09:00', '19:00', '13:00', '14:00'], 3: ['09:00', '19:00', '13:00', '14:00'], 4: ['09:00', '19:00', '13:00', '14:00'], 5: ['09:00', '19:00', '13:00', '14:00'], 6: ['09:00', '17:00', '12:00', '12:30'] } },
    { id: 'pro_camila', name: 'Camila Rocha', color: '#C2410C', active: true, since: HIST_START, schedule: { 2: ['09:00', '19:00', '12:00', '13:00'], 3: ['09:00', '19:00', '12:00', '13:00'], 4: ['09:00', '19:00', '12:00', '13:00'], 5: ['09:00', '19:00', '12:00', '13:00'], 6: ['09:00', '17:00', '12:00', '12:30'] } },
    { id: 'pro_larissa', name: 'Larissa Mendes', color: '#B45309', active: true, since: addDays(refDate, -260), schedule: { 1: ['10:00', '19:00', '14:00', '15:00'], 3: ['10:00', '19:00', '14:00', '15:00'], 4: ['10:00', '19:00', '14:00', '15:00'], 5: ['10:00', '19:00', '14:00', '15:00'], 6: ['09:00', '17:00', '12:00', '12:30'] } },
  ];
  // Converte agenda para objeto legível
  for (const p of professionals) {
    const s = {}; for (const [d, v] of Object.entries(p.schedule)) s[d] = { start: v[0], end: v[1], breakStart: v[2], breakEnd: v[3] }; p.schedule = s;
  }

  const resources = [{ id: 'res_sala', name: 'Sala de estética facial', type: 'Sala' }, { id: 'res_maca', name: 'Maca de cílios', type: 'Equipamento' }];

  const S = (key, name, category, price, duration, pros, commissionPct, extra = {}) => ({ id: 'srv_' + key, name, category, description: extra.description || '', price: price * 100, duration, professionalIds: pros, commissionPct, active: true, resourceId: extra.resourceId || null, createdAt: HIST_START });
  const J = 'pro_juliana', B = 'pro_bruna', C = 'pro_camila', L = 'pro_larissa';
  const services = [
    S('design', 'Design de sobrancelhas', 'Sobrancelhas', 70, 45, [J, B], 40, { description: 'Desenho e modelagem com pinça e linha.' }),
    S('henna', 'Design com henna', 'Sobrancelhas', 90, 60, [J, B], 40, { description: 'Design com aplicação de henna para preenchimento.' }),
    S('brow', 'Brow lamination', 'Sobrancelhas', 150, 60, [J], 40, { description: 'Alinhamento dos fios com efeito penteado.' }),
    S('cilios', 'Extensão de cílios fio a fio', 'Cílios', 220, 120, [J, L], 40, { resourceId: 'res_maca', description: 'Aplicação fio a fio, efeito natural.' }),
    S('manut', 'Manutenção de cílios', 'Cílios', 130, 75, [J, L], 40, { resourceId: 'res_maca', description: 'Reposição de fios entre 15 e 25 dias.' }),
    S('lash', 'Lash lifting', 'Cílios', 150, 60, [J, L], 40, { description: 'Curvatura dos cílios naturais.' }),
    S('manicure', 'Manicure', 'Unhas', 45, 45, [C], 50, { description: 'Cutilagem e esmaltação tradicional.' }),
    S('pedicure', 'Pedicure', 'Unhas', 50, 50, [C], 50),
    S('gel', 'Esmaltação em gel', 'Unhas', 80, 60, [C], 50),
    S('fibra', 'Alongamento em fibra', 'Unhas', 200, 120, [C], 45),
    S('limpeza', 'Limpeza de pele', 'Estética facial', 160, 75, [B, L], 40, { resourceId: 'res_sala', description: 'Higienização, extração e máscara calmante.' }),
    S('revital', 'Revitalização facial', 'Estética facial', 180, 60, [B, L], 40, { resourceId: 'res_sala' }),
    S('massagem', 'Massagem relaxante', 'Bem-estar', 150, 60, [B, L], 40, { resourceId: 'res_sala' }),
    S('buco', 'Depilação de buço', 'Depilação', 25, 15, [J, B], 40),
  ];
  const srv = Object.fromEntries(services.map((s) => [s.id.replace('srv_', ''), s]));

  const packages = [
    { id: 'pkg_limpeza4', name: 'Limpeza de pele — 4 sessões', items: [{ serviceId: 'srv_limpeza', sessions: 4 }], price: 56000, validityDays: 180, active: true, rules: 'Uma sessão por atendimento. Intransferível.' },
    { id: 'pkg_maospes', name: 'Mãos e pés — 4 de cada', items: [{ serviceId: 'srv_manicure', sessions: 4 }, { serviceId: 'srv_pedicure', sessions: 4 }], price: 34000, validityDays: 60, active: true, rules: 'Válido por 60 dias a partir da compra.' },
    { id: 'pkg_sobr5', name: 'Sobrancelhas — 5 designs', items: [{ serviceId: 'srv_design', sessions: 5 }], price: 30000, validityDays: 150, active: true, rules: 'Pode ser usado com qualquer profissional habilitada.' },
    { id: 'pkg_manut3', name: 'Manutenção de cílios — 3 sessões', items: [{ serviceId: 'srv_manut', sessions: 3 }], price: 35000, validityDays: 90, active: true, rules: 'Exige extensão prévia.' },
  ];

  const users = [
    { id: 'usr_juliana', name: 'Juliana Alves', email: 'admin@junebusiness.com', role: 'proprietaria', professionalId: J, active: true, phone: '+5511930000001' },
    { id: 'usr_paula', name: 'Paula Nogueira', email: 'recepcao@junebusiness.com', role: 'recepcionista', professionalId: null, active: true, phone: '+5511930000002' },
    { id: 'usr_bruna', name: 'Bruna Lima', email: 'bruna@junebusiness.com', role: 'profissional', professionalId: B, active: true, phone: '+5511930000003' },
    { id: 'usr_camila', name: 'Camila Rocha', email: 'camila@junebusiness.com', role: 'profissional', professionalId: C, active: true, phone: '+5511930000004' },
    { id: 'usr_larissa', name: 'Larissa Mendes', email: 'larissa@junebusiness.com', role: 'profissional', professionalId: L, active: true, phone: '+5511930000005' },
    { id: 'usr_renata', name: 'Renata Duarte', email: 'gestao@junebusiness.com', role: 'gestora', professionalId: null, active: true, phone: '+5511930000006' },
    { id: 'usr_suporte', name: 'Suporte June', email: 'suporte@june.com.br', role: 'admin_june', professionalId: null, active: true, phone: '' },
  ];

  // ---------- Ocupação para evitar conflitos ----------
  const occ = new Map();
  const busy = (key, s, e) => (occ.get(key) || []).some(([a, b]) => s < b && e > a);
  const mark = (key, s, e) => { if (!occ.has(key)) occ.set(key, []); occ.get(key).push([s, e]); };
  function allocate(proId, date, duration, prefMin, resourceId) {
    const pro = professionals.find((p) => p.id === proId); const sch = pro.schedule[dow(date)];
    if (!sch || date < pro.since) return null;
    const st = timeToMin(sch.start), en = timeToMin(sch.end), bs = timeToMin(sch.breakStart), be = timeToMin(sch.breakEnd);
    const cands = []; for (let m = st; m + duration <= en; m += 15) if (!(m < be && m + duration > bs)) cands.push(m);
    cands.sort((a, b) => Math.abs(a - prefMin) - Math.abs(b - prefMin));
    for (const m of cands) {
      if (busy(proId + date, m, m + duration)) continue;
      if (resourceId && busy(resourceId + date, m, m + duration)) continue;
      mark(proId + date, m, m + duration); if (resourceId) mark(resourceId + date, m, m + duration);
      return minToTime(m);
    }
    return null;
  }

  // ---------- Clientes ----------
  const clients = []; const consentHistory = [];
  const usedNames = new Set();
  const profiles = [
    { main: 'design', alt: ['henna', 'buco', 'brow'], freq: [21, 32] },
    { main: 'manicure', alt: ['pedicure', 'gel'], freq: [10, 18] },
    { main: 'gel', alt: ['manicure', 'pedicure', 'fibra'], freq: [18, 26] },
    { main: 'manut', alt: ['cilios', 'lash'], freq: [17, 25], first: 'cilios' },
    { main: 'limpeza', alt: ['revital', 'massagem'], freq: [30, 45] },
    { main: 'massagem', alt: ['limpeza'], freq: [28, 55] },
    { main: 'henna', alt: ['design', 'lash'], freq: [24, 35] },
    { main: 'lash', alt: ['design', 'henna'], freq: [40, 60] },
  ];
  const N = 240;
  const origins = ['Instagram', 'Instagram', 'Indicação', 'Indicação', 'Google', 'WhatsApp', 'Passou na frente'];
  for (let i = 0; i < N; i++) {
    let name; do { name = `${pick(FIRST.slice(0, 80))} ${pick(LAST)}`; } while (usedNames.has(name)); usedNames.add(name);
    const phone = `+55119${String(60000000 + Math.floor(R() * 39999999)).padStart(8, '0')}`;
    const hasEmail = chance(0.55);
    const email = hasEmail ? `${name.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, '.')}@exemplo.com` : '';
    const birth = chance(0.65) ? `${between(1968, 2004)}-${String(between(1, 12)).padStart(2, '0')}-${String(between(1, 28)).padStart(2, '0')}` : '';
    const profile = pick(profiles);
    const preExisting = i < N * 0.32;
    const acq = preExisting ? addDays(HIST_START, between(0, 150)) : addDays(START, Math.floor(Math.pow(R(), 0.8) * 360));
    const c = {
      id: id('cli'), name, phone, email, birth, createdAt: acq + 'T10:00', origin: pick(origins), notes: '', preferences: '', status: 'ativo', mergedInto: null,
      consents: {
        whatsapp: { operacional: chance(0.97), promocional: chance(0.72) },
        email: { operacional: hasEmail, promocional: hasEmail && chance(0.45) },
        sms: { operacional: false, promocional: false },
      },
      _p: { profile, acq, freq: profile.freq, churn: R(), flaky: chance(0.08), hour: pick([540, 600, 660, 840, 900, 960, 1020]) },
    };
    for (const ch of ['whatsapp', 'email']) for (const pu of ['operacional', 'promocional']) if (c.consents[ch][pu]) consentHistory.push({ id: id('cns'), clientId: c.id, channel: ch, purpose: pu, value: true, at: acq + 'T10:00', origin: 'Cadastro no balcão', by: 'usr_paula' });
    clients.push(c);
  }
  // Telefone compartilhado (mãe e filha) e cadastro duplicado (mesma pessoa)
  const sharedPhone = '+5511987654321';
  clients[10].name = 'Helena Prado'; clients[10].phone = sharedPhone;
  clients[11].name = 'Sofia Prado'; clients[11].phone = sharedPhone; clients[11].notes = 'Filha da Helena — mesmo WhatsApp.';
  clients[20].name = 'Fernanda Souza'; clients[20].phone = '+5511976543210';
  const dup = { ...clients[20], id: id('cli'), name: 'Fernanda de Souza', email: '', birth: '', createdAt: addDays(refDate, -40) + 'T15:00', origin: 'Agendamento', consents: JSON.parse(JSON.stringify(clients[20].consents)), _p: { ...clients[20]._p, acq: addDays(refDate, -40), churn: 0.9, oneShot: true } };
  clients.push(dup);
  // Revogações (descadastro) para demonstrar histórico
  for (const k of [5, 33, 67, 101]) {
    const c = clients[k]; if (!c.consents.whatsapp.promocional) { c.consents.whatsapp.promocional = true; consentHistory.push({ id: id('cns'), clientId: c.id, channel: 'whatsapp', purpose: 'promocional', value: true, at: c._p.acq + 'T10:00', origin: 'Cadastro no balcão', by: 'usr_paula' }); }
    c.consents.whatsapp.promocional = false;
    consentHistory.push({ id: id('cns'), clientId: c.id, channel: 'whatsapp', purpose: 'promocional', value: false, at: addDays(refDate, -between(10, 90)) + 'T19:20', origin: 'Descadastro solicitado pela cliente', by: 'usr_paula' });
  }
  // Aniversariantes no mês de referência
  for (const k of [3, 14, 27, 45, 88]) clients[k].birth = `19${between(80, 99)}-${refDate.slice(5, 7)}-${String(between(1, 28)).padStart(2, '0')}`;
  // Leads (cadastradas, sem visita)
  for (let k = 0; k < 9; k++) clients[N - 1 - k]._p.lead = true;

  // ---------- Simulação de visitas ----------
  const appointments = []; const sales = []; const payments = []; const clientPackages = []; const packageUsage = [];
  const proFor = (s) => pick(s.professionalIds);
  const methodPick = () => { const r = R(); return r < 0.46 ? 'pix' : r < 0.71 ? 'credito' : r < 0.86 ? 'debito' : 'dinheiro'; };
  const seasonSkip = (date) => { const m = Number(date.slice(5, 7)); return m === 1 || m === 2 ? 0.28 : m === 12 ? 0 : m === 7 ? 0.12 : 0.05; };
  const staff = ['usr_paula', 'usr_paula', 'usr_juliana'];

  function makeSale({ date, clientId, appointmentId, type, items, by }) {
    const s = { id: id('sale'), date, clientId, appointmentId: appointmentId || null, type, items, status: 'valida', createdAt: date + 'T' + minToTime(between(600, 1140)), createdBy: by, note: '' };
    sales.push(s); return s;
  }
  function pay(sale, amount, date, method, by) {
    if (amount <= 0) return; payments.push({ id: id('pay'), saleId: sale.id, clientId: sale.clientId, amount, method, date, kind: 'recebimento', createdAt: date + 'T' + minToTime(between(600, 1140)), createdBy: by, idempotencyKey: 'seed-' + seq });
  }
  const saleTotal = (s) => s.items.reduce((t, i) => t + i.qty * i.unitPrice - (i.discount || 0), 0);

  for (const c of clients) {
    const p = c._p; if (p.lead) continue;
    let date = p.acq; let visits = 0;
    const maxVisits = p.oneShot ? 1 : p.churn < 0.28 ? between(1, 2) : p.churn < 0.48 ? between(3, 9) : 999;
    let myPkg = null; let firstDone = false;
    while (date < addDays(refDate, 16) && visits < maxVisits) {
      if (date >= refDate && date <= refDate) { date = addDays(date, 1); continue; } // hoje é montado à mão
      const isFuture = date > refDate;
      if (!isFuture && chance(seasonSkip(date))) { date = addDays(date, between(5, 12)); continue; }
      let key = p.profile.main;
      if (!firstDone && p.profile.first) key = p.profile.first; else if (chance(0.25)) key = pick(p.profile.alt);
      const s = srv[key];
      // tenta alocar em até 4 dias seguintes
      let placed = null; let pro; let d2 = date;
      for (let t = 0; t < 4 && !placed; t++) { pro = proFor(s); placed = allocate(pro, d2, s.duration, p.hour + between(-60, 60), s.resourceId); if (!placed) d2 = addDays(d2, 1); }
      if (!placed) { date = addDays(date, 3); continue; }
      date = d2;
      if (date === refDate) { date = addDays(date, 1); continue; }
      if (date > refDate && date > addDays(refDate, 14)) break;
      const createdDaysBefore = between(1, 12);
      const a = { id: id('apt'), clientId: c.id, serviceId: s.id, professionalId: pro, date, start: placed, duration: s.duration, price: s.price, status: 'agendado', origin: visits === 0 ? c.origin : 'Recorrente', notes: '', clientPackageId: null, resourceId: s.resourceId, rescheduledFrom: null, rescheduledTo: null, createdAt: addDays(date, -createdDaysBefore) + 'T' + minToTime(between(540, 1200)), createdBy: pick(staff), history: [], checkout: null };
      a.history.push({ from: null, to: 'agendado', at: a.createdAt, by: a.createdBy });
      appointments.push(a);
      if (date > refDate) {
        if (diffDays(date, refDate) <= 2 && chance(0.6)) { a.status = 'confirmado'; a.history.push({ from: 'agendado', to: 'confirmado', at: addDays(refDate, -1) + 'T18:00', by: 'usr_paula' }); }
        if (myPkg && myPkg.serviceIds.includes(s.id) && myPkg.expiresAt >= date && myPkg._left > 0) a.clientPackageId = myPkg.id;
        break;
      }
      // passado: desfecho
      const r = R();
      const noShowP = p.flaky ? 0.22 : 0.035;
      if (r < noShowP) { a.status = 'falta'; a.history.push({ from: 'agendado', to: 'falta', at: date + 'T' + minToTime(timeToMin(placed) + 30), by: 'usr_paula' }); date = addDays(date, between(5, 15)); continue; }
      if (r < noShowP + 0.05) {
        if (chance(0.45)) { // reagendado
          a.status = 'reagendado'; a.history.push({ from: 'agendado', to: 'reagendado', at: addDays(date, -1) + 'T11:00', by: 'usr_paula' });
          a._resched = true; date = addDays(date, between(2, 6)); continue;
        }
        a.status = 'cancelado'; a.history.push({ from: 'agendado', to: 'cancelado', at: addDays(date, -1) + 'T16:00', by: 'usr_paula', reason: pick(['Imprevisto pessoal', 'Doença na família', 'Trabalho', 'Sem motivo informado']) });
        date = addDays(date, between(7, 20)); continue;
      }
      // realizado
      a.status = 'realizado'; firstDone = true; visits++;
      if (chance(0.7)) a.history.push({ from: 'agendado', to: 'confirmado', at: addDays(date, -1) + 'T17:30', by: 'usr_paula' });
      const by = pick(['usr_paula', 'usr_paula', 'usr_juliana', 'usr_bruna', 'usr_camila']);
      const at = date + 'T' + minToTime(timeToMin(placed) + s.duration + between(0, 10));
      let realized = s.price; let settlement; let saleId = null; const extras = [];
      // Pacote ativo?
      if (myPkg && myPkg.serviceIds.includes(s.id) && myPkg.expiresAt >= date && myPkg._left > 0) {
        settlement = 'pacote'; a.clientPackageId = myPkg.id; myPkg._left--;
        packageUsage.push({ id: id('use'), clientPackageId: myPkg.id, appointmentId: a.id, serviceId: s.id, date, at, by });
      } else {
        const items = [{ serviceId: s.id, packageId: null, description: s.name, qty: 1, unitPrice: s.price, discount: 0, professionalId: pro }];
        if (chance(0.07) && s.category !== 'Depilação') { const x = s.category === 'Unhas' ? srv.gel : srv.buco; if (x.id !== s.id) { items.push({ serviceId: x.id, packageId: null, description: x.name, qty: 1, unitPrice: x.price, discount: 0, professionalId: pro }); extras.push(x.id); } }
        if (chance(0.06)) { items[0].discount = Math.round(s.price * 0.1); }
        const rr = R(); settlement = rr < 0.925 ? 'pago' : rr < 0.955 ? 'parcial' : rr < 0.993 ? 'pendente' : 'cortesia';
        if (settlement === 'cortesia') { items.forEach((it) => { it.discount = it.unitPrice * it.qty; }); }
        const sale = makeSale({ date, clientId: c.id, appointmentId: a.id, type: settlement === 'cortesia' ? 'cortesia' : 'servico', items, by });
        if (settlement === 'cortesia') { sale.authorizedBy = 'usr_juliana'; sale.note = 'Cortesia autorizada — retorno de ajuste.'; }
        saleId = sale.id; const total = saleTotal(sale); realized = total;
        if (settlement === 'pago') pay(sale, total, date, methodPick(), by);
        if (settlement === 'parcial') { const part = Math.round(total * 0.5 / 100) * 100; pay(sale, part, date, methodPick(), by); const later = addDays(date, between(3, 12)); if (later < refDate) pay(sale, total - part, later, 'pix', 'usr_paula'); }
        if (settlement === 'pendente') { const later = addDays(date, between(2, 20)); if (later < refDate && chance(0.85)) pay(sale, total, later, methodPick(), 'usr_paula'); }
        // Compra de pacote no dia
        const pk = packages.find((k) => k.items.some((it) => it.serviceId === s.id));
        if (pk && !myPkg && p.churn > 0.4 && chance(0.16) && date < addDays(refDate, -3)) {
          const ps = makeSale({ date, clientId: c.id, appointmentId: null, type: 'pacote', items: [{ serviceId: null, packageId: pk.id, description: pk.name, qty: 1, unitPrice: pk.price, discount: 0, professionalId: pro }], by });
          if (chance(0.7)) pay(ps, pk.price, date, methodPick(), by); else { pay(ps, pk.price / 2, date, 'credito', by); const l = addDays(date, 30); if (l < refDate) pay(ps, pk.price / 2, l, 'pix', 'usr_paula'); }
          const total2 = pk.items.reduce((t, it) => t + it.sessions, 0);
          myPkg = { id: id('cpk'), clientId: c.id, packageId: pk.id, saleId: ps.id, purchaseDate: date, expiresAt: addDays(date, pk.validityDays), sessionsTotal: total2, serviceIds: pk.items.map((it) => it.serviceId), items: pk.items.map((it) => ({ ...it })), _left: total2, status: 'ativo' };
          clientPackages.push(myPkg);
        }
      }
      a.checkout = { at, by, settlement, realizedValue: realized, saleId, extras, method: null };
      a.history.push({ from: a.history.at(-1).to, to: 'realizado', at, by });
      if (myPkg && (myPkg._left <= 0 || myPkg.expiresAt < date)) myPkg = myPkg._left <= 0 ? null : myPkg;
      const f = between(p.freq[0], p.freq[1]);
      date = addDays(date, Math.round(f * (0.85 + R() * 0.4)));
    }
  }
  // Liga reagendamentos ao próximo compromisso da mesma cliente
  const byClient = new Map(); for (const a of appointments) { if (!byClient.has(a.clientId)) byClient.set(a.clientId, []); byClient.get(a.clientId).push(a); }
  for (const list of byClient.values()) { list.sort((x, y) => (x.date + x.start).localeCompare(y.date + y.start)); for (let i = 0; i < list.length; i++) if (list[i]._resched && list[i + 1]) { list[i].rescheduledTo = list[i + 1].id; list[i + 1].rescheduledFrom = list[i].id; } }
  for (const a of appointments) delete a._resched;

  // ---------- Hoje (montado à mão para demonstrar todos os estados) ----------
  const active = clients.filter((c) => !c._p.lead && appointments.some((a) => a.clientId === c.id && a.status === 'realizado'));
  const todayPlan = [
    ['09:00', 'design', J, 'realizado', 'pago'],
    ['09:15', 'manicure', C, 'realizado', 'parcial'],
    ['09:30', 'limpeza', B, 'falta'],
    ['10:00', 'manut', J, 'agendado'], // passou sem status → pendência
    ['10:15', 'pedicure', C, 'confirmado'], // passou sem status → pendência
    ['10:30', 'massagem', L, 'cancelado'],
    ['11:00', 'henna', B, 'realizado', 'pendente'],
    ['13:00', 'cilios', J, 'em_atendimento'],
    ['13:30', 'gel', C, 'em_atendimento'],
    ['14:00', 'design', B, 'chegou'],
    ['14:30', 'limpeza', L, 'confirmado', null, 'pkg'],
    ['15:00', 'manicure', C, 'confirmado'],
    ['15:30', 'revital', B, 'agendado'],
    ['16:00', 'lash', L, 'agendado'],
    ['16:30', 'design', J, 'confirmado', null, 'pkg'],
    ['17:00', 'fibra', C, 'agendado'],
    ['17:30', 'design', B, 'agendado', null, 'lead'],
  ];
  const usedToday = new Set();
  for (const [time, key, pro, status, settle, flag] of todayPlan) {
    const s = srv[key];
    let c;
    if (flag === 'lead') c = clients.find((x) => x._p.lead && !usedToday.has(x.id));
    else if (flag === 'pkg') {
      const pkgSvcs = { limpeza: 'pkg_limpeza4', design: 'pkg_sobr5' };
      c = active.find((x) => !usedToday.has(x.id) && !clientPackages.some((cp) => cp.clientId === x.id));
      const pk = packages.find((k) => k.id === pkgSvcs[key]);
      const pDate = addDays(refDate, -between(20, 50));
      const ps = makeSale({ date: pDate, clientId: c.id, type: 'pacote', items: [{ serviceId: null, packageId: pk.id, description: pk.name, qty: 1, unitPrice: pk.price, discount: 0, professionalId: pro }], by: 'usr_juliana' });
      pay(ps, pk.price, pDate, 'pix', 'usr_juliana');
      const tot = pk.items.reduce((t, it) => t + it.sessions, 0);
      const cp = { id: id('cpk'), clientId: c.id, packageId: pk.id, saleId: ps.id, purchaseDate: pDate, expiresAt: addDays(pDate, pk.validityDays), sessionsTotal: tot, serviceIds: pk.items.map((it) => it.serviceId), items: pk.items.map((it) => ({ ...it })), _left: tot, status: 'ativo' };
      clientPackages.push(cp);
      const uses = key === 'limpeza' ? 3 : 2; // limpeza: fica com 1 sessão (alerta de fim)
      for (let u = 0; u < uses; u++) {
        let dd = addDays(pDate, 7 * (u + 1)); let st = null;
        for (let t = 0; t < 5 && !st; t++) { st = allocate(pro, dd, s.duration, 600, s.resourceId); if (!st) dd = addDays(dd, 1); }
        if (!st || dd >= refDate) continue;
        const a = { id: id('apt'), clientId: c.id, serviceId: s.id, professionalId: pro, date: dd, start: st, duration: s.duration, price: s.price, status: 'realizado', origin: 'Recorrente', notes: '', clientPackageId: cp.id, resourceId: s.resourceId, rescheduledFrom: null, rescheduledTo: null, createdAt: addDays(dd, -5) + 'T10:00', createdBy: 'usr_paula', history: [{ from: null, to: 'agendado', at: addDays(dd, -5) + 'T10:00', by: 'usr_paula' }], checkout: { at: dd + 'T' + minToTime(timeToMin(st) + s.duration), by: 'usr_paula', settlement: 'pacote', realizedValue: s.price, saleId: null, extras: [] } };
        a.history.push({ from: 'agendado', to: 'realizado', at: a.checkout.at, by: 'usr_paula' });
        appointments.push(a); packageUsage.push({ id: id('use'), clientPackageId: cp.id, appointmentId: a.id, serviceId: s.id, date: dd, at: a.checkout.at, by: 'usr_paula' }); cp._left--;
      }
      c._todayPkg = cp.id;
    } else c = active.find((x) => !usedToday.has(x.id) && !appointments.some((a) => a.clientId === x.id && a.date > refDate && a.date <= addDays(refDate, 3)) && x.id !== clients[20].id) ;
    usedToday.add(c.id);
    // reserva no mapa de ocupação
    mark(pro + refDate, timeToMin(time), timeToMin(time) + s.duration); if (s.resourceId) mark(s.resourceId + refDate, timeToMin(time), timeToMin(time) + s.duration);
    const created = addDays(refDate, -between(1, 9)) + 'T' + minToTime(between(540, 1140));
    const a = { id: id('apt'), clientId: c.id, serviceId: s.id, professionalId: pro, date: refDate, start: time, duration: s.duration, price: s.price, status, origin: flag === 'lead' ? 'Instagram' : 'Recorrente', notes: '', clientPackageId: flag === 'pkg' ? c._todayPkg : null, resourceId: s.resourceId, rescheduledFrom: null, rescheduledTo: null, createdAt: created, createdBy: 'usr_paula', history: [{ from: null, to: 'agendado', at: created, by: 'usr_paula' }], checkout: null };
    if (flag === 'lead') a.notes = 'Primeira visita — veio pelo Instagram.';
    const steps = { confirmado: ['confirmado'], chegou: ['confirmado', 'chegou'], em_atendimento: ['confirmado', 'chegou', 'em_atendimento'], realizado: ['confirmado', 'chegou', 'em_atendimento', 'realizado'], falta: ['confirmado', 'falta'], cancelado: ['cancelado'] }[status] || [];
    let prev = 'agendado'; let tm = timeToMin(time) - 60;
    for (const stp of steps) { const at = stp === 'confirmado' ? addDays(refDate, -1) + 'T17:00' : refDate + 'T' + minToTime(stp === 'realizado' ? timeToMin(time) + s.duration : stp === 'cancelado' ? 480 : Math.max(tm, timeToMin(time) - 10)); a.history.push({ from: prev, to: stp, at, by: 'usr_paula', ...(stp === 'cancelado' ? { reason: 'Imprevisto pessoal' } : {}) }); prev = stp; tm += 10; }
    if (status === 'realizado') {
      const at = refDate + 'T' + minToTime(timeToMin(time) + s.duration + 3);
      const sale = makeSale({ date: refDate, clientId: c.id, appointmentId: a.id, type: 'servico', items: [{ serviceId: s.id, packageId: null, description: s.name, qty: 1, unitPrice: s.price, discount: 0, professionalId: pro }], by: 'usr_paula' });
      if (settle === 'pago') pay(sale, s.price, refDate, 'pix', 'usr_paula');
      if (settle === 'parcial') pay(sale, Math.round(s.price / 2), refDate, 'dinheiro', 'usr_paula');
      a.checkout = { at, by: 'usr_paula', settlement: settle, realizedValue: s.price, saleId: sale.id, extras: [] };
    }
    appointments.push(a);
  }
  // Ontem: um atendimento sem status final (pendência operacional de dia anterior)
  const yd = addDays(refDate, -1);
  const yAppt = appointments.find((a) => a.date === yd && a.status === 'realizado' && a.checkout && a.checkout.settlement === 'pago');
  if (yAppt) {
    const s2 = sales.find((s) => s.id === yAppt.checkout.saleId); sales.splice(sales.indexOf(s2), 1);
    for (let i = payments.length - 1; i >= 0; i--) if (payments[i].saleId === s2.id) payments.splice(i, 1);
    yAppt.status = 'confirmado'; yAppt.checkout = null; yAppt.history = yAppt.history.filter((h) => h.to !== 'realizado');
  }

  for (const cp of clientPackages) delete cp._left;
  for (const c of clients) { delete c._p; delete c._todayPkg; }

  // ---------- Despesas ----------
  const expenses = [];
  const months = []; for (let d = START.slice(0, 8) + '01'; d <= refDate; d = addDays(d.slice(0, 8) + '28', 5).slice(0, 8) + '01') months.push(d);
  const E = (desc, cat, amount, date, paid = true, paidDate = date) => expenses.push({ id: id('exp'), description: desc, category: cat, amount, date, paid, paidDate: paid ? paidDate : null, createdBy: 'usr_juliana', supplier: '' });
  for (const m of months) {
    const isCur = m.slice(0, 7) === refDate.slice(0, 7);
    const due = (day) => m.slice(0, 8) + String(day).padStart(2, '0');
    const paidIf = (day) => !isCur || due(day) <= refDate;
    E('Aluguel do espaço', 'Aluguel', 280000, due(5), paidIf(5));
    E('Energia elétrica', 'Contas de consumo', between(29000, 42000), due(12), paidIf(12));
    E('Água', 'Contas de consumo', between(9000, 14000), due(14), paidIf(14));
    E('Internet e telefone', 'Contas de consumo', 12900, due(10), paidIf(10));
    E('Produtos e descartáveis', 'Produtos', between(80000, 140000), due(8), paidIf(8));
    E('Contabilidade', 'Serviços', 45000, due(20), paidIf(20));
    E('Anúncios Instagram', 'Marketing', between(20000, 45000), due(3), paidIf(3));
    if (isCur) { expenses.at(-2).paid = false; expenses.at(-2).paidDate = null; }
  }
  E('Manutenção da maca', 'Manutenção', 38000, addDays(refDate, -120));
  E('Cadeira de manicure nova', 'Equipamentos', 129000, addDays(refDate, -200));

  // ---------- CRM: templates, jornadas, campanhas, comunicações ----------
  const templates = [
    { id: 'tpl_confirmacao', name: 'Confirmação de agendamento', type: 'confirmacao', purpose: 'operacional', channel: 'whatsapp', text: 'Olá, {{nome}}! Seu horário de {{servico}} com {{profissional}} está marcado para {{data}} às {{horario}} no {{estabelecimento}}. Responda SIM para confirmar.' },
    { id: 'tpl_lembrete', name: 'Lembrete 24 h antes', type: 'lembrete', purpose: 'operacional', channel: 'whatsapp', text: 'Oi, {{nome}}! Lembrando do seu {{servico}} amanhã, {{data}}, às {{horario}}. Te esperamos no {{estabelecimento}}.' },
    { id: 'tpl_pos', name: 'Pós-atendimento', type: 'pos', purpose: 'operacional', channel: 'whatsapp', text: '{{nome}}, obrigada pela visita! Como ficou seu {{servico}}? Qualquer dúvida, é só chamar.' },
    { id: 'tpl_aniversario', name: 'Aniversário', type: 'aniversario', purpose: 'promocional', channel: 'whatsapp', text: 'Feliz aniversário, {{nome}}! Neste mês você tem 15% de desconto em qualquer serviço do {{estabelecimento}}.' },
    { id: 'tpl_reativacao', name: 'Reativação', type: 'reativacao', purpose: 'promocional', channel: 'whatsapp', text: 'Oi, {{nome}}! Faz tempo que não te vemos por aqui. Que tal agendar seu {{servico}}? Temos horários esta semana.' },
    { id: 'tpl_pacote', name: 'Pacote próximo do fim', type: 'pacote', purpose: 'operacional', channel: 'whatsapp', text: '{{nome}}, seu pacote está quase no fim. Quer garantir a renovação com condição especial?' },
    { id: 'tpl_promo', name: 'Promoção da semana', type: 'promocional', purpose: 'promocional', channel: 'whatsapp', text: '{{nome}}, esta semana tem condição especial no {{estabelecimento}}. Responda para saber os horários.' },
    { id: 'tpl_email_novidades', name: 'Novidades por e-mail', type: 'promocional', purpose: 'promocional', channel: 'email', subject: 'Novidades no {{estabelecimento}}', text: 'Olá, {{nome}}! Chegaram novos serviços e horários no {{estabelecimento}}. Agende pelo WhatsApp.' },
  ];
  const journeys = [
    { id: 'jrn_confirmacao', name: 'Confirmação de agendamento', trigger: 'appointment.created', condition: 'agendamento ativo', waitHours: 0, templateId: 'tpl_confirmacao', channel: 'whatsapp', active: true, createdAt: START },
    { id: 'jrn_lembrete', name: 'Lembrete antes do atendimento', trigger: 'appointment.reminder', condition: 'agendamento ativo', waitHours: -24, templateId: 'tpl_lembrete', channel: 'whatsapp', active: true, createdAt: START },
    { id: 'jrn_pos', name: 'Pós-atendimento após 1 dia', trigger: 'appointment.completed', condition: 'atendimento realizado', waitHours: 24, templateId: 'tpl_pos', channel: 'whatsapp', active: true, createdAt: START },
    { id: 'jrn_aniversario', name: 'Aniversário', trigger: 'client.birthday', condition: 'aniversário hoje', waitHours: 0, templateId: 'tpl_aniversario', channel: 'whatsapp', active: true, createdAt: START },
    { id: 'jrn_reativacao', name: 'Reativação após inatividade', trigger: 'client.inactive', condition: 'sem visita há 90 dias', waitHours: 0, templateId: 'tpl_reativacao', channel: 'whatsapp', active: false, createdAt: START },
    { id: 'jrn_pacote', name: 'Pacote próximo do fim', trigger: 'package.session_consumed', condition: 'restam 1 ou menos sessões', waitHours: 2, templateId: 'tpl_pacote', channel: 'whatsapp', active: true, createdAt: START },
  ];

  const campaigns = []; const communications = [];
  const mkCampaign = (name, objective, segmentId, tplId, daysAgo, status) => {
    const c = { id: id('cmp'), name, objective, segmentId, segmentLabel: '', channel: 'whatsapp', templateId: tplId, text: templates.find((t) => t.id === tplId).text, status, createdAt: addDays(refDate, -daysAgo - 2) + 'T10:00', createdBy: 'usr_juliana', approvedBy: status !== 'rascunho' ? 'usr_juliana' : null, approvedAt: status !== 'rascunho' ? addDays(refDate, -daysAgo - 1) + 'T09:00' : null, scheduledAt: status !== 'rascunho' ? addDays(refDate, -daysAgo) + 'T10:00' : null, executedAt: status === 'concluida' ? addDays(refDate, -daysAgo) + 'T10:00' : null, simulated: true, recipients: [] };
    campaigns.push(c); return c;
  };
  const c1 = mkCampaign('Volta às aulas — sobrancelhas', 'Reativar clientes de sobrancelhas sem retorno', 'sem_retorno_60', 'tpl_reativacao', 70, 'concluida');
  const c2 = mkCampaign('Dia das Mães — pacotes', 'Vender pacotes de limpeza de pele', 'recorrentes', 'tpl_promo', 190, 'concluida');
  mkCampaign('Black Friday — mãos e pés', 'Vender pacote Mãos e pés', 'servico:srv_manicure', 'tpl_promo', 0, 'rascunho');
  for (const camp of [c1, c2]) {
    const pool = clients.filter((x) => x.consents.whatsapp.promocional).slice(0, camp === c1 ? 34 : 58);
    for (const x of pool) {
      const st = R() < 0.06 ? 'falhou' : R() < 0.55 ? 'lida' : 'entregue';
      camp.recipients.push({ clientId: x.id, status: st, at: camp.executedAt });
      communications.push({ id: id('msg'), clientId: x.id, channel: 'whatsapp', purpose: 'promocional', templateId: camp.templateId, campaignId: camp.id, journeyId: null, appointmentId: null, text: camp.text, status: st, at: camp.executedAt, simulated: true });
    }
  }
  // Histórico de mensagens operacionais simuladas recentes (jornadas)
  for (const a of appointments.filter((x) => x.date >= addDays(refDate, -10) && x.date <= addDays(refDate, 3))) {
    const c = clients.find((x) => x.id === a.clientId); if (!c.consents.whatsapp.operacional) continue;
    communications.push({ id: id('msg'), clientId: c.id, channel: 'whatsapp', purpose: 'operacional', templateId: 'tpl_confirmacao', campaignId: null, journeyId: 'jrn_confirmacao', appointmentId: a.id, text: 'Confirmação de agendamento', status: R() < 0.05 ? 'falhou' : 'entregue', at: a.createdAt, simulated: true });
  }

  const blocks = [
    { id: id('blk'), professionalId: L, start: addDays(refDate, 9) + 'T00:00', end: addDays(refDate, 13) + 'T23:59', reason: 'Férias', allDay: true },
    { id: id('blk'), professionalId: B, start: addDays(refDate, 2) + 'T15:00', end: addDays(refDate, 2) + 'T17:00', reason: 'Curso de atualização', allDay: false },
  ];

  return {
    version: 3, seededAt: new Date().toISOString(), seed,
    org, settings: { refDate, demoTime: '14:10', session: null, viewAsUserId: null },
    users, professionals, resources, services, servicePriceHistory: services.map((s) => ({ id: id('sph'), serviceId: s.id, price: s.price, from: s.createdAt })),
    packages, clients, clientMerges: [], consentHistory, appointments, blocks, sales, payments, expenses, clientPackages, packageUsage,
    cashClosings: [], templates, journeys, journeyExecutions: [], campaigns, communications, events: [], audit: [],
    tracking: { appointmentCreateMs: [], checkoutMs: [] },
  };
}
