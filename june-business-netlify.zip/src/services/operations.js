// Operações de domínio: única camada que grava dados. Cada operação roda em
// transação (tudo ou nada), registra auditoria e publica eventos de negócio.
import { transaction, getState } from '../data/store.js';
import { canTransition, STATUS, ACTIVE_STATUSES, ROLE_PERMS } from '../domain/rules.js';
import { normalizePhone, uid, addDays, timeToMin, minToTime, diffDays } from '../util.js';
import {
  DomainError, assertPerm, hasPerm, currentUser, client, service, professional, appointment, pkg, sale, byId,
  checkConflict, saleTotal, salePaid, packageRemaining, findByPhone,
} from './core.js';

const stamp = (d) => `${d.settings.refDate}T${d.settings.demoTime}`;
const me = (d) => d.settings.session?.userId || null;
const req = (v, msg, field) => { if (v == null || v === '' || (typeof v === 'number' && isNaN(v))) throw new DomainError(msg, field); };

// ======================= CLIENTES =======================
export function createClient(input) {
  return transaction((d, ctx) => {
    assertPerm(d, 'clientes.editar');
    const c = buildClient(d, input);
    d.clients.push(c); ctx.audit('criou', 'cliente', c.id, c.name);
    ctx.publish('client.created', { clientId: c.id });
    return c;
  });
}
function buildClient(d, input) {
  req(input.name?.trim(), 'Informe o nome da cliente.', 'name');
  const phone = normalizePhone(input.phone); if (!phone) throw new DomainError('Telefone inválido. Use DDD + número.', 'phone');
  const at = stamp(d);
  const c = {
    id: uid('cli'), name: input.name.trim(), phone, email: (input.email || '').trim(), birth: input.birth || '', createdAt: at,
    origin: input.origin || 'Agendamento', notes: input.notes || '', preferences: input.preferences || '', status: 'ativo', mergedInto: null,
    consents: input.consents || { whatsapp: { operacional: true, promocional: false }, email: { operacional: !!input.email, promocional: false }, sms: { operacional: false, promocional: false } },
  };
  for (const ch of Object.keys(c.consents)) for (const pu of ['operacional', 'promocional']) if (c.consents[ch][pu]) d.consentHistory.push({ id: uid('cns'), clientId: c.id, channel: ch, purpose: pu, value: true, at, origin: input.consentOrigin || 'Cadastro', by: me(d) });
  return c;
}
export function updateClient(id, patch) {
  return transaction((d, ctx) => {
    assertPerm(d, 'clientes.editar');
    const c = client(d, id); if (!c) throw new DomainError('Cliente não encontrada.');
    if (patch.name !== undefined) { req(patch.name.trim(), 'Informe o nome.', 'name'); c.name = patch.name.trim(); }
    if (patch.phone !== undefined) { const p = normalizePhone(patch.phone); if (!p) throw new DomainError('Telefone inválido.', 'phone'); c.phone = p; }
    for (const k of ['email', 'birth', 'origin', 'notes', 'preferences']) if (patch[k] !== undefined) c[k] = patch[k];
    ctx.audit('editou', 'cliente', c.id, c.name);
    return c;
  });
}
export function updateConsent(clientId, channel, purpose, value, origin = 'Alteração manual') {
  return transaction((d, ctx) => {
    const c = client(d, clientId); if (!c) throw new DomainError('Cliente não encontrada.');
    if (channel === 'email' && value && !c.email) throw new DomainError('Cadastre um e-mail antes de autorizar este canal.');
    c.consents[channel][purpose] = value;
    d.consentHistory.push({ id: uid('cns'), clientId, channel, purpose, value, at: stamp(d), origin, by: me(d) });
    ctx.audit(value ? 'autorizou' : 'revogou', 'consentimento', clientId, `${channel}/${purpose}`);
    ctx.publish('consent.updated', { clientId, channel, purpose, value });
  });
}
export function mergeClients(keepId, mergeId) {
  return transaction((d, ctx) => {
    assertPerm(d, 'clientes.mesclar');
    if (keepId === mergeId) throw new DomainError('Escolha dois cadastros diferentes.');
    const keep = client(d, keepId), drop = client(d, mergeId); if (!keep || !drop) throw new DomainError('Cadastro não encontrado.');
    let moved = 0;
    for (const col of ['appointments', 'sales', 'payments', 'clientPackages', 'communications', 'consentHistory', 'journeyExecutions']) for (const r of d[col]) if (r.clientId === mergeId) { r.clientId = keepId; moved++; }
    if (!keep.email && drop.email) keep.email = drop.email; if (!keep.birth && drop.birth) keep.birth = drop.birth;
    if (drop.createdAt < keep.createdAt) keep.createdAt = drop.createdAt;
    drop.mergedInto = keepId; drop.status = 'mesclado';
    d.clientMerges.push({ id: uid('mrg'), keepId, mergedId: mergeId, mergedName: drop.name, at: stamp(d), by: me(d), movedRecords: moved });
    ctx.audit('mesclou', 'cliente', keepId, `${drop.name} → ${keep.name} (${moved} registros)`);
    return { moved };
  });
}
export function dismissDuplicate(aId, bId) {
  return transaction((d) => { d.org.dismissedDuplicates = d.org.dismissedDuplicates || []; d.org.dismissedDuplicates.push([aId, bId].sort().join('|')); });
}

// ======================= AGENDAMENTOS =======================
export function createAppointment(input) {
  const t0 = input._startedAt;
  return transaction((d, ctx) => {
    assertPerm(d, 'agenda.editar');
    const u = currentUser(d);
    req(input.serviceId, 'Escolha o serviço.', 'serviceId'); req(input.professionalId, 'Escolha a profissional.', 'professionalId');
    req(input.date, 'Escolha a data.', 'date'); req(input.start, 'Escolha o horário.', 'start');
    if (u.role === 'profissional' && !hasPerm(d, 'agenda.ver_todas') && input.professionalId !== u.professionalId) throw new DomainError('Você só pode agendar na sua própria agenda.');
    const s = service(d, input.serviceId); if (!s || !s.active) throw new DomainError('Serviço indisponível.', 'serviceId');
    if (!s.professionalIds.includes(input.professionalId)) throw new DomainError('Esta profissional não está habilitada para o serviço.', 'professionalId');
    const duration = Number(input.duration) || s.duration;
    const resourceId = input.resourceId !== undefined ? input.resourceId || null : s.resourceId;
    const conflict = checkConflict(d, { professionalId: input.professionalId, date: input.date, start: input.start, duration, resourceId });
    if (conflict) throw new DomainError(conflict, 'start');
    // Cliente: reutiliza o cadastro confirmado ou cria um novo automaticamente.
    let c; let created = false;
    if (input.clientId) { c = client(d, input.clientId); if (!c || c.mergedInto) throw new DomainError('Cliente não encontrada.'); }
    else {
      c = buildClient(d, { name: input.clientName, phone: input.phone, origin: input.origin || 'Agendamento', consentOrigin: 'Informado no agendamento' });
      d.clients.push(c); created = true; ctx.audit('criou automaticamente', 'cliente', c.id, c.name); ctx.publish('client.created', { clientId: c.id, auto: true });
    }
    if (input.clientPackageId) {
      const cp = byId(d.clientPackages, input.clientPackageId);
      if (!cp || cp.clientId !== c.id) throw new DomainError('Pacote não pertence a esta cliente.');
      if (cp.expiresAt < input.date) throw new DomainError('O pacote vence antes da data do atendimento.');
      if (packageRemaining(d, cp, s.id) <= 0) throw new DomainError('Pacote sem saldo para este serviço.');
    }
    const price = input.price != null && !isNaN(input.price) ? input.price : s.price;
    const at = stamp(d);
    const a = {
      id: uid('apt'), clientId: c.id, serviceId: s.id, professionalId: input.professionalId, date: input.date, start: input.start, duration,
      price, status: 'agendado', origin: input.origin || (created ? 'Agendamento' : 'Recorrente'), notes: input.notes || '', clientPackageId: input.clientPackageId || null,
      resourceId, rescheduledFrom: input.rescheduledFrom || null, rescheduledTo: null, createdAt: at, createdBy: me(d), history: [{ from: null, to: 'agendado', at, by: me(d) }], checkout: null,
    };
    d.appointments.push(a);
    if (t0) { d.tracking.appointmentCreateMs.push(Date.now() - t0); if (d.tracking.appointmentCreateMs.length > 200) d.tracking.appointmentCreateMs.shift(); }
    ctx.audit('criou', 'agendamento', a.id, `${c.name} · ${s.name} · ${a.date} ${a.start}`);
    ctx.publish('appointment.created', { appointmentId: a.id, clientId: c.id });
    return { appointment: a, client: c, createdClient: created };
  });
}

export function changeStatus(apptId, to, { reason } = {}) {
  return transaction((d, ctx) => {
    assertPerm(d, 'agenda.editar');
    const a = appointment(d, apptId); if (!a) throw new DomainError('Agendamento não encontrado.');
    if (to === 'realizado') throw new DomainError('Use a Finalização Expressa para concluir o atendimento.');
    if (!canTransition(a.status, to)) throw new DomainError(`Não é possível mudar de “${STATUS[a.status].label}” para “${STATUS[to].label}”.`);
    if (to === 'falta' && `${a.date}T${a.start}` > stamp(d)) throw new DomainError('Só é possível marcar falta depois do horário agendado.');
    a.history.push({ from: a.status, to, at: stamp(d), by: me(d), ...(reason ? { reason } : {}) });
    a.status = to;
    ctx.audit('alterou status', 'agendamento', a.id, `${STATUS[to].label}${reason ? ' — ' + reason : ''}`);
    const evt = { confirmado: 'appointment.confirmed', cancelado: 'appointment.cancelled', falta: 'appointment.no_show', chegou: 'appointment.arrived', em_atendimento: 'appointment.started' }[to];
    if (evt) ctx.publish(evt, { appointmentId: a.id, clientId: a.clientId });
    return a;
  });
}

export function reschedule(apptId, { date, start, professionalId }) {
  return transaction((d, ctx) => {
    assertPerm(d, 'agenda.editar');
    const a = appointment(d, apptId); if (!a) throw new DomainError('Agendamento não encontrado.');
    if (!ACTIVE_STATUSES.includes(a.status) && a.status !== 'falta') throw new DomainError('Este agendamento não pode mais ser reagendado.');
    if (a.status === 'em_atendimento') throw new DomainError('O atendimento já começou.');
    req(date, 'Escolha a nova data.', 'date'); req(start, 'Escolha o novo horário.', 'start');
    const pro = professionalId || a.professionalId;
    const s = service(d, a.serviceId);
    if (!s.professionalIds.includes(pro)) throw new DomainError('Profissional não habilitada para o serviço.');
    const conflict = checkConflict(d, { professionalId: pro, date, start, duration: a.duration, resourceId: a.resourceId, ignoreId: a.id });
    if (conflict) throw new DomainError(conflict, 'start');
    const at = stamp(d);
    const n = { ...structuredClone(a), id: uid('apt'), date, start, professionalId: pro, status: 'agendado', rescheduledFrom: a.id, rescheduledTo: null, createdAt: at, createdBy: me(d), history: [{ from: null, to: 'agendado', at, by: me(d), note: `Reagendado de ${a.date} ${a.start}` }], checkout: null };
    a.history.push({ from: a.status, to: 'reagendado', at, by: me(d), note: `Novo horário: ${date} ${start}` });
    a.status = 'reagendado'; a.rescheduledTo = n.id;
    d.appointments.push(n);
    ctx.audit('reagendou', 'agendamento', a.id, `${a.date} ${a.start} → ${date} ${start}`);
    ctx.publish('appointment.rescheduled', { appointmentId: a.id, newAppointmentId: n.id, clientId: a.clientId });
    ctx.publish('appointment.created', { appointmentId: n.id, clientId: a.clientId, rescheduled: true });
    return n;
  });
}

export function updateAppointmentNotes(apptId, notes) {
  return transaction((d, ctx) => { const a = appointment(d, apptId); a.notes = notes; ctx.audit('editou observação', 'agendamento', a.id, ''); });
}

// ======================= FINALIZAÇÃO EXPRESSA =======================
// input: { realizedValue, extras:[{serviceId, price}], settlement, method, amountReceived, clientPackageId, authorizedBy, idempotencyKey, startedAt }
export function checkout(apptId, input) {
  // Idempotência: repetir a mesma operação devolve o resultado já gravado.
  const s0 = getState(); const a0 = appointment(s0, apptId);
  if (a0?.checkout && input.idempotencyKey && a0.checkout.idempotencyKey === input.idempotencyKey) return { appointment: a0, duplicate: true };
  return transaction((d, ctx) => {
    assertPerm(d, 'atendimento.finalizar');
    const u = currentUser(d);
    const a = appointment(d, apptId); if (!a) throw new DomainError('Atendimento não encontrado.');
    if (a.checkout || a.status === 'realizado') throw new DomainError('Este atendimento já foi finalizado. Para corrigir, use ajuste ou estorno.');
    if (!['agendado', 'confirmado', 'chegou', 'em_atendimento'].includes(a.status)) throw new DomainError(`Atendimento com status “${STATUS[a.status].label}” não pode ser finalizado.`);
    if (u.role === 'profissional' && a.professionalId !== u.professionalId) throw new DomainError('Você só pode finalizar seus próprios atendimentos.');
    const s = service(d, a.serviceId);
    const settlement = input.settlement; req(settlement, 'Escolha a situação financeira.', 'settlement');
    const realized = Math.round(input.realizedValue);
    if (settlement !== 'pacote' && settlement !== 'cortesia' && (!(realized >= 0) || isNaN(realized))) throw new DomainError('Informe o valor realizado.', 'realizedValue');
    const extras = (input.extras || []).map((x) => { const sv = service(d, x.serviceId); if (!sv) throw new DomainError('Serviço extra inválido.'); return { serviceId: sv.id, description: sv.name, price: x.price != null ? x.price : sv.price }; });
    const at = stamp(d); const by = me(d);
    let saleRec = null; let usage = null;

    const mainItem = () => realized <= a.price
      ? { serviceId: s.id, packageId: null, description: s.name, qty: 1, unitPrice: a.price, discount: a.price - realized, professionalId: a.professionalId }
      : { serviceId: s.id, packageId: null, description: s.name, qty: 1, unitPrice: realized, discount: 0, professionalId: a.professionalId };
    const extraItems = extras.map((x) => ({ serviceId: x.serviceId, packageId: null, description: x.description, qty: 1, unitPrice: x.price, discount: 0, professionalId: a.professionalId }));
    const newSale = (items, type) => { const sl = { id: uid('sale'), date: d.settings.refDate, clientId: a.clientId, appointmentId: a.id, type, items, status: 'valida', createdAt: at, createdBy: by, note: '' }; d.sales.push(sl); return sl; };
    const addPayment = (sl, amount, method) => {
      if (!(amount > 0)) return null; req(method, 'Escolha a forma de pagamento.', 'method');
      const key = `${input.idempotencyKey || a.id}:${sl.id}:pay`;
      if (d.payments.some((p) => p.idempotencyKey === key)) return null;
      const p = { id: uid('pay'), saleId: sl.id, clientId: sl.clientId, amount, method, date: d.settings.refDate, kind: 'recebimento', createdAt: at, createdBy: by, idempotencyKey: key };
      d.payments.push(p); ctx.publish('payment.received', { paymentId: p.id, saleId: sl.id, amount }); return p;
    };

    if (settlement === 'pacote') {
      const cp = byId(d.clientPackages, input.clientPackageId || a.clientPackageId); if (!cp) throw new DomainError('Selecione o pacote da cliente.', 'clientPackageId');
      if (cp.clientId !== a.clientId) throw new DomainError('Pacote não pertence a esta cliente.');
      if (cp.expiresAt < a.date) throw new DomainError(`Pacote vencido em ${cp.expiresAt.split('-').reverse().join('/')}. Escolha outra situação financeira.`);
      if (!cp.serviceIds.includes(s.id)) throw new DomainError('Este pacote não inclui o serviço realizado.');
      if (packageRemaining(d, cp, s.id) <= 0) throw new DomainError('Pacote sem sessões restantes para este serviço.');
      if (d.packageUsage.some((x) => x.appointmentId === a.id)) throw new DomainError('Sessão já consumida para este atendimento.');
      usage = { id: uid('use'), clientPackageId: cp.id, appointmentId: a.id, serviceId: s.id, date: a.date, at, by };
      d.packageUsage.push(usage); a.clientPackageId = cp.id;
      ctx.publish('package.session_consumed', { clientPackageId: cp.id, clientId: a.clientId, remaining: packageRemaining(d, cp) });
      if (extraItems.length) { saleRec = newSale(extraItems, 'servico'); addPayment(saleRec, saleTotal(saleRec), input.method); }
    } else if (settlement === 'cortesia') {
      if (!input.authorizedBy) throw new DomainError('Cortesia exige autorização.', 'authorizedBy');
      const auth = byId(d.users, input.authorizedBy); if (!auth || !hasPerm(d, 'estornos.autorizar', auth)) throw new DomainError('Quem autoriza precisa ter permissão para cortesias.');
      const items = [mainItem(), ...extraItems].map((i) => ({ ...i, unitPrice: i.unitPrice || a.price, discount: i.unitPrice || a.price }));
      items[0].unitPrice = a.price; items[0].discount = a.price;
      saleRec = newSale(items, 'cortesia'); saleRec.authorizedBy = auth.id; saleRec.note = input.note || 'Cortesia autorizada';
    } else {
      saleRec = newSale([mainItem(), ...extraItems], 'servico');
      const total = saleTotal(saleRec);
      if (settlement === 'pago') addPayment(saleRec, total, input.method);
      if (settlement === 'parcial') {
        const amt = Math.round(input.amountReceived);
        if (!(amt > 0)) throw new DomainError('Informe o valor recebido.', 'amountReceived');
        if (amt >= total) throw new DomainError('Valor recebido igual ou maior que o total: use “Pago integralmente”.', 'amountReceived');
        addPayment(saleRec, amt, input.method);
      }
    }
    if (saleRec) ctx.publish('sale.created', { saleId: saleRec.id, clientId: a.clientId });
    a.history.push({ from: a.status, to: 'realizado', at, by });
    a.status = 'realizado';
    a.checkout = { at, by, settlement, realizedValue: settlement === 'pacote' ? 0 : realized, saleId: saleRec?.id || null, extras: extras.map((x) => x.serviceId), method: input.method || null, idempotencyKey: input.idempotencyKey || null, usageId: usage?.id || null };
    if (input.startedAt) { d.tracking.checkoutMs.push(Date.now() - input.startedAt); if (d.tracking.checkoutMs.length > 200) d.tracking.checkoutMs.shift(); }
    ctx.audit('finalizou', 'atendimento', a.id, `${service(d, a.serviceId).name} · ${settlement}`);
    ctx.publish('appointment.completed', { appointmentId: a.id, clientId: a.clientId });
    return { appointment: a, sale: saleRec };
  });
}

// ======================= VENDAS E PAGAMENTOS =======================
export function createSale({ clientId, items, method, amountReceived, note, date }) {
  return transaction((d, ctx) => {
    assertPerm(d, 'pagamentos.registrar');
    if (!client(d, clientId)) throw new DomainError('Escolha a cliente.', 'clientId');
    if (!items?.length) throw new DomainError('Adicione ao menos um item.');
    for (const it of items) if (!(it.unitPrice >= 0) || !(it.qty > 0)) throw new DomainError('Item com valor ou quantidade inválida.');
    const sl = { id: uid('sale'), date: date || d.settings.refDate, clientId, appointmentId: null, type: 'avulsa', items: items.map((i) => ({ discount: 0, packageId: null, serviceId: null, professionalId: null, ...i })), status: 'valida', createdAt: stamp(d), createdBy: me(d), note: note || '' };
    d.sales.push(sl);
    const total = saleTotal(sl);
    const amt = amountReceived == null ? total : Math.round(amountReceived);
    if (amt > total) throw new DomainError('Valor recebido maior que o total da venda.');
    if (amt > 0) { req(method, 'Escolha a forma de pagamento.', 'method'); d.payments.push({ id: uid('pay'), saleId: sl.id, clientId, amount: amt, method, date: sl.date, kind: 'recebimento', createdAt: stamp(d), createdBy: me(d), idempotencyKey: sl.id + ':pay' }); ctx.publish('payment.received', { saleId: sl.id, amount: amt }); }
    ctx.audit('registrou venda', 'venda', sl.id, `${sl.items.map((i) => i.description).join(', ')}`);
    ctx.publish('sale.created', { saleId: sl.id, clientId });
    return sl;
  });
}

export function sellPackage({ clientId, packageId, method, amountReceived, professionalId }) {
  return transaction((d, ctx) => {
    assertPerm(d, 'pagamentos.registrar');
    const c = client(d, clientId); if (!c) throw new DomainError('Escolha a cliente.', 'clientId');
    const p = pkg(d, packageId); if (!p || !p.active) throw new DomainError('Pacote indisponível.', 'packageId');
    const at = stamp(d);
    const sl = { id: uid('sale'), date: d.settings.refDate, clientId, appointmentId: null, type: 'pacote', items: [{ serviceId: null, packageId: p.id, description: p.name, qty: 1, unitPrice: p.price, discount: 0, professionalId: professionalId || null }], status: 'valida', createdAt: at, createdBy: me(d), note: '' };
    d.sales.push(sl);
    const amt = amountReceived == null ? p.price : Math.round(amountReceived);
    if (amt > p.price) throw new DomainError('Valor recebido maior que o preço do pacote.');
    if (amt > 0) { req(method, 'Escolha a forma de pagamento.', 'method'); d.payments.push({ id: uid('pay'), saleId: sl.id, clientId, amount: amt, method, date: d.settings.refDate, kind: 'recebimento', createdAt: at, createdBy: me(d), idempotencyKey: sl.id + ':pay' }); ctx.publish('payment.received', { saleId: sl.id, amount: amt }); }
    const total = p.items.reduce((t, i) => t + i.sessions, 0);
    const cp = { id: uid('cpk'), clientId, packageId: p.id, saleId: sl.id, purchaseDate: d.settings.refDate, expiresAt: addDays(d.settings.refDate, p.validityDays), sessionsTotal: total, serviceIds: p.items.map((i) => i.serviceId), items: p.items.map((i) => ({ ...i })), status: 'ativo' };
    d.clientPackages.push(cp);
    ctx.audit('vendeu pacote', 'pacote', cp.id, `${p.name} para ${c.name}`);
    ctx.publish('sale.created', { saleId: sl.id, clientId });
    return cp;
  });
}

export function registerPayment({ saleId, amount, method, date, idempotencyKey }) {
  return transaction((d, ctx) => {
    assertPerm(d, 'pagamentos.registrar');
    const sl = sale(d, saleId); if (!sl || sl.status !== 'valida') throw new DomainError('Venda não encontrada ou cancelada.');
    if (idempotencyKey && d.payments.some((p) => p.idempotencyKey === idempotencyKey)) throw new DomainError('Este pagamento já foi registrado.');
    const balance = saleTotal(sl) - salePaid(d, sl.id);
    const amt = Math.round(amount);
    if (!(amt > 0)) throw new DomainError('Informe um valor maior que zero.', 'amount');
    if (amt > balance) throw new DomainError(`Valor maior que o saldo pendente (${(balance / 100).toFixed(2).replace('.', ',')}).`, 'amount');
    req(method, 'Escolha a forma de pagamento.', 'method');
    const p = { id: uid('pay'), saleId, clientId: sl.clientId, amount: amt, method, date: date || d.settings.refDate, kind: 'recebimento', createdAt: stamp(d), createdBy: me(d), idempotencyKey: idempotencyKey || uid('key') };
    if (p.date > d.settings.refDate) throw new DomainError('A data do recebimento não pode ser futura.', 'date');
    d.payments.push(p);
    ctx.audit('registrou recebimento', 'pagamento', p.id, `${(amt / 100).toFixed(2)} via ${method}`);
    ctx.publish('payment.received', { paymentId: p.id, saleId, amount: amt });
    return p;
  });
}

export function reversePayment(paymentId, reason) {
  return transaction((d, ctx) => {
    assertPerm(d, 'estornos.autorizar');
    const p = byId(d.payments, paymentId); if (!p || p.kind !== 'recebimento') throw new DomainError('Recebimento não encontrado.');
    if (d.payments.some((x) => x.reversesId === p.id)) throw new DomainError('Este recebimento já foi estornado.');
    req(reason?.trim(), 'Informe o motivo do estorno.', 'reason');
    const r = { id: uid('pay'), saleId: p.saleId, clientId: p.clientId, amount: -p.amount, method: p.method, date: d.settings.refDate, kind: 'estorno', reversesId: p.id, reason, createdAt: stamp(d), createdBy: me(d), idempotencyKey: 'rev:' + p.id };
    d.payments.push(r);
    ctx.audit('estornou', 'pagamento', p.id, reason);
    ctx.publish('payment.reversed', { paymentId: p.id, reversalId: r.id, amount: p.amount });
    return r;
  });
}

export function cancelSale(saleId, reason) {
  return transaction((d, ctx) => {
    assertPerm(d, 'estornos.autorizar');
    const sl = sale(d, saleId); if (!sl || sl.status !== 'valida') throw new DomainError('Venda não encontrada.');
    if (salePaid(d, sl.id) > 0) throw new DomainError('Estorne os recebimentos desta venda antes de cancelá-la.');
    if (sl.type === 'pacote') { const cp = d.clientPackages.find((x) => x.saleId === sl.id); if (cp && d.packageUsage.some((u) => u.clientPackageId === cp.id)) throw new DomainError('O pacote já tem sessões usadas; não pode ser cancelado.'); if (cp) cp.status = 'cancelado'; }
    req(reason?.trim(), 'Informe o motivo.', 'reason');
    sl.status = 'cancelada'; sl.cancelReason = reason; sl.cancelledAt = stamp(d); sl.cancelledBy = me(d);
    ctx.audit('cancelou venda', 'venda', sl.id, reason);
    ctx.publish('sale.cancelled', { saleId });
  });
}

// ======================= DESPESAS E CAIXA =======================
export function saveExpense(input) {
  return transaction((d, ctx) => {
    assertPerm(d, 'despesas.editar');
    req(input.description?.trim(), 'Descreva a despesa.', 'description');
    if (!(input.amount > 0)) throw new DomainError('Informe o valor.', 'amount');
    req(input.date, 'Informe a data de vencimento.', 'date');
    let e = input.id ? byId(d.expenses, input.id) : null;
    if (!e) { e = { id: uid('exp'), createdBy: me(d) }; d.expenses.push(e); }
    Object.assign(e, { description: input.description.trim(), category: input.category || 'Outras', amount: Math.round(input.amount), date: input.date, paid: !!input.paid, paidDate: input.paid ? input.paidDate || d.settings.refDate : null, supplier: input.supplier || '' });
    if (e.paid && e.paidDate > d.settings.refDate) throw new DomainError('A data de pagamento não pode ser futura.', 'paidDate');
    ctx.audit(input.id ? 'editou' : 'lançou', 'despesa', e.id, e.description);
    return e;
  });
}
export function payExpense(id) { return transaction((d, ctx) => { assertPerm(d, 'despesas.editar'); const e = byId(d.expenses, id); e.paid = true; e.paidDate = d.settings.refDate; ctx.audit('pagou', 'despesa', id, e.description); }); }

export function closeCash({ date, counted, note }) {
  return transaction((d, ctx) => {
    assertPerm(d, 'pagamentos.registrar');
    if (d.cashClosings.some((c) => c.date === date)) throw new DomainError('O caixa deste dia já foi fechado.');
    const byMethod = {}; for (const p of d.payments) if (p.date === date) byMethod[p.method] = (byMethod[p.method] || 0) + p.amount;
    const c = { id: uid('cx'), date, expected: byMethod, counted, note: note || '', at: stamp(d), by: me(d) };
    d.cashClosings.push(c); ctx.audit('fechou caixa', 'caixa', c.id, date);
    return c;
  });
}

// ======================= SERVIÇOS E PACOTES =======================
export function saveService(input) {
  return transaction((d, ctx) => {
    assertPerm(d, 'servicos.editar');
    req(input.name?.trim(), 'Informe o nome do serviço.', 'name'); req(input.category, 'Escolha a categoria.', 'category');
    if (!(input.price >= 0)) throw new DomainError('Informe o preço.', 'price');
    if (!(input.duration >= 5)) throw new DomainError('Informe a duração em minutos.', 'duration');
    if (!input.professionalIds?.length) throw new DomainError('Habilite ao menos uma profissional.', 'professionalIds');
    let s = input.id ? service(d, input.id) : null;
    if (!s) { s = { id: uid('srv'), createdAt: d.settings.refDate, active: true }; d.services.push(s); }
    const priceChanged = s.price !== undefined && s.price !== input.price;
    Object.assign(s, { name: input.name.trim(), category: input.category, description: input.description || '', price: Math.round(input.price), duration: Number(input.duration), professionalIds: input.professionalIds, commissionPct: Number(input.commissionPct) || 0, resourceId: input.resourceId || null, active: input.active !== false });
    if (priceChanged || !input.id) d.servicePriceHistory.push({ id: uid('sph'), serviceId: s.id, price: s.price, from: d.settings.refDate, by: me(d) });
    ctx.audit(input.id ? 'editou' : 'criou', 'serviço', s.id, `${s.name}${priceChanged ? ' (novo preço; histórico preservado)' : ''}`);
    return s;
  });
}
export function toggleService(id) { return transaction((d, ctx) => { assertPerm(d, 'servicos.editar'); const s = service(d, id); s.active = !s.active; ctx.audit(s.active ? 'ativou' : 'inativou', 'serviço', id, s.name); }); }
export function savePackage(input) {
  return transaction((d, ctx) => {
    assertPerm(d, 'servicos.editar');
    req(input.name?.trim(), 'Informe o nome do pacote.', 'name');
    if (!input.items?.length || input.items.some((i) => !i.serviceId || !(i.sessions > 0))) throw new DomainError('Adicione serviços com quantidade de sessões.', 'items');
    if (!(input.price > 0)) throw new DomainError('Informe o preço.', 'price');
    if (!(input.validityDays > 0)) throw new DomainError('Informe a validade em dias.', 'validityDays');
    let p = input.id ? pkg(d, input.id) : null;
    if (!p) { p = { id: uid('pkg'), active: true }; d.packages.push(p); }
    Object.assign(p, { name: input.name.trim(), items: input.items.map((i) => ({ serviceId: i.serviceId, sessions: Number(i.sessions) })), price: Math.round(input.price), validityDays: Number(input.validityDays), rules: input.rules || '', active: input.active !== false });
    ctx.audit(input.id ? 'editou' : 'criou', 'pacote', p.id, p.name);
    return p;
  });
}
export function togglePackage(id) { return transaction((d, ctx) => { assertPerm(d, 'servicos.editar'); const p = pkg(d, id); p.active = !p.active; ctx.audit(p.active ? 'ativou' : 'inativou', 'pacote', id, p.name); }); }

// ======================= EQUIPE, CONFIGURAÇÕES =======================
export function saveUser(input) {
  return transaction((d, ctx) => {
    assertPerm(d, 'equipe.gerir');
    req(input.name?.trim(), 'Informe o nome.', 'name'); req(input.email?.trim(), 'Informe o e-mail.', 'email'); req(input.role, 'Escolha o papel.', 'role');
    if (!/^\S+@\S+\.\S+$/.test(input.email)) throw new DomainError('E-mail inválido.', 'email');
    if (d.users.some((u) => u.email.toLowerCase() === input.email.toLowerCase() && u.id !== input.id)) throw new DomainError('Já existe um usuário com este e-mail.', 'email');
    let u = input.id ? byId(d.users, input.id) : null;
    if (!u) { u = { id: uid('usr'), active: true }; d.users.push(u); }
    if (u.id === me(d) && input.role !== u.role) throw new DomainError('Você não pode alterar o seu próprio papel.');
    let proId = input.professionalId || null;
    if (input.createProfessional) {
      const p = { id: uid('pro'), name: input.name.trim(), color: '#247B82', active: true, since: d.settings.refDate, schedule: { 2: { start: '09:00', end: '18:00', breakStart: '12:00', breakEnd: '13:00' }, 3: { start: '09:00', end: '18:00', breakStart: '12:00', breakEnd: '13:00' }, 4: { start: '09:00', end: '18:00', breakStart: '12:00', breakEnd: '13:00' }, 5: { start: '09:00', end: '18:00', breakStart: '12:00', breakEnd: '13:00' } } };
      d.professionals.push(p); proId = p.id;
    }
    Object.assign(u, { name: input.name.trim(), email: input.email.trim(), role: input.role, professionalId: proId, phone: input.phone ? normalizePhone(input.phone) || '' : u.phone || '' });
    ctx.audit(input.id ? 'editou' : 'criou', 'usuário', u.id, `${u.name} (${u.role})`);
    return u;
  });
}
export function toggleUser(id) {
  return transaction((d, ctx) => {
    assertPerm(d, 'equipe.gerir'); if (id === me(d)) throw new DomainError('Você não pode desativar o próprio acesso.');
    const u = byId(d.users, id); u.active = !u.active; ctx.audit(u.active ? 'ativou' : 'desativou', 'usuário', id, u.name);
  });
}
export function updateProfile(patch) {
  return transaction((d, ctx) => { const u = byId(d.users, me(d)); if (patch.name) u.name = patch.name.trim(); if (patch.phone !== undefined) u.phone = normalizePhone(patch.phone) || ''; ctx.audit('editou perfil', 'usuário', u.id, ''); });
}
export function setRolePerm(role, perm, value) {
  return transaction((d, ctx) => {
    assertPerm(d, 'equipe.gerir'); if (role === 'proprietaria') throw new DomainError('As permissões da proprietária não podem ser reduzidas.');
    d.org.rolePerms = d.org.rolePerms || {};
    const cur = new Set(d.org.rolePerms[role] || ROLE_PERMS[role]); value ? cur.add(perm) : cur.delete(perm); d.org.rolePerms[role] = [...cur];
    ctx.audit('alterou permissão', 'papel', role, `${perm}: ${value ? 'sim' : 'não'}`);
  });
}

export function saveOrg(patch) {
  return transaction((d, ctx) => {
    assertPerm(d, 'config.editar');
    if (patch.name !== undefined) req(patch.name.trim(), 'Informe o nome do estabelecimento.', 'name');
    for (const [k, v] of Object.entries(patch)) { if (typeof v === 'object' && v && !Array.isArray(v) && d.org[k] && typeof d.org[k] === 'object') d.org[k] = { ...d.org[k], ...v }; else d.org[k] = v; }
    ctx.audit('editou', 'configurações', d.org.id, Object.keys(patch).join(', '));
  });
}
export function saveSchedule(proId, schedule) {
  return transaction((d, ctx) => {
    assertPerm(d, 'config.editar');
    for (const [day, v] of Object.entries(schedule)) if (v) {
      if (timeToMin(v.start) >= timeToMin(v.end)) throw new DomainError(`Horário inválido em ${['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'][day]}.`);
      if (v.breakStart && (timeToMin(v.breakStart) >= timeToMin(v.breakEnd) || timeToMin(v.breakStart) < timeToMin(v.start) || timeToMin(v.breakEnd) > timeToMin(v.end))) throw new DomainError(`Intervalo inválido em ${['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'][day]}.`);
    }
    const p = professional(d, proId); p.schedule = schedule; ctx.audit('editou jornada', 'profissional', proId, p.name);
  });
}
export function addBlock({ professionalId, start, end, reason, allDay }) {
  return transaction((d, ctx) => {
    assertPerm(d, 'agenda.editar');
    req(professionalId, 'Escolha a profissional.'); req(start, 'Informe o início.'); req(end, 'Informe o fim.'); req(reason?.trim(), 'Informe o motivo.');
    if (end < start) throw new DomainError('O fim deve ser depois do início.');
    const b = { id: uid('blk'), professionalId, start, end, reason, allDay: !!allDay }; d.blocks.push(b); ctx.audit('bloqueou agenda', 'profissional', professionalId, reason); return b;
  });
}
export function removeBlock(id) { return transaction((d, ctx) => { d.blocks = d.blocks.filter((b) => b.id !== id); ctx.audit('removeu bloqueio', 'agenda', id, ''); }); }
export function toggleProfessional(id) { return transaction((d, ctx) => { assertPerm(d, 'config.editar'); const p = professional(d, id); p.active = !p.active; ctx.audit(p.active ? 'ativou' : 'inativou', 'profissional', id, p.name); }); }

// ======================= SESSÃO (demonstrativa) =======================
export function login(email, password) {
  return transaction((d, ctx) => {
    const u = d.users.find((x) => x.email.toLowerCase() === String(email).trim().toLowerCase());
    if (!u || password !== 'demo123') throw new DomainError('E-mail ou senha incorretos.');
    if (!u.active) throw new DomainError('Este acesso está desativado. Fale com a proprietária.');
    d.settings.session = { userId: u.id, since: new Date().toISOString() };
    ctx.audit('entrou', 'sessão', u.id, 'login demonstrativo');
    return u;
  });
}
export function switchUser(userId) { return transaction((d, ctx) => { const u = byId(d.users, userId); if (!u?.active) throw new DomainError('Usuário inativo.'); d.settings.session = { userId, since: new Date().toISOString(), demoSwitch: true }; ctx.audit('trocou perfil (demonstração)', 'sessão', userId, u.role); }); }
export function logout() { return transaction((d) => { d.settings.session = null; }); }
