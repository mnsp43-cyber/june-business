// CRM: segmentos dinâmicos, elegibilidade/consentimento, campanhas e jornadas.
// Segmento = classificação comercial. Elegibilidade = pode receber mensagem (canal + finalidade).
import { transaction, onEvent } from '../data/store.js';
import { clientStats, idx } from '../metrics/metrics.js';
import { addDays, diffDays, uid, fmtDate, timeToMin, minToTime } from '../util.js';
import { DomainError, assertPerm, client, service, professional, byId, renderTemplate, packageRemaining, activeClients } from './core.js';
import { providerFor } from '../adapters/messaging.js';

export function segmentDefs(s) {
  const c = s.org.crm;
  const defs = [
    { id: 'leads', name: 'Leads sem atendimento', criteria: 'Cadastradas sem nenhuma visita realizada.' },
    { id: 'primeira_visita', name: 'Primeira visita recente', criteria: `Primeira visita realizada nos últimos ${c.recentFirstVisitDays} dias.` },
    { id: 'recorrentes', name: 'Recorrentes', criteria: `Duas ou mais visitas e a última há no máximo ${c.inactivityDays} dias.` },
    { id: 'sem_retorno_30', name: 'Sem retorno há 30 a 59 dias', criteria: 'Última visita entre 30 e 59 dias atrás e sem agendamento futuro.' },
    { id: 'sem_retorno_60', name: 'Sem retorno há 60 a 89 dias', criteria: 'Última visita entre 60 e 89 dias atrás e sem agendamento futuro.' },
    { id: 'sem_retorno_90', name: 'Sem retorno há 90 dias ou mais', criteria: 'Última visita há 90 dias ou mais e sem agendamento futuro.' },
    { id: 'aniversariantes', name: 'Aniversariantes do mês', criteria: 'Data de nascimento no mês atual.' },
    { id: 'alto_valor', name: 'Alto valor comercial', criteria: `As ${c.highValueTopPct}% clientes com maior valor de vendas nos últimos 12 meses.` },
    { id: 'pacote_fim', name: 'Pacote próximo do fim', criteria: `Pacote ativo com ${c.packageAlertSessions} sessão(ões) restante(s) ou vencendo em até ${c.packageAlertDays} dias.` },
    { id: 'faltas', name: 'Histórico de faltas', criteria: `${c.noShowMin} ou mais faltas registradas.` },
    { id: 'reativadas', name: 'Reativadas', criteria: `Voltaram nos últimos ${c.reactivatedWindowDays} dias depois de mais de ${c.inactivityDays} dias sem visita.` },
    { id: 'futuros', name: 'Com agendamento futuro', criteria: 'Agendamento ativo a partir de agora.' },
  ];
  for (const sv of s.services.filter((x) => x.active)) defs.push({ id: 'servico:' + sv.id, name: `Clientes de ${sv.name}`, criteria: `Já realizaram ${sv.name}.`, byService: true });
  return defs;
}

export function segmentMembers(s, segId) {
  const I = idx(s); const key = 'seg:' + segId; if (I.cache.has(key)) return I.cache.get(key);
  const ref = s.settings.refDate; const c = s.org.crm; const list = activeClients(s);
  let members = [];
  const st = (x) => clientStats(s, x.id);
  const noFuture = (x) => !st(x).future.length;
  switch (true) {
    case segId === 'leads': members = list.filter((x) => st(x).visitCount === 0); break;
    case segId === 'primeira_visita': members = list.filter((x) => st(x).firstVisit && diffDays(ref, st(x).firstVisit) <= c.recentFirstVisitDays); break;
    case segId === 'recorrentes': members = list.filter((x) => st(x).visitCount >= 2 && st(x).daysSince <= c.inactivityDays); break;
    case segId === 'sem_retorno_30': members = list.filter((x) => st(x).daysSince >= 30 && st(x).daysSince < 60 && noFuture(x)); break;
    case segId === 'sem_retorno_60': members = list.filter((x) => st(x).daysSince >= 60 && st(x).daysSince < 90 && noFuture(x)); break;
    case segId === 'sem_retorno_90': members = list.filter((x) => st(x).daysSince >= 90 && noFuture(x)); break;
    case segId === 'aniversariantes': members = list.filter((x) => x.birth && x.birth.slice(5, 7) === ref.slice(5, 7)); break;
    case segId === 'alto_valor': { const ranked = list.map((x) => [x, st(x).sales12m]).filter(([, v]) => v > 0).sort((a, b) => b[1] - a[1]); members = ranked.slice(0, Math.max(1, Math.round(ranked.length * c.highValueTopPct / 100))).map(([x]) => x); break; }
    case segId === 'pacote_fim': members = list.filter((x) => st(x).activePackages.some((cp) => packageRemaining(s, cp) <= c.packageAlertSessions || diffDays(cp.expiresAt, ref) <= c.packageAlertDays)); break;
    case segId === 'faltas': members = list.filter((x) => st(x).noShows >= c.noShowMin); break;
    case segId === 'reativadas': members = list.filter((x) => { const v = st(x).visits; for (let i = v.length - 1; i > 0; i--) { if (diffDays(ref, v[i].date) > c.reactivatedWindowDays) break; if (diffDays(v[i].date, v[i - 1].date) > c.inactivityDays) return true; } return false; }); break;
    case segId === 'futuros': members = list.filter((x) => st(x).future.length > 0); break;
    case segId.startsWith('servico:'): { const sid = segId.slice(8); members = list.filter((x) => st(x).services.includes(sid)); break; }
    default: members = [];
  }
  I.cache.set(key, members); return members;
}

export function clientSegments(s, clientId) { return segmentDefs(s).filter((d) => !d.byService && segmentMembers(s, d.id).some((m) => m.id === clientId)); }

// Elegibilidade: revalida canal, finalidade, consentimento e dados de contato.
export function eligibility(s, cl, channel, purpose) {
  if (!cl || cl.mergedInto) return { ok: false, reason: 'Cadastro inexistente ou mesclado' };
  if (channel === 'sms') return { ok: false, reason: 'SMS planejado para evolução futura' };
  if (channel === 'email' && !cl.email) return { ok: false, reason: 'Sem e-mail cadastrado' };
  if (channel === 'whatsapp' && !cl.phone) return { ok: false, reason: 'Sem telefone' };
  const cons = cl.consents?.[channel] || {};
  if (purpose === 'promocional' && !cons.promocional) return { ok: false, reason: 'Sem consentimento promocional neste canal' };
  if (purpose === 'operacional' && !cons.operacional) return { ok: false, reason: 'Descadastrada de mensagens operacionais' };
  return { ok: true, reason: '' };
}
export function eligibleCount(s, members, channel, purpose) { return members.filter((m) => eligibility(s, m, channel, purpose).ok).length; }

export function templateVars(s, cl, appt) {
  const sv = appt ? service(s, appt.serviceId) : null; const pr = appt ? professional(s, appt.professionalId) : null;
  return { nome: cl?.name.split(' ')[0] || '', servico: sv?.name || (cl ? lastServiceName(s, cl.id) : ''), profissional: pr?.name.split(' ')[0] || '', data: appt ? fmtDate(appt.date) : '', horario: appt?.start || '', estabelecimento: s.org.name };
}
function lastServiceName(s, cid) { const v = clientStats(s, cid).visits.at(-1); return v ? service(s, v.serviceId)?.name || '' : ''; }

// ======================= CAMPANHAS =======================
export function saveCampaign(input) {
  return transaction((d, ctx) => {
    assertPerm(d, 'campanhas.criar');
    if (!input.name?.trim()) throw new DomainError('Dê um nome à campanha.', 'name');
    if (!input.segmentId) throw new DomainError('Escolha o público (segmento).', 'segmentId');
    if (!input.text?.trim()) throw new DomainError('Escreva a mensagem.', 'text');
    let c = input.id ? byId(d.campaigns, input.id) : null;
    if (c && !['rascunho', 'aguardando'].includes(c.status)) throw new DomainError('Só rascunhos podem ser editados.');
    if (!c) { c = { id: uid('cmp'), status: 'rascunho', createdAt: `${d.settings.refDate}T${d.settings.demoTime}`, createdBy: d.settings.session.userId, recipients: [], simulated: true }; d.campaigns.push(c); }
    Object.assign(c, { name: input.name.trim(), objective: input.objective || '', segmentId: input.segmentId, channel: input.channel || 'whatsapp', purpose: input.purpose || 'promocional', templateId: input.templateId || null, text: input.text, subject: input.subject || '', scheduledAt: input.scheduledAt || null });
    if (c.status === 'aguardando') { c.status = 'rascunho'; c.approvedBy = null; }
    ctx.audit(input.id ? 'editou' : 'criou', 'campanha', c.id, c.name);
    return c;
  });
}
export function submitCampaign(id) { return transaction((d, ctx) => { assertPerm(d, 'campanhas.criar'); const c = byId(d.campaigns, id); if (c.status !== 'rascunho') throw new DomainError('Apenas rascunhos podem ser enviados para aprovação.'); c.status = 'aguardando'; ctx.audit('enviou para aprovação', 'campanha', id, c.name); }); }
export function approveCampaign(id) {
  return transaction((d, ctx) => {
    assertPerm(d, 'campanhas.aprovar'); const c = byId(d.campaigns, id);
    if (c.status !== 'aguardando') throw new DomainError('A campanha não está aguardando aprovação.');
    c.status = 'agendada'; c.approvedBy = d.settings.session.userId; c.approvedAt = `${d.settings.refDate}T${d.settings.demoTime}`;
    if (!c.scheduledAt) c.scheduledAt = c.approvedAt;
    ctx.audit('aprovou', 'campanha', id, c.name);
  });
}
export function cancelCampaign(id) { return transaction((d, ctx) => { const c = byId(d.campaigns, id); if (['concluida', 'cancelada'].includes(c.status)) throw new DomainError('Campanha já encerrada.'); c.status = 'cancelada'; ctx.audit('cancelou', 'campanha', id, c.name); }); }
export function duplicateCampaign(id) { return transaction((d, ctx) => { const o = byId(d.campaigns, id); const c = { ...structuredClone(o), id: uid('cmp'), name: o.name + ' (cópia)', status: 'rascunho', recipients: [], approvedBy: null, approvedAt: null, executedAt: null, scheduledAt: null, createdAt: `${d.settings.refDate}T${d.settings.demoTime}` }; d.campaigns.push(c); ctx.audit('duplicou', 'campanha', c.id, c.name); return c; }); }

// Execução pelo provedor SIMULADO. Revalida elegibilidade de cada destinatária.
export function executeCampaign(id) {
  return transaction((d, ctx) => {
    const c = byId(d.campaigns, id);
    if (c.status !== 'agendada') throw new DomainError('A campanha precisa estar aprovada e agendada.');
    const now = `${d.settings.refDate}T${d.settings.demoTime}`;
    if (c.scheduledAt > now) throw new DomainError(`Agendada para ${fmtDate(c.scheduledAt)} às ${c.scheduledAt.slice(11, 16)}. Avance a data demonstrativa ou edite o agendamento.`);
    c.status = 'processando';
    const members = segmentMembers(d, c.segmentId); const provider = providerFor(c.channel);
    c.recipients = []; c.segmentSize = members.length;
    for (const m of members) {
      const el = eligibility(d, m, c.channel, c.purpose || 'promocional');
      if (!el.ok) { c.recipients.push({ clientId: m.id, status: 'bloqueada', reason: el.reason, at: now }); continue; }
      const text = renderTemplate(c.text, templateVars(d, m, null));
      const res = provider.send({ channel: c.channel, to: c.channel === 'email' ? m.email : m.phone, text, idempotencyKey: c.id + m.id });
      c.recipients.push({ clientId: m.id, status: res.status, at: now, error: res.error || null });
      d.communications.push({ id: uid('msg'), clientId: m.id, channel: c.channel, purpose: c.purpose || 'promocional', templateId: c.templateId, campaignId: c.id, journeyId: null, appointmentId: null, text, status: res.status, at: now, simulated: true });
    }
    c.status = 'concluida'; c.executedAt = now;
    ctx.audit('executou (simulado)', 'campanha', id, `${c.recipients.filter((r) => r.status !== 'bloqueada').length} mensagens simuladas`);
    return c;
  });
}

// Atribuição (regra demonstrativa, sobre dados existentes): destinatária com mensagem
// entregue/lida que criou agendamento ou compra em até N dias após a execução.
export function campaignResults(s, c) {
  const win = s.org.crm.attributionDays; const sent = c.recipients.filter((r) => !['bloqueada', 'falhou'].includes(r.status));
  const r = { audience: c.segmentSize ?? c.recipients.length, eligible: c.recipients.filter((x) => x.status !== 'bloqueada').length, sent: sent.length, delivered: c.recipients.filter((x) => ['entregue', 'lida'].includes(x.status)).length, read: c.recipients.filter((x) => x.status === 'lida').length, failed: c.recipients.filter((x) => x.status === 'falhou').length, blocked: c.recipients.filter((x) => x.status === 'bloqueada').length, optOuts: 0, bookings: 0, sales: 0, revenue: 0 };
  if (!c.executedAt) return r; const start = c.executedAt.slice(0, 10); const end = addDays(start, win);
  const ids = new Set(sent.map((x) => x.clientId));
  r.optOuts = s.consentHistory.filter((h) => ids.has(h.clientId) && !h.value && h.at.slice(0, 10) >= start && h.at.slice(0, 10) <= end).length;
  r.bookings = s.appointments.filter((a) => ids.has(a.clientId) && a.createdAt.slice(0, 10) >= start && a.createdAt.slice(0, 10) <= end).length;
  const sl = s.sales.filter((x) => ids.has(x.clientId) && x.status === 'valida' && x.date >= start && x.date <= end);
  r.sales = sl.length; r.revenue = sl.reduce((t, x) => t + idx(s).saleTot.get(x.id), 0);
  return r;
}

// ======================= JORNADAS =======================
export const TRIGGERS = {
  'appointment.created': 'Agendamento criado',
  'appointment.reminder': 'Antes do atendimento',
  'appointment.completed': 'Atendimento concluído',
  'client.birthday': 'Aniversário da cliente',
  'client.inactive': 'Cliente atingiu o limite de inatividade',
  'package.session_consumed': 'Sessão de pacote consumida',
};

export function saveJourney(input) {
  return transaction((d, ctx) => {
    assertPerm(d, 'campanhas.criar');
    if (!input.name?.trim()) throw new DomainError('Dê um nome à jornada.', 'name');
    if (!TRIGGERS[input.trigger]) throw new DomainError('Escolha o gatilho.', 'trigger');
    if (!input.templateId) throw new DomainError('Escolha o template.', 'templateId');
    let j = input.id ? byId(d.journeys, input.id) : null;
    if (!j) { j = { id: uid('jrn'), active: false, createdAt: d.settings.refDate }; d.journeys.push(j); }
    Object.assign(j, { name: input.name.trim(), trigger: input.trigger, condition: input.condition || '', waitHours: Number(input.waitHours) || 0, templateId: input.templateId, channel: input.channel || 'whatsapp' });
    ctx.audit(input.id ? 'editou' : 'criou', 'jornada', j.id, j.name);
    return j;
  });
}
export function toggleJourney(id) { return transaction((d, ctx) => { assertPerm(d, 'campanhas.criar'); const j = byId(d.journeys, id); j.active = !j.active; if (!j.active) for (const e of d.journeyExecutions) if (e.journeyId === id && e.status === 'pendente') { e.status = 'cancelada'; e.note = 'Jornada pausada'; } ctx.audit(j.active ? 'ativou' : 'pausou', 'jornada', id, j.name); }); }
export function saveTemplate(input) {
  return transaction((d, ctx) => {
    assertPerm(d, 'campanhas.criar');
    if (!input.name?.trim() || !input.text?.trim()) throw new DomainError('Preencha nome e texto do template.');
    let t = input.id ? byId(d.templates, input.id) : null; if (!t) { t = { id: uid('tpl') }; d.templates.push(t); }
    Object.assign(t, { name: input.name.trim(), type: input.type || 'promocional', purpose: input.purpose || 'promocional', channel: input.channel || 'whatsapp', text: input.text, subject: input.subject || '' });
    ctx.audit(input.id ? 'editou' : 'criou', 'template', t.id, t.name); return t;
  });
}

const addHours = (stampStr, h) => { const date = stampStr.slice(0, 10); let m = timeToMin(stampStr.slice(11, 16)) + Math.round(h * 60); const days = Math.floor(m / 1440); m = ((m % 1440) + 1440) % 1440; return `${addDays(date, days)}T${minToTime(m)}`; };

function enqueue(d, j, { clientId, appointmentId = null, eventKey, dueAt, source }) {
  const k = `${j.id}|${eventKey}`;
  if (d.journeyExecutions.some((e) => e.key === k)) return null; // impede disparo repetido
  const e = { id: uid('jex'), key: k, journeyId: j.id, clientId, appointmentId, dueAt, status: 'pendente', createdAt: `${d.settings.refDate}T${d.settings.demoTime}`, source };
  d.journeyExecutions.push(e); return e;
}

// Consumidor de eventos (idempotente). Roda dentro da mesma transação da operação.
onEvent((d, ev) => {
  const now = `${d.settings.refDate}T${d.settings.demoTime}`;
  const active = (trigger) => d.journeys.filter((j) => j.active && j.trigger === trigger);
  const p = ev.payload || {};
  if (ev.type === 'appointment.created') {
    const a = byId(d.appointments, p.appointmentId); if (!a) return;
    for (const j of active('appointment.created')) enqueue(d, j, { clientId: a.clientId, appointmentId: a.id, eventKey: a.id, dueAt: addHours(now, j.waitHours), source: ev.type });
    for (const j of active('appointment.reminder')) { const due = addHours(`${a.date}T${a.start}`, j.waitHours); if (due > now) enqueue(d, j, { clientId: a.clientId, appointmentId: a.id, eventKey: a.id, dueAt: due, source: ev.type }); }
  }
  if (['appointment.cancelled', 'appointment.rescheduled', 'appointment.no_show'].includes(ev.type)) {
    for (const e of d.journeyExecutions) if (e.appointmentId === p.appointmentId && e.status === 'pendente') { e.status = 'cancelada'; e.note = { 'appointment.cancelled': 'Agendamento cancelado', 'appointment.rescheduled': 'Agendamento reagendado', 'appointment.no_show': 'Cliente faltou' }[ev.type]; }
  }
  if (ev.type === 'appointment.completed') {
    const a = byId(d.appointments, p.appointmentId);
    for (const j of active('appointment.completed')) enqueue(d, j, { clientId: a.clientId, appointmentId: a.id, eventKey: a.id, dueAt: addHours(a.checkout?.at || now, j.waitHours), source: ev.type });
    for (const e of d.journeyExecutions) if (e.appointmentId === a.id && e.status === 'pendente' && byId(d.journeys, e.journeyId)?.trigger === 'appointment.reminder') { e.status = 'cancelada'; e.note = 'Atendimento já realizado'; }
  }
  if (ev.type === 'package.session_consumed' && p.remaining <= d.org.crm.packageAlertSessions) {
    for (const j of active('package.session_consumed')) enqueue(d, j, { clientId: p.clientId, eventKey: p.clientPackageId + ':' + p.remaining, dueAt: addHours(now, j.waitHours), source: ev.type });
  }
  if (ev.type === 'consent.updated' && !p.value) {
    for (const e of d.journeyExecutions) if (e.clientId === p.clientId && e.status === 'pendente') { const j = byId(d.journeys, e.journeyId); const t = byId(d.templates, j?.templateId); if (j?.channel === p.channel && t?.purpose === p.purpose) { e.status = 'cancelada'; e.note = 'Consentimento revogado'; } }
  }
});

// Processa a fila de jornadas até o "agora" demonstrativo. Revalida tudo antes de enviar.
function processQueueIn(d) {
  const now = `${d.settings.refDate}T${d.settings.demoTime}`; let sent = 0, blocked = 0, cancelled = 0;
  for (const e of d.journeyExecutions) {
    if (e.status !== 'pendente' || e.dueAt > now) continue;
    const j = byId(d.journeys, e.journeyId); const t = byId(d.templates, j?.templateId); const cl = byId(d.clients, e.clientId);
    if (!j?.active) { e.status = 'cancelada'; e.note = 'Jornada pausada'; cancelled++; continue; }
    const a = e.appointmentId ? byId(d.appointments, e.appointmentId) : null;
    if (a && ['appointment.created', 'appointment.reminder'].includes(j.trigger) && !['agendado', 'confirmado'].includes(a.status)) { e.status = 'cancelada'; e.note = 'Agendamento não está mais ativo'; cancelled++; continue; }
    const el = eligibility(d, cl, j.channel, t?.purpose || 'operacional');
    if (!el.ok) { e.status = 'bloqueada'; e.note = el.reason; e.at = now; blocked++; d.communications.push({ id: uid('msg'), clientId: e.clientId, channel: j.channel, purpose: t?.purpose, templateId: t?.id, campaignId: null, journeyId: j.id, appointmentId: e.appointmentId, text: '', status: 'bloqueada', at: now, simulated: true, reason: el.reason }); continue; }
    const text = renderTemplate(t.text, templateVars(d, cl, a));
    const res = providerFor(j.channel).send({ channel: j.channel, to: j.channel === 'email' ? cl.email : cl.phone, text, idempotencyKey: e.key });
    e.status = res.status === 'falhou' ? 'falhou' : 'executada'; e.at = now; e.note = res.error || '';
    d.communications.push({ id: uid('msg'), clientId: e.clientId, channel: j.channel, purpose: t.purpose, templateId: t.id, campaignId: null, journeyId: j.id, appointmentId: e.appointmentId, text, status: res.status, at: now, simulated: true });
    sent++;
  }
  return { sent, blocked, cancelled };
}
function dailyScan(d, date) {
  for (const j of d.journeys.filter((x) => x.active && x.trigger === 'client.birthday')) for (const c of d.clients) if (!c.mergedInto && c.birth && c.birth.slice(5) === date.slice(5)) enqueue(d, j, { clientId: c.id, eventKey: c.id + ':' + date.slice(0, 4), dueAt: `${date}T09:00`, source: 'scan' });
  for (const j of d.journeys.filter((x) => x.active && x.trigger === 'client.inactive')) {
    const lim = d.org.crm.inactivityDays;
    for (const c of d.clients) { if (c.mergedInto) continue; const st = clientStats(d, c.id, date); if (st.lastVisit && st.daysSince === lim + 1 && !st.future.length) enqueue(d, j, { clientId: c.id, eventKey: c.id + ':' + st.lastVisit, dueAt: `${date}T10:00`, source: 'scan' }); }
  }
}
export function processQueue() { return transaction((d) => { dailyScan(d, d.settings.refDate); return processQueueIn(d); }); }
export function simulateTrigger(journeyId, clientId) {
  return transaction((d) => {
    const j = byId(d.journeys, journeyId); if (!j) throw new DomainError('Jornada não encontrada.');
    if (!j.active) throw new DomainError('Ative a jornada para simular.');
    const appt = d.appointments.filter((a) => a.clientId === clientId).at(-1);
    const e = enqueue(d, j, { clientId, appointmentId: appt?.id || null, eventKey: 'sim:' + clientId + ':' + Date.now(), dueAt: `${d.settings.refDate}T${d.settings.demoTime}`, source: 'simulação manual' });
    return processQueueIn(d);
  });
}
// Avança o relógio demonstrativo e processa o que venceu. Não há processamento com o navegador fechado.
export function advanceTime({ days = 0, hours = 0 }) {
  return transaction((d, ctx) => {
    let date = d.settings.refDate; let m = timeToMin(d.settings.demoTime) + hours * 60;
    const target = addDays(date, days + Math.floor(m / 1440)); m = ((m % 1440) + 1440) % 1440;
    while (date < target) { date = addDays(date, 1); d.settings.refDate = date; d.settings.demoTime = '23:59'; dailyScan(d, date); processQueueIn(d); }
    d.settings.refDate = target; d.settings.demoTime = minToTime(m);
    dailyScan(d, target); const r = processQueueIn(d);
    ctx.audit('avançou data demonstrativa', 'sistema', null, `${target} ${minToTime(m)}`);
    return r;
  });
}
export function setDemoClock(date, time) {
  return transaction((d, ctx) => { if (date < d.settings.refDate) throw new DomainError('Para voltar no tempo, restaure a base fictícia. O relógio só avança, para não gerar registros incoerentes.'); d.settings.refDate = date; d.settings.demoTime = time; ctx.audit('ajustou relógio demonstrativo', 'sistema', null, `${date} ${time}`); });
}
