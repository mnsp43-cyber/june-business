// Consultas e utilidades de domínio compartilhadas (sem gravação).
import { ROLE_PERMS, ACTIVE_STATUSES } from '../domain/rules.js';
import { timeToMin, minToTime, dow, normalizePhone, similarity, norm } from '../util.js';

export const byId = (arr, id) => arr.find((x) => x.id === id) || null;
export const client = (s, id) => byId(s.clients, id);
export const service = (s, id) => byId(s.services, id);
export const professional = (s, id) => byId(s.professionals, id);
export const user = (s, id) => byId(s.users, id);
export const pkg = (s, id) => byId(s.packages, id);
export const appointment = (s, id) => byId(s.appointments, id);
export const sale = (s, id) => byId(s.sales, id);

export function currentUser(s) { return s.settings.session ? user(s, s.settings.session.userId) : null; }
export function hasPerm(s, perm, u = currentUser(s)) {
  if (!perm) return true; if (!u) return false;
  const custom = s.org.rolePerms?.[u.role];
  return (custom || ROLE_PERMS[u.role] || []).includes(perm);
}
export function rolePerms(s, role) { return s.org.rolePerms?.[role] || ROLE_PERMS[role] || []; }
export class DomainError extends Error { constructor(msg, field) { super(msg); this.field = field; } }
export function assertPerm(s, perm) { if (!hasPerm(s, perm)) throw new DomainError('Seu perfil não tem permissão para esta ação.'); }

// ---------- Vendas ----------
export const itemTotal = (i) => i.qty * i.unitPrice - (i.discount || 0);
export const saleGross = (sl) => sl.items.reduce((t, i) => t + i.qty * i.unitPrice, 0);
export const saleDiscount = (sl) => sl.items.reduce((t, i) => t + (i.discount || 0), 0);
export const saleTotal = (sl) => sl.items.reduce((t, i) => t + itemTotal(i), 0);
export function salePaid(s, saleId, until) { let t = 0; for (const p of s.payments) if (p.saleId === saleId && (!until || p.date <= until)) t += p.amount; return t; }
export function saleBalance(s, sl, until) { return sl.status === 'valida' ? Math.max(0, saleTotal(sl) - salePaid(s, sl.id, until)) : 0; }
export function saleSituation(s, sl) {
  if (sl.status !== 'valida') return { key: 'cancelada', label: 'Cancelada', tone: 'muted' };
  const tot = saleTotal(sl); const paid = salePaid(s, sl.id);
  if (tot === 0) return { key: 'cortesia', label: sl.type === 'cortesia' ? 'Cortesia' : 'Sem valor', tone: 'muted' };
  if (paid >= tot) return { key: 'pago', label: 'Pago', tone: 'good' };
  if (paid > 0) return { key: 'parcial', label: 'Parcial', tone: 'warn' };
  return { key: 'pendente', label: 'Pendente', tone: 'bad' };
}

// ---------- Pacotes ----------
export function packageUsed(s, cp, serviceId) { return s.packageUsage.filter((u) => u.clientPackageId === cp.id && (!serviceId || u.serviceId === serviceId)).length; }
export function packageRemaining(s, cp, serviceId) {
  if (serviceId) { const it = cp.items.find((i) => i.serviceId === serviceId); return it ? it.sessions - packageUsed(s, cp, serviceId) : 0; }
  return cp.sessionsTotal - packageUsed(s, cp);
}
export function packageState(s, cp, refDate) {
  const left = packageRemaining(s, cp);
  if (left <= 0) return { key: 'concluido', label: 'Concluído', tone: 'muted' };
  if (cp.expiresAt < refDate) return { key: 'vencido', label: 'Vencido', tone: 'bad' };
  return { key: 'ativo', label: 'Ativo', tone: 'good' };
}
export function usablePackages(s, clientId, serviceId, date) {
  return s.clientPackages.filter((cp) => cp.clientId === clientId && cp.expiresAt >= date && packageRemaining(s, cp, serviceId) > 0);
}

// ---------- Clientes ----------
export function activeClients(s) { return s.clients.filter((c) => !c.mergedInto); }
export function findByPhone(s, raw) { const p = normalizePhone(raw); if (!p) return []; return activeClients(s).filter((c) => c.phone === p); }
export function duplicateCandidates(s) {
  const out = []; const list = activeClients(s);
  const byPhone = new Map(); for (const c of list) { if (!byPhone.has(c.phone)) byPhone.set(c.phone, []); byPhone.get(c.phone).push(c); }
  for (const group of byPhone.values()) if (group.length > 1) for (let i = 0; i < group.length; i++) for (let j = i + 1; j < group.length; j++) {
    const sim = similarity(group[i].name, group[j].name);
    const dismissed = (s.org.dismissedDuplicates || []).includes([group[i].id, group[j].id].sort().join('|'));
    if (!dismissed) out.push({ a: group[i], b: group[j], reason: sim > 0.6 ? 'Mesmo telefone e nome parecido' : 'Mesmo telefone, nomes diferentes (pode ser telefone compartilhado)', score: sim });
  }
  return out.sort((x, y) => y.score - x.score);
}
export function searchClients(s, q) {
  const n = norm(q); const digits = q.replace(/\D/g, '');
  return activeClients(s).filter((c) => (n && norm(c.name).includes(n)) || (digits.length >= 4 && c.phone.includes(digits)) || (n && norm(c.email).includes(n)));
}

// ---------- Disponibilidade ----------
export function proSchedule(p, date) { return p.schedule[dow(date)] || null; }
export function blocksFor(s, proId, date) { return s.blocks.filter((b) => b.professionalId === proId && b.start.slice(0, 10) <= date && b.end.slice(0, 10) >= date); }

// Retorna mensagem de conflito ou null.
export function checkConflict(s, { professionalId, date, start, duration, resourceId, ignoreId }) {
  const p = professional(s, professionalId); if (!p) return 'Profissional não encontrada.';
  if (!p.active) return `${p.name} está inativa.`;
  const sch = proSchedule(p, date); if (!sch) return `${p.name} não atende neste dia da semana.`;
  const st = timeToMin(start), en = st + duration;
  if (st < timeToMin(sch.start) || en > timeToMin(sch.end)) return `Fora da jornada de ${p.name} (${sch.start} às ${sch.end}).`;
  if (sch.breakStart && st < timeToMin(sch.breakEnd) && en > timeToMin(sch.breakStart)) return `Conflita com o intervalo de ${p.name} (${sch.breakStart} às ${sch.breakEnd}).`;
  for (const b of blocksFor(s, professionalId, date)) {
    const bs = b.start.slice(0, 10) < date ? 0 : timeToMin(b.start.slice(11, 16)); const be = b.end.slice(0, 10) > date ? 1440 : timeToMin(b.end.slice(11, 16));
    if (st < be && en > bs) return `${p.name} está indisponível: ${b.reason}.`;
  }
  for (const a of s.appointments) {
    if (a.id === ignoreId || a.date !== date || !ACTIVE_STATUSES.concat('realizado').includes(a.status)) continue;
    const as = timeToMin(a.start), ae = as + a.duration;
    if (!(st < ae && en > as)) continue;
    if (a.professionalId === professionalId) return `${p.name} já tem atendimento das ${a.start} às ${minToTime(ae)}.`;
    if (resourceId && a.resourceId === resourceId) { const r = byId(s.resources, resourceId); return `${r ? r.name : 'O recurso'} está ocupada das ${a.start} às ${minToTime(ae)}.`; }
  }
  return null;
}

export function freeSlots(s, { professionalId, date, duration, resourceId, ignoreId, step = 15 }) {
  const p = professional(s, professionalId); if (!p) return [];
  const sch = proSchedule(p, date); if (!sch) return [];
  const out = [];
  for (let m = timeToMin(sch.start); m + duration <= timeToMin(sch.end); m += step) {
    const t = minToTime(m);
    if (!checkConflict(s, { professionalId, date, start: t, duration, resourceId, ignoreId })) out.push(t);
  }
  return out;
}

export function renderTemplate(text, vars) { return String(text || '').replace(/\{\{(\w+)\}\}/g, (_, k) => (vars[k] != null && vars[k] !== '' ? vars[k] : `{{${k}}}`)); }
