// Utilitários: datas, moeda, ids, texto. Sem dependências.

export const pad = (n) => String(n).padStart(2, '0');

// Datas são tratadas como strings locais 'YYYY-MM-DD' e 'YYYY-MM-DDTHH:mm'
// (fuso do estabelecimento, padrão America/Sao_Paulo). No MVP: timestamptz.
export function toDateStr(d) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
export function parseDate(s) { const [y, m, d] = s.slice(0, 10).split('-').map(Number); return new Date(y, m - 1, d); }
export function addDays(s, n) { const d = parseDate(s); d.setDate(d.getDate() + n); return toDateStr(d); }
export function addMonths(s, n) { const d = parseDate(s); const day = d.getDate(); d.setDate(1); d.setMonth(d.getMonth() + n); const last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate(); d.setDate(Math.min(day, last)); return toDateStr(d); }
export function diffDays(a, b) { return Math.round((parseDate(a) - parseDate(b)) / 864e5); }
export function dow(s) { return parseDate(s).getDay(); }
export function startOfMonth(s) { return s.slice(0, 8) + '01'; }
export function endOfMonth(s) { const d = parseDate(s); return toDateStr(new Date(d.getFullYear(), d.getMonth() + 1, 0)); }
export function startOfWeek(s) { const d = parseDate(s); const w = (d.getDay() + 6) % 7; d.setDate(d.getDate() - w); return toDateStr(d); }
export function timeToMin(t) { const [h, m] = t.split(':').map(Number); return h * 60 + m; }
export function minToTime(m) { return `${pad(Math.floor(m / 60))}:${pad(m % 60)}`; }
export function dt(date, time) { return `${date}T${time}`; }
export function datePart(s) { return s.slice(0, 10); }
export function timePart(s) { return s.slice(11, 16); }
export function addMinutesDT(s, min) { const t = timeToMin(timePart(s)) + min; return dt(addDays(datePart(s), Math.floor(t / 1440)), minToTime(((t % 1440) + 1440) % 1440)); }
export function cmpDT(a, b) { return a < b ? -1 : a > b ? 1 : 0; }

export const MONTHS = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
export const MONTHS_SHORT = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
export const WEEKDAYS = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
export const WEEKDAYS_SHORT = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];

export function fmtDate(s) { if (!s) return '—'; const [y, m, d] = s.slice(0, 10).split('-'); return `${d}/${m}/${y}`; }
export function fmtDateShort(s) { const [, m, d] = s.slice(0, 10).split('-'); return `${d}/${m}`; }
export function fmtDateTime(s) { return s ? `${fmtDate(s)} ${timePart(s)}` : '—'; }
export function fmtLongDate(s) { const d = parseDate(s); return `${WEEKDAYS[d.getDay()]}, ${d.getDate()} de ${MONTHS[d.getMonth()]} de ${d.getFullYear()}`; }
export function fmtMonth(s) { const d = parseDate(s); return `${MONTHS_SHORT[d.getMonth()]}/${String(d.getFullYear()).slice(2)}`; }
export function isoFromBR(br) { const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(br || ''); return m ? `${m[3]}-${m[2]}-${m[1]}` : null; }

// Dinheiro sempre em centavos inteiros.
const brl = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
export function money(c) { return brl.format((c || 0) / 100); }
export function moneyShort(c) { const v = (c || 0) / 100; if (Math.abs(v) >= 1000) return 'R$ ' + (v / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' mil'; return brl.format(v); }
export function parseMoney(str) { if (str == null) return NaN; let s = String(str).replace(/[^\d,.-]/g, ''); if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.'); const v = parseFloat(s); return isNaN(v) ? NaN : Math.round(v * 100); }
export function moneyInput(c) { return ((c || 0) / 100).toFixed(2).replace('.', ','); }
export function pct(v, digits = 1) { return v == null || !isFinite(v) ? '—' : v.toLocaleString('pt-BR', { maximumFractionDigits: digits, minimumFractionDigits: digits }) + '%'; }
export function num(v) { return (v || 0).toLocaleString('pt-BR'); }

// Telefone: normaliza para E.164 brasileiro (+55DDDNÚMERO).
export function normalizePhone(raw) {
  let d = String(raw || '').replace(/\D/g, '');
  if (d.startsWith('55') && d.length >= 12) d = d.slice(2);
  if (d.startsWith('0')) d = d.slice(1);
  if (d.length < 10 || d.length > 11) return null;
  return '+55' + d;
}
export function fmtPhone(e164) {
  if (!e164) return '—';
  const d = e164.replace('+55', '');
  return d.length === 11 ? `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}` : `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
}
export function maskPhoneInput(v) {
  const d = v.replace(/\D/g, '').slice(0, 11);
  if (d.length <= 2) return d.length ? `(${d}` : '';
  if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
}

let idCounter = 0;
export function uid(prefix = 'id') { idCounter = (idCounter + 1) % 1e6; return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}${idCounter.toString(36)}`; }

export function esc(s) { return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
export function initials(name) { return (name || '?').split(' ').filter(Boolean).slice(0, 2).map((p) => p[0]).join('').toUpperCase(); }
export function norm(s) { return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim(); }
export function firstName(n) { return (n || '').split(' ')[0]; }
export function sum(arr, f = (x) => x) { let t = 0; for (const x of arr) t += f(x) || 0; return t; }
export function groupBy(arr, f) { const m = new Map(); for (const x of arr) { const k = f(x); if (!m.has(k)) m.set(k, []); m.get(k).push(x); } return m; }
export function similarity(a, b) {
  a = norm(a); b = norm(b); if (!a || !b) return 0; if (a === b) return 1;
  const bg = (s) => { const r = new Map(); for (let i = 0; i < s.length - 1; i++) { const g = s.slice(i, i + 2); r.set(g, (r.get(g) || 0) + 1); } return r; };
  const A = bg(a), B = bg(b); let inter = 0; for (const [g, c] of A) inter += Math.min(c, B.get(g) || 0);
  return (2 * inter) / (a.length + b.length - 2);
}

// PRNG determinístico (mulberry32) para a base fictícia.
export function rng(seed) { let a = seed >>> 0; return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

export function toCSV(rows, columns) {
  const escCell = (v) => { const s = v == null ? '' : String(v); return /[;"\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const head = columns.map((c) => escCell(c.label)).join(';');
  const body = rows.map((r) => columns.map((c) => escCell(typeof c.value === 'function' ? c.value(r) : r[c.key])).join(';'));
  return '﻿' + [head, ...body].join('\n');
}
