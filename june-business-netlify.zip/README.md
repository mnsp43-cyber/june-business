# June Business — Protótipo navegável (Etapa 2)

**Gestão simples. Negócios mais inteligentes.**
Aplicação SaaS B2B para negócios de estética, beleza e bem-estar (1 a 5 profissionais). Esta versão é um protótipo completo e funcional, com dados fictícios do **June Studio** e persistência no navegador.

> Ambiente demonstrativo. Não use com dados reais. O login local não é autenticação segura, o armazenamento local não é banco de produção e nenhuma mensagem real é enviada.

## Como abrir

| Opção | Passos |
| --- | --- |
| Netlify (recomendado) | Acesse app.netlify.com → **Add new site → Deploy manually** → arraste a pasta descompactada do ZIP (ou o próprio ZIP). O `index.html` já está na raiz. Não há configuração de build. |
| No computador | Os módulos JavaScript não abrem por `file://`. Na pasta do projeto, rode `python3 -m http.server 8080` e acesse `http://localhost:8080`. |

**Credenciais provisórias** (já preenchidas): `admin@junebusiness.com` / `demo123` (Proprietária).
Outros perfis para teste (mesma senha): `recepcao@junebusiness.com` (Recepcionista), `bruna@junebusiness.com` (Profissional), `gestao@junebusiness.com` (Gestora), `suporte@june.com.br` (Administrador June). Também é possível trocar de perfil em **Configurações → Meu perfil**.

## Roteiro rápido de teste (jornada prioritária)

1. **Meu Dia** → veja pendências (horários passados sem status) e os cards do dia.
2. Botão **+ / Novo agendamento** → digite um telefone novo, nome, serviço e um horário livre → salve. O cadastro da cliente nasce sozinho.
3. Digite `(11) 98765-4321` em um novo agendamento: aparecem duas pessoas com o mesmo telefone (nada é mesclado sem confirmação).
4. Em um card, **Finalizar** → escolha *Pagamento parcial*, informe o valor → confirme.
5. **Finanças** → a venda aparece separada do recebimento; o saldo vai para *A receber*.
6. **Dados (Dashboard)** → indicadores e comparativos já refletem a finalização.
7. **Mais → CRM e Campanhas** → segmentos atualizados; crie uma campanha a partir de um segmento, envie para aprovação, aprove e execute (simulado).
8. **Configurações → Dados demonstrativos** → avance o relógio (+1 dia) para disparar jornadas de pós-atendimento; restaure a base quando quiser.

## O que está implementado

- **Meu Dia**: saudação, data, contadores (agendados, confirmados, realizados, pendentes, faltas, cancelamentos), vendas, recebido e a receber do dia, pendências operacionais com Realizado/Faltou/Cancelado/Reagendar, cards com coluna fixa de horário e ações conforme o estado.
- **Agenda**: visão diária por profissional (grade com horários livres e indisponíveis), semanal (equipe ou por profissional) e lista; filtros por profissional, categoria, serviço e status; bloqueios/férias; clique no horário livre para agendar.
- **Agendamento inteligente**: telefone normalizado (E.164), busca de cadastro na mesma empresa com confirmação de identidade, criação automática de cliente, preço/duração/profissionais habilitadas carregados do serviço, verificação de jornada, intervalo, bloqueio, sala/equipamento e conflitos; preço congelado no agendamento; evento para confirmação no CRM.
- **Estados** com transições válidas, histórico e reagendamento com vínculo ao horário original.
- **Finalização Expressa**: valor realizado editável, serviços extras, cinco situações (pago, parcial, pendente, sessão de pacote, cortesia autorizada), resumo antes de confirmar, idempotência contra duplicidade, atualização integrada de cliente, financeiro, pacote, métricas e segmentos.
- **Clientes**: busca, filtros, duplicidades com mesclagem autorizada, perfil com Visão geral, Histórico (linha do tempo), Pacotes, Financeiro e CRM (consentimentos por canal e finalidade, com histórico), exportação CSV.
- **Serviços e Pacotes**: catálogo com histórico de preços, ativar/inativar, pacotes de um ou mais serviços, venda de pacote, saldo, validade e consumo.
- **Financeiro**: vendas × recebimentos, a receber, recebimento parcial de saldo com data própria, despesas (pagas × em aberto), estornos por movimento de reversão, cancelamento de venda, fechamento de caixa, comissões simples, CSV.
- **Dashboard**: indicadores financeiros, operacionais e de clientes com comparativo (período equivalente ou anterior completo), variação %, p.p. para taxas, “não calculável” com anterior zero, filtros que recalculam tudo, insights determinísticos, 9 gráficos (evolução, comparação acumulada, status, serviços, profissionais, clientes, financeiro, horários de maior procura, retenção por coorte) e dicionário de métricas.
- **CRM**: 12 segmentos dinâmicos + por serviço, elegibilidade separada da classificação, campanhas com aprovação e provedor simulado, templates com variáveis e prévia, jornadas Gatilho → Condição → Espera → Ação com simulação de tempo, histórico de comunicações, atribuição demonstrativa.
- **Relatórios**: operacionais, financeiros, clientes, serviços, profissionais e CRM com CSV.
- **Configurações**: estabelecimento, horários, categorias, formas de pagamento, políticas, parâmetros de CRM, disponibilidade das profissionais, equipe e matriz de permissões, integrações (sem conexões falsas), relógio demonstrativo, restauração da base, indicadores de sucesso e trilha de auditoria.

## Estrutura de arquivos

```text
index.html            Entrada da aplicação
tests.html            Testes automatizados no navegador
assets/css/tokens.css Variáveis de marca (troque aqui pela identidade oficial da June)
assets/css/app.css    Estilos e componentes
src/util.js           Datas, moeda (centavos), telefone, CSV
src/domain/rules.js   Estados, transições, papéis e permissões
src/data/seed.js      Base fictícia determinística (12+ meses)
src/data/store.js     Repositório único, transação tudo-ou-nada, eventos (outbox)
src/services/         core (consultas), operations (gravações), crm (segmentos, campanhas, jornadas)
src/metrics/          Motor de métricas e dicionário
src/adapters/         Mensageria (simulado; WhatsApp oficial e e-mail preparados)
src/ui/               Componentes, gráficos SVG e telas por módulo
tests/                Testes das regras críticas (Node e navegador)
docs/                 Rastreabilidade e limitações
```

Sem dependências externas, sem etapa de compilação, sem chaves secretas.

## Testes executados

- **42 testes automatizados** das regras críticas (todos passando): `node tests/run-node.mjs` ou abra `tests.html`.
- Testes de interface automatizados no Chrome em 390 × 844 px (iPhone 13) e 1440 × 900 px: navegação por todos os módulos e abas, criação de agendamento com cliente nova, reconhecimento de telefone compartilhado, finalização parcial, perfil, campanha completa, troca de perfis, persistência após recarregar — sem erros de console e sem rolagem horizontal.

## Limitações conhecidas

- Persistência só no navegador atual (até ~5 MB); limpar dados do navegador apaga as alterações.
- Concorrência entre usuários, permissões no servidor, RLS, backups e autenticação real dependem do backend (Etapa 3).
- O campo de data nativo segue o idioma do navegador (em navegadores em inglês aparece MM/DD); todas as datas exibidas pelo sistema usam DD/MM/AAAA.
- Entregas, leituras e falhas de mensagens são simuladas; cliques e custos aparecem como indisponíveis.
- Na prévia dentro do Claude, downloads são bloqueados: a exportação mostra o conteúdo para copiar. Na versão publicada o CSV é baixado normalmente.
- Unidade única (multiunidade planejada); agendamento online, pagamentos e IA planejados.

## Próximos passos

1. Validar o protótipo com usuárias reais (tempo para agendar e finalizar).
2. Etapa 3 — MVP: Next.js + TypeScript + Supabase (Auth, PostgreSQL com RLS, transações, restrição de exclusão contra conflito de horário, outbox), reaproveitando `domain`, `services` e `metrics`.
3. Etapa 4 — CRM operacional com provedor simulado no servidor; Etapa 5 — integrações reais mediante aprovação.
